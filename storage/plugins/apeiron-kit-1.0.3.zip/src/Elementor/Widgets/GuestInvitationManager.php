<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class GuestInvitationManager extends BaseWidget {

	public function get_name() {
		return 'apeiron-guest-invitation-manager';
	}

	public function get_title() {
		return __( 'Guest Manager', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-guest';
	}

	public function get_keywords() {
		return [ 'invitation', 'guest', 'send', 'whatsapp', 'invite' ];
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-guest-invitation';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-guest-invitation-js' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}
		// Header Content Section
		$this->start_controls_section(
			'section_header_content',
			[
				'label' => __( 'Header Content', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'show_header',
			[
				'label'        => __( 'Tampilkan Header', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'after',
			]
		);

		$this->add_control(
			'header_icon',
			[
				'label' => __( 'Icon', 'apeiron-kit' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-user-plus',
					'library' => 'solid',
				],
				'condition' => [
					'show_header' => 'yes',
				],
			]
		);

		$this->add_control(
			'header_title',
			[
				'label' => __( 'Title', 'apeiron-kit' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Kelola Tamu Undangan', 'apeiron-kit' ),
				'label_block' => true,
				'condition' => [
					'show_header' => 'yes',
				],
			]
		);

		$this->add_control(
			'header_description',
			[
				'label' => __( 'Description', 'apeiron-kit' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => __( 'Buat daftar tamu dan kirim undangan dengan mudah.', 'apeiron-kit' ),
				'rows' => 2,
				'condition' => [
					'show_header' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// General Settings Section
		$this->start_controls_section(
			'section_general_settings',
			[
				'label' => __( 'Pengaturan Umum', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'show_guest_list',
			[
				'label' => __( 'Tampilkan Daftar Nama Tamu', 'apeiron-kit' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'apeiron-kit' ),
				'label_off' => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'guest_list_title',
			[
				'label'       => __( 'Judul Daftar Tamu', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Daftar Nama Tamu', 'apeiron-kit' ),
				'label_block' => true,
				'separator'   => 'before',
				'condition'   => [
					'show_guest_list' => 'yes',
				],
			]
		);

		$this->add_control(
			'table_label_no',
			[
				'label'       => __( 'Label Kolom No', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'No', 'apeiron-kit' ),
				'condition'   => [
					'show_guest_list' => 'yes',
				],
			]
		);

		$this->add_control(
			'table_label_guest',
			[
				'label'       => __( 'Label Kolom Nama', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Nama Tamu', 'apeiron-kit' ),
				'condition'   => [
					'show_guest_list' => 'yes',
				],
			]
		);

		$this->add_control(
			'table_label_option',
			[
				'label'       => __( 'Label Kolom Opsi', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Opsi', 'apeiron-kit' ),
				'condition'   => [
					'show_guest_list' => 'yes',
				],
			]
		);

		$this->add_control(
			'invitation_link_label',
			[
				'label'       => __( 'Label Link Undangan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Link Undangan', 'apeiron-kit' ),
				'label_block' => true,
				'separator'   => 'before',
			]
		);

		$this->add_control(
			'invitation_link_hint',
			[
				'label'       => __( 'Hint Link Undangan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '* Masukkan link undangan Anda. Contoh: apeiron.id/ika-budi atau https://apeiron.id/ika-budi', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'invitation_link_placeholder',
			[
				'label'       => __( 'Placeholder Link Undangan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Contoh: apeiron.id/ika-budi', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'guest_names_placeholder',
			[
				'label'       => __( 'Placeholder Nama Tamu', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Nama Tamu', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'message_template_placeholder',
			[
				'label'       => __( 'Placeholder Template Ucapan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Template ucapan akan muncul di sini...', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		// General Section
		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'General', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'info_description',
			[
				'raw'             => __( '<b>Info:</b> User harus memasukkan link undangan mereka di form frontend. Link akan otomatis ditambahkan parameter ?to=nama-tamu.<br><br>Contoh: Jika user input <b>apeiron.id/ika-budi</b>, maka link undangan akan menjadi <b>apeiron.id/ika-budi/?to=nama-tamu</b>', 'apeiron-kit' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'render_type'     => 'ui',
				'type'            => Controls_Manager::RAW_HTML,
			]
		);

		$this->add_control(
			'info_description3',
			[
				'raw'             => __( '<b>Note:</b> Untuk penulisan baris baru (↵), gunakan (\n) pada template ucapan.', 'apeiron-kit' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'render_type'     => 'ui',
				'type'            => Controls_Manager::RAW_HTML,
			]
		);

		// Message Templates - Single Repeater with 4 default templates
		$repeater_templates = new Repeater();
		$repeater_templates->add_control(
			'item_label',
			[
				'label'       => __( 'Label Item', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Template 1', 'apeiron-kit' ),
				'label_block' => true,
			]
		);
		$repeater_templates->add_control(
			'item_message',
			[
				'label'       => __( 'Template Ucapan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => '6',
				'default'     => '',
				'label_block' => true,
			]
		);
		$repeater_templates->add_control(
			'item_bg_color',
			[
				'label'   => __( 'Warna Background', 'apeiron-kit' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#083C57',
			]
		);

		$this->add_control(
			'templates',
			[
				'label'       => __( 'Template Ucapan', 'apeiron-kit' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater_templates->get_controls(),
				'default'     => [
					[
						'item_label'    => __( 'Formal', 'apeiron-kit' ),
						'item_message'  => 'Tanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i *[nama]* untuk menghadiri acara kami.\n\n*Berikut link undangan kami*, untuk info lengkap dari acara bisa kunjungi :\n\n[link-undangan]\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\n\n*Mohon maaf perihal undangan hanya di bagikan melalui pesan ini.*\n\nDan agar selalu menjaga kesehatan bersama serta datang pada waktu yang telah ditentukan.\n\nTerima kasih banyak atas perhatiannya.',
						'item_bg_color' => '#083C57',
					],
					[
						'item_label'    => __( 'Muslim', 'apeiron-kit' ),
						'item_message'  => '_Assalamualaikum Warahmatullahi Wabarakatuh_\n\nTanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i *[nama]* untuk menghadiri acara kami.\n\n*Berikut link undangan kami*, untuk info lengkap dari acara bisa kunjungi :\n\n[link-undangan]\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\n\n*Mohon maaf perihal undangan hanya di bagikan melalui pesan ini.*\n\nDan agar selalu menjaga kesehatan bersama serta datang pada waktu yang telah ditentukan.\n\nTerima kasih banyak atas perhatiannya.\n\n_Wassalamualaikum Warahmatullahi Wabarakatuh_',
						'item_bg_color' => '#059669',
					],
					[
						'item_label'    => __( 'Nasrani', 'apeiron-kit' ),
						'item_message'  => 'Kepada Yth.\n*[nama]*\n\nSalam Sejahtera Bagi Kita Semua. Tuhan membuat segala sesuatu indah pada waktunya dan mempersatukan kami dalam suatu ikatan pernikahan kudus, semoga Tuhan memberkati dalam mengiringi pernikahan kami.\n\nTanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i: untuk menghadiri acara kami.\n\nBerikut link undangan kami:\n\n[link-undangan]\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\n\n*Mohon maaf perihal undangan hanya di bagikan melalui pesan ini.*\n\nDan agar selalu menjaga kesehatan bersama serta datang pada waktu yang telah ditentukan. Semoga kita semua diberikan kesehatan dan tetap dibawah lindungan-Nya.\n\nTerima kasih.',
						'item_bg_color' => '#FFFFFF',
					],
					[
						'item_label'    => __( 'Hindu', 'apeiron-kit' ),
						'item_message'  => 'Kepada Yth.\n*[nama]*\n\nOm Swastiastu\n\nTanpa mengurangi rasa hormat, perkenankan kami mengundang Bapak/Ibu/Saudara/i, teman sekaligus sahabat, untuk menghadiri acara pernikahan kami :\n\nBerikut link undangan kami untuk info lengkap dari acara bisa kunjungi :\n\n[link-undangan]\n\nMerupakan suatu kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan untuk hadir dan memberikan doa restu.\n\nMohon maaf perihal undangan hanya di bagikan melalui pesan ini. Dan agar selalu menjaga kesehatan bersama serta datang pada waktu yang telah ditentukan. Terima kasih banyak atas perhatiannya.\n\nOm Shanti, Shanti, Shanti, Om.',
						'item_bg_color' => '#FFFFFF',
					],
				],
				'title_field' => '{{{ item_label }}}',
				'separator'   => 'before',
			]
		);

		$this->end_controls_section();


		// Import Section
		$this->start_controls_section(
			'section_import',
			[
				'label' => __( 'Import Options', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'enable_excel_import',
			[
				'label'        => __( 'Enable Excel Import', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'apeiron-kit' ),
				'label_off'    => __( 'No', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Fitur import Excel menggunakan library SheetJS (xlsx). Pastikan format Excel: Kolom pertama untuk nama, kolom kedua untuk nomor telepon (opsional).', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'download_template_link',
			[
				'label'       => __( 'Link Download Template', 'apeiron-kit' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => 'https://example.com/template.xlsx',
				'default'     => [
					'url' => '',
				],
				'label_block' => true,
				'separator'   => 'before',
				'description' => __( 'Masukkan URL file template Excel untuk diunduh oleh pengguna. Bisa berupa link eksternal atau file media.', 'apeiron-kit' ),
				'condition'   => [
					'enable_excel_import' => 'yes',
				],
			]
		);

		$this->add_control(
			'download_template_label',
			[
				'label'       => __( 'Label Tombol Download', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Download Template', 'apeiron-kit' ),
				'label_block' => true,
				'separator'   => 'before',
				'condition'   => [
					'enable_excel_import' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Layout & Spacing
		// =============================================
		$this->start_controls_section(
			'section_layout_spacing',
			[
				'label' => __( 'Layout & Spacing', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// --- Template Section Spacing ---
		$this->add_control(
			'heading_template_spacing',
			[
				'label' => __( 'Template Section', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_responsive_control(
			'template_section_margin_top',
			[
				'label'      => __( 'Margin Atas Section', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-template-section' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'template_section_margin_bottom',
			[
				'label'      => __( 'Margin Bawah Section', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-template-section' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'template_label_to_buttons_gap',
			[
				'label'      => __( 'Jarak Label ke Tombol', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'default'    => [
					'size' => 5,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-template-section > label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_group_gap',
			[
				'label'      => __( 'Gap Antar Tombol', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'default'    => [
					'size' => 4,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-template-buttons' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_group_margin',
			[
				'label'      => __( 'Margin Tombol', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '20',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-template-buttons' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		// --- Spacing Antar Bagian ---
		$this->add_control(
			'heading_section_spacing',
			[
				'label'     => __( 'Spacing Antar Bagian', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'spacing_between_template_guestlist',
			[
				'label'      => __( 'Jarak Form ke Daftar Tamu', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'default'    => [
					'size' => 20,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-form' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Container Style
		// =============================================
		$this->start_controls_section(
			'section_container_style',
			[
				'label' => __( 'Container Style', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// --- Main Container ---
		$this->add_control(
			'heading_main_container',
			[
				'label' => __( 'Kontainer Utama', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'container_background',
				'label'    => __( 'Background', 'apeiron-kit' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .apeiron-invitation-container',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '#ffffff',
					],
				],
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '28',
					'right'  => '28',
					'bottom' => '28',
					'left'   => '28',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'container_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .apeiron-invitation-container',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width' => [
						'default' => [
							'top'    => '1',
							'right'  => '1',
							'bottom' => '1',
							'left'   => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#0000000D',
					],
				],
			]
		);

		$this->add_responsive_control(
			'container_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => '13',
					'right'  => '13',
					'bottom' => '13',
					'left'   => '13',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Header Konten
		// =============================================
		$this->start_controls_section(
			'section_header_style',
			[
				'label'     => __( 'Header Konten', 'apeiron-kit' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_header' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'header_icon_size',
			[
				'label'      => __( 'Icon Size', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min' => 12,
						'max' => 80,
					],
				],
				'default'    => [
					'size' => 24,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-header-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-header-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_header' => 'yes',
				],
			]
		);

		$this->add_control(
			'header_title_color',
			[
				'label'     => __( 'Warna Judul', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .apeiron-header-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'header_title_typography',
				'label'    => __( 'Typography Judul', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-header-title',
			]
		);

		$this->add_control(
			'header_description_color',
			[
				'label'     => __( 'Warna Deskripsi', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .apeiron-header-description' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'header_description_typography',
				'label'    => __( 'Typography Deskripsi', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-header-description',
			]
		);

		$this->add_responsive_control(
			'header_margin_top',
			[
				'label'      => __( 'Margin Atas', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'separator'  => 'before',
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-header-section' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'header_spacing_bottom',
			[
				'label'      => __( 'Spacing Bawah', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'size' => 24,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-header-section' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Form Fields
		// =============================================
		$this->start_controls_section(
			'section_form_field_style',
			[
				'label' => __( 'Form Fields', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'form_field_typography',
				'selector' => '{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea',
			]
		);

		$this->start_controls_tabs( 'tabs_form_field_style' );

		$this->start_controls_tab(
			'tab_form_field_normal',
			[
				'label' => __( 'Normal', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'form_field_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'form_field_background',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'form_field_border',
				'selector' => '{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width' => [
						'default' => [
							'top'    => '1',
							'right'  => '1',
							'bottom' => '1',
							'left'   => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#e2e8f0',
					],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_form_field_focus',
			[
				'label' => __( 'Focus', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'form_field_focus_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-invitation-container input:focus, {{WRAPPER}} .apeiron-invitation-container textarea:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'form_field_focus_background',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-invitation-container input:focus, {{WRAPPER}} .apeiron-invitation-container textarea:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'form_field_focus_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-invitation-container input:focus, {{WRAPPER}} .apeiron-invitation-container textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'form_field_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'separator'  => 'before',
				'default'    => [
					'top'    => '6',
					'right'  => '6',
					'bottom' => '6',
					'left'   => '6',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'form_field_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-invitation-container input, {{WRAPPER}} .apeiron-invitation-container textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Label
		// =============================================
		$this->start_controls_section(
			'section_label_style',
			[
				'label' => __( 'Label', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typography',
				'label'    => __( 'Label Typography', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-form-label',
			]
		);

		$this->add_control(
			'label_text_color',
			[
				'label'     => __( 'Label Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-form-label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'hint_typography',
				'label'     => __( 'Hint Typography', 'apeiron-kit' ),
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .apeiron-form-hint',
			]
		);

		$this->add_control(
			'hint_text_color',
			[
				'label'     => __( 'Hint Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-form-hint' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'section_title_typography',
				'label'     => __( 'Judul Section Typography', 'apeiron-kit' ),
				'separator' => 'before',
				'selector'  => '{{WRAPPER}} .apeiron-section-title',
			]
		);

		$this->add_control(
			'section_title_color',
			[
				'label'     => __( 'Judul Section Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-section-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// STYLE TAB — Button — Global Style
		// =============================================
		$this->register_button_global_style();

		// =============================================
		// STYLE TAB — Button — Colors (all buttons)
		// =============================================
		$this->register_button_colors_section();

		// =============================================
		// STYLE TAB — Table Style
		// =============================================
		$this->start_controls_section(
			'section_table_style_unified',
			[
				'label' => __( 'Table Style', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// --- Table Container ---
		$this->add_control(
			'heading_table_container',
			[
				'label' => __( 'Kontainer', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'guest_list_background',
				'label'    => __( 'Background', 'apeiron-kit' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .apeiron-guest-list-section',
			]
		);

		$this->add_responsive_control(
			'guest_list_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-guest-list-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'guest_list_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-guest-list-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'guest_list_border',
				'selector' => '{{WRAPPER}} .apeiron-guest-list-section',
			]
		);

		// --- Table Style ---
		$this->add_control(
			'heading_table_style',
			[
				'label'     => __( 'Gaya Tabel', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'table_header_background',
			[
				'label'     => __( 'Background Header', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fafafa',
				'selectors' => [
					'{{WRAPPER}} .apeiron-guest-table thead' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'table_header_color',
			[
				'label'     => __( 'Warna Teks Header', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#64748b',
				'selectors' => [
					'{{WRAPPER}} .apeiron-guest-table thead th' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'table_header_typography',
				'label'    => __( 'Tipografi Header', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-guest-table thead th',
			]
		);

		$this->add_control(
			'table_row_background',
			[
				'label'     => __( 'Warna Baris', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-guest-table tbody tr' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'table_row_hover_background',
			[
				'label'     => __( 'Warna Hover Baris', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f8fafc',
				'selectors' => [
					'{{WRAPPER}} .apeiron-guest-table tbody tr:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'table_body_text_color',
			[
				'label'     => __( 'Warna Teks Body', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#334155',
				'selectors' => [
					'{{WRAPPER}} .apeiron-guest-table tbody td' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'table_border',
				'label'    => __( 'Border Tabel', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-table-wrapper',
				'fields_options' => [
					'border' => [
						'default' => 'none',
					],
				],
			]
		);

		$this->add_responsive_control(
			'table_wrapper_border_radius',
			[
				'label'      => __( 'Border Radius Wrapper', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-table-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register global button style controls (all buttons)
	 */
	protected function register_button_global_style() {
		$this->start_controls_section(
			'section_button_style_grouped',
			[
				'label' => __( 'Button — Global Style', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .apeiron-btn',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .apeiron-btn',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width' => [
						'default' => [
							'top'    => '0',
							'right'  => '0',
							'bottom' => '0',
							'left'   => '0',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#083c57',
					],
				],
			]
		);

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => '6',
					'right'  => '6',
					'bottom' => '6',
					'left'   => '6',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '10',
					'right'  => '26',
					'bottom' => '10',
					'left'   => '26',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-btn',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Register unified button color controls (all buttons in one section)
	 */
	protected function register_button_colors_section() {
		$this->start_controls_section(
			'section_button_colors_unified',
			[
				'label' => __( 'Button — Colors', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// --- Tombol Template ---
		$this->add_control(
			'heading_template_btn_color',
			[
				'label'     => __( 'Tombol Template', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
			]
		);
		$this->start_controls_tabs( 'template_button_color_tabs' );
		$this->start_controls_tab( 'template_button_color_normal', [ 'label' => __( 'Normal', 'apeiron-kit' ) ] );
		$this->add_control( 'template_button_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-template' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'template_button_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-template',
		]);
		$this->end_controls_tab();
		$this->start_controls_tab( 'template_button_color_hover', [ 'label' => __( 'Hover', 'apeiron-kit' ) ] );
		$this->add_control( 'template_button_hover_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-template:hover' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'template_button_hover_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-template:hover',
		]);
		$this->add_control( 'template_button_hover_border_color', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-template:hover' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		// --- Tombol Buat Daftar ---
		$this->add_control(
			'heading_create_btn_color',
			[
				'label'     => __( 'Tombol Buat Daftar', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->start_controls_tabs( 'create_button_color_tabs' );
		$this->start_controls_tab( 'create_button_color_normal', [ 'label' => __( 'Normal', 'apeiron-kit' ) ] );
		$this->add_control( 'create_button_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-create' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'create_button_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-create',
		]);
		$this->end_controls_tab();
		$this->start_controls_tab( 'create_button_color_hover', [ 'label' => __( 'Hover', 'apeiron-kit' ) ] );
		$this->add_control( 'create_button_hover_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-create:hover' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'create_button_hover_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-create:hover',
		]);
		$this->add_control( 'create_button_hover_border_color', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-create:hover' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		// --- Tombol Import Excel ---
		$this->add_control(
			'heading_import_btn_color',
			[
				'label'     => __( 'Tombol Import Excel', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->start_controls_tabs( 'import_excel_button_color_tabs' );
		$this->start_controls_tab( 'import_excel_button_color_normal', [ 'label' => __( 'Normal', 'apeiron-kit' ) ] );
		$this->add_control( 'import_excel_button_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-excel' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'import_excel_button_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-excel',
		]);
		$this->end_controls_tab();
		$this->start_controls_tab( 'import_excel_button_color_hover', [ 'label' => __( 'Hover', 'apeiron-kit' ) ] );
		$this->add_control( 'import_excel_button_hover_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-excel:hover' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'import_excel_button_hover_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-excel:hover',
		]);
		$this->add_control( 'import_excel_button_hover_border_color', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-excel:hover' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		// --- Tombol Download ---
		$this->add_control(
			'heading_download_btn_color',
			[
				'label'     => __( 'Tombol Download', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->start_controls_tabs( 'download_button_color_tabs' );
		$this->start_controls_tab( 'download_button_color_normal', [ 'label' => __( 'Normal', 'apeiron-kit' ) ] );
		$this->add_control( 'download_button_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'default' => '#083c57',
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download' => 'color: {{VALUE}};' ],
		]);
		$this->add_control( 'download_button_background', [
			'label' => __( 'Background Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'default' => '#f8fafc',
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download' => 'background-color: {{VALUE}}; background-image: none;' ],
		]);
		$this->add_control( 'download_button_border_color_normal', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'default' => '#e2e8f0',
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->start_controls_tab( 'download_button_color_hover', [ 'label' => __( 'Hover', 'apeiron-kit' ) ] );
		$this->add_control( 'download_button_hover_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download:hover' => 'color: {{VALUE}};' ],
		]);
		$this->add_control( 'download_button_hover_background', [
			'label' => __( 'Background Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'default' => '#f1f5f9',
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download:hover' => 'background-color: {{VALUE}};' ],
		]);
		$this->add_control( 'download_button_hover_border_color', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-download:hover' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		// --- Tombol Copy ---
		$this->add_control(
			'heading_copy_btn_color',
			[
				'label'     => __( 'Tombol Copy', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->start_controls_tabs( 'copy_button_color_tabs' );
		$this->start_controls_tab( 'copy_button_color_normal', [ 'label' => __( 'Normal', 'apeiron-kit' ) ] );
		$this->add_control( 'copy_button_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-copy' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'copy_button_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-copy',
		]);
		$this->end_controls_tab();
		$this->start_controls_tab( 'copy_button_color_hover', [ 'label' => __( 'Hover', 'apeiron-kit' ) ] );
		$this->add_control( 'copy_button_hover_text_color', [
			'label' => __( 'Text Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-copy:hover' => 'color: {{VALUE}};' ],
		]);
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name' => 'copy_button_hover_background', 'types' => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .apeiron-btn-copy:hover',
		]);
		$this->add_control( 'copy_button_hover_border_color', [
			'label' => __( 'Border Color', 'apeiron-kit' ), 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .apeiron-btn-copy:hover' => 'border-color: {{VALUE}};' ],
		]);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}
		$settings = $this->get_settings_for_display();
		$unique_id = 'apeiron-invitation-' . $this->get_id();

		// Link will be input manually by user in form frontend
		// No need to auto-detect, user must provide the link

		?>
		<div class="apeiron-invitation-container" id="<?php echo esc_attr( $unique_id ); ?>">
			<?php if ( 'yes' === $settings['show_header'] ) : ?>
			<!-- Header Section -->
			<div class="apeiron-header-section">
				<?php if ( ! empty( $settings['header_icon']['value'] ) ) : ?>
				<div class="apeiron-header-icon">
					<?php \Elementor\Icons_Manager::render_icon( $settings['header_icon'], [ 'aria-hidden' => 'true' ] ); ?>
				</div>
				<?php endif; ?>
				<div class="apeiron-header-text">
					<?php if ( ! empty( $settings['header_title'] ) ) : ?>
					<h2 class="apeiron-header-title"><?php echo esc_html( $settings['header_title'] ); ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $settings['header_description'] ) ) : ?>
					<p class="apeiron-header-description"><?php echo esc_html( $settings['header_description'] ); ?></p>
					<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>

			<div class="apeiron-invitation-wrapper">
				
				<!-- Input Form -->
				<div class="apeiron-invitation-form">
					<div class="apeiron-form-group">
						<label class="apeiron-form-label" for="invitation_link_input_<?php echo esc_attr( $this->get_id() ); ?>">
							<?php echo esc_html( ! empty( $settings['invitation_link_label'] ) ? $settings['invitation_link_label'] : __( 'Link Undangan', 'apeiron-kit' ) ); ?>
						</label>
						<p class="apeiron-form-hint">
							<?php echo esc_html( ! empty( $settings['invitation_link_hint'] ) ? $settings['invitation_link_hint'] : __( '* Masukkan link undangan Anda. Contoh: apeiron.id/ika-budi atau https://apeiron.id/ika-budi', 'apeiron-kit' ) ); ?>
						</p>
						<input 
							type="text" 
							id="invitation_link_input_<?php echo esc_attr( $this->get_id() ); ?>"
							class="apeiron-form-input apeiron-invitation-link-input" 
							placeholder="<?php echo esc_attr( ! empty( $settings['invitation_link_placeholder'] ) ? $settings['invitation_link_placeholder'] : __( 'Contoh: apeiron.id/ika-budi', 'apeiron-kit' ) ); ?>"
							required
						>
					</div>

					<div class="apeiron-form-group">
						<label class="apeiron-form-label" for="guest_names_<?php echo esc_attr( $this->get_id() ); ?>">
							<?php echo esc_html__( 'Masukkan Nama Tamu', 'apeiron-kit' ); ?>
						</label>
						<p class="apeiron-form-hint">
							<?php echo esc_html__( '* Gunakan baris baru (↵) untuk memisahkan nama yang akan Anda undang.', 'apeiron-kit' ); ?>
						</p>
						<textarea 
							id="guest_names_<?php echo esc_attr( $this->get_id() ); ?>"
							class="apeiron-form-input apeiron-guest-names" 
							rows="5" 
							placeholder="<?php echo esc_attr( ! empty( $settings['guest_names_placeholder'] ) ? $settings['guest_names_placeholder'] : __( 'Nama Tamu', 'apeiron-kit' ) ); ?>"
						></textarea>
					</div>

					<?php if ( 'yes' === $settings['enable_excel_import'] ) : ?>
					<div class="apeiron-import-section">
						<label class="apeiron-form-label">
							<?php echo esc_html__( 'Import dari Excel', 'apeiron-kit' ); ?>
						</label>
						<!-- Drag & Drop Zone -->
						<div class="apeiron-dropzone" id="dropzone_<?php echo esc_attr( $this->get_id() ); ?>">
							<input 
								type="file" 
								id="import_excel_<?php echo esc_attr( $this->get_id() ); ?>" 
								class="apeiron-file-input apeiron-dropzone-input" 
								accept=".xlsx,.xls"
							>
							<div class="apeiron-dropzone-content">
								<div class="apeiron-dropzone-icon">
									<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0d9e6d" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>
								</div>
								<p class="apeiron-dropzone-text"><?php echo esc_html__( 'Klik atau drop file Excel di sini', 'apeiron-kit' ); ?></p>
								<p class="apeiron-dropzone-hint"><?php echo esc_html__( 'Format: Kolom 1 untuk Nama, Kolom 2 untuk No. Telepon (Opsional)', 'apeiron-kit' ); ?></p>
							</div>
						</div>
						<!-- Action Buttons Row -->
						<div class="apeiron-import-actions">
							<?php
							$download_link = $settings['download_template_link'];
							if ( ! empty( $download_link['url'] ) ) :
								$download_label = ! empty( $settings['download_template_label'] ) ? esc_html( $settings['download_template_label'] ) : esc_html__( 'Download Template', 'apeiron-kit' );
								$download_target = ! empty( $download_link['is_external'] ) ? ' target="_blank"' : '';
								$download_nofollow = ! empty( $download_link['nofollow'] ) ? ' rel="nofollow"' : '';
							?>
							<a 
								href="<?php echo esc_url( $download_link['url'] ); ?>"
								class="apeiron-btn apeiron-guest-btn btn-download apeiron-btn-download"
								<?php echo wp_kses_post( $download_target . $download_nofollow ); ?>
							>
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
								<?php echo $download_label; ?>
							</a>
							<?php endif; ?>
							<button 
								type="button" 
								class="apeiron-btn apeiron-guest-btn btn-import apeiron-btn-excel"
								onclick="apeironImportExcel('<?php echo esc_attr( $this->get_id() ); ?>')"
							>
								<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:6px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
								<?php echo esc_html__( 'Proses Import Excel', 'apeiron-kit' ); ?>
							</button>
						</div>
					</div>
					<?php endif; ?>

					<div class="apeiron-template-section">
						<label class="apeiron-form-label" for="message_template_<?php echo esc_attr( $this->get_id() ); ?>">
							<?php echo esc_html__( 'Pilih Template Ucapan', 'apeiron-kit' ); ?>
						</label>
						
						<div class="apeiron-template-buttons">
							<?php 
							// Template Repeater Items - Single repeater with all templates
							if ( ! empty( $settings['templates'] ) ) : 
								foreach ( $settings['templates'] as $index => $item ) :
									$item_id = 'template_' . $index;
									$bg_color = ! empty( $item['item_bg_color'] ) ? esc_attr( $item['item_bg_color'] ) : '#083C57';
									$item_message = isset( $item['item_message'] ) ? $item['item_message'] : '';
									$item_label = ! empty( $item['item_label'] ) ? esc_html( $item['item_label'] ) : sprintf( __( 'Ucapan %d', 'apeiron-kit' ), $index + 1 );
									// Auto-detect text color based on background
									$text_color = '#FFFFFF';
									$border_color = 'transparent';
									$bg_upper = strtoupper( trim( $bg_color ) );
									if ( $bg_upper === '#FFFFFF' || $bg_upper === '#FFF' ) {
										$text_color = '#083C57';
										$border_color = '#E2E8F0';
									}
							?>
								<button 
									type="button" 
									class="apeiron-btn apeiron-guest-btn btn-template apeiron-btn-template"
									data-template-index="<?php echo esc_attr( $index ); ?>"
									data-bg="<?php echo esc_attr( $bg_color ); ?>"
									data-color="<?php echo esc_attr( $text_color ); ?>"
									data-border="<?php echo esc_attr( $border_color ); ?>"
									data-widget-id="<?php echo esc_attr( $this->get_id() ); ?>"
									data-template-id="<?php echo esc_attr( $item_id ); ?>"
									data-message="<?php echo esc_attr( str_replace( [ "\n", "\r" ], [ '\\n', '' ], $item_message ) ); ?>"
								>
									<?php echo $item_label; ?>
								</button>
							<?php 
								endforeach;
							endif;
							?>
						</div>

						<textarea 
							id="message_template_<?php echo esc_attr( $this->get_id() ); ?>"
							class="apeiron-form-input apeiron-message-template" 
							rows="15" 
							placeholder="<?php echo esc_attr( ! empty( $settings['message_template_placeholder'] ) ? $settings['message_template_placeholder'] : __( 'Template ucapan akan muncul di sini...', 'apeiron-kit' ) ); ?>"
						></textarea>
					</div>

					<div class="apeiron-form-actions">
						<button 
							type="button" 
							class="apeiron-btn apeiron-guest-btn btn-register apeiron-btn-create"
							onclick="apeironCreateGuestList('<?php echo esc_attr( $this->get_id() ); ?>')"
						>
							<?php echo esc_html__( 'Buat Daftar Nama Tamu', 'apeiron-kit' ); ?>
						</button>
					</div>
				</div>

			<?php if ( 'yes' === $settings['show_guest_list'] ) : ?>
				<!-- Guest List -->
				<div class="apeiron-guest-list-section">
					<h3 class="apeiron-section-title">
						<?php echo esc_html( ! empty( $settings['guest_list_title'] ) ? $settings['guest_list_title'] : __( 'Daftar Nama Tamu', 'apeiron-kit' ) ); ?>
					</h3>
					<div class="apeiron-table-wrapper">
						<table class="apeiron-guest-table">
							<thead>
								<tr>
									<th><?php echo esc_html( ! empty( $settings['table_label_no'] ) ? $settings['table_label_no'] : __( 'No', 'apeiron-kit' ) ); ?></th>
									<th><?php echo esc_html( ! empty( $settings['table_label_guest'] ) ? $settings['table_label_guest'] : __( 'Nama Tamu', 'apeiron-kit' ) ); ?></th>
									<th><?php echo esc_html( ! empty( $settings['table_label_option'] ) ? $settings['table_label_option'] : __( 'Opsi', 'apeiron-kit' ) ); ?></th>
								</tr>
							</thead>
							<tbody id="guest_list_<?php echo esc_attr( $this->get_id() ); ?>">
								<tr class="apeiron-empty-state">
									<td colspan="3">
										<?php echo esc_html__( 'Belum ada daftar tamu. Silakan buat daftar terlebih dahulu.', 'apeiron-kit' ); ?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			<?php endif; ?>

			</div>
		</div>

		<?php
	}
}

