(function ($) {
    'use strict';

    const StickerPicker = {
        init() {
            // Initialize sticker pickers
            const initPicker = (picker) => {
                const field = picker.closest('.apeiron-kit-sticker-field');
                if (!field) {
                    return;
                }

                const inputSrc = field.querySelector('input[name="sticker_src"]');
                const inputType = field.querySelector('input[name="sticker_type"]');
                if (!inputSrc || !inputType) {
                    return;
                }

                // Remove existing listeners to avoid duplicates
                const options = picker.querySelectorAll('.apeiron-kit-sticker-option');
                options.forEach((btn) => {
                    // Clone button to remove all event listeners
                    const newBtn = btn.cloneNode(true);
                    btn.parentNode.replaceChild(newBtn, btn);
                });

                // Add click listeners to all sticker options
                picker.querySelectorAll('.apeiron-kit-sticker-option').forEach((btn) => {
                    btn.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();

                        const alreadySelected = this.classList.contains('is-selected');

                        // Remove selection from all options
                        picker.querySelectorAll('.apeiron-kit-sticker-option.is-selected').forEach((active) => {
                            active.classList.remove('is-selected');
                        });

                        if (alreadySelected) {
                            inputSrc.value = '';
                            inputType.value = '';
                            return;
                        }

                        // Select this option
                        this.classList.add('is-selected');
                        inputSrc.value = this.dataset.src || '';
                        inputType.value = this.dataset.type || 'image';
                    });
                });
            };

            // Initialize all existing pickers
            document.querySelectorAll('.apeiron-kit-sticker-picker').forEach(initPicker);

            // Also use event delegation as fallback (register only once)
            if (StickerPicker._delegationInit) return;
            StickerPicker._delegationInit = true;

            document.addEventListener('click', (event) => {
                const btn = event.target.closest('.apeiron-kit-sticker-option');
                if (!btn) {
                    return;
                }

                const picker = btn.closest('.apeiron-kit-sticker-picker');
                if (!picker) {
                    return;
                }

                const field = picker.closest('.apeiron-kit-sticker-field');
                const inputSrc = field ? field.querySelector('input[name="sticker_src"]') : null;
                const inputType = field ? field.querySelector('input[name="sticker_type"]') : null;
                if (!inputSrc || !inputType) {
                    return;
                }

                // Only handle if not already handled by direct listener
                if (!event.defaultPrevented) {
                    event.preventDefault();
                    event.stopPropagation();

                    const alreadySelected = btn.classList.contains('is-selected');
                    picker.querySelectorAll('.apeiron-kit-sticker-option.is-selected').forEach((active) => active.classList.remove('is-selected'));

                    if (alreadySelected) {
                        inputSrc.value = '';
                        inputType.value = '';
                        return;
                    }

                    btn.classList.add('is-selected');
                    inputSrc.value = btn.dataset.src || '';
                    inputType.value = btn.dataset.type || 'image';
                }
            }, true);
        },
    };

    const Comments = {
        parseMap(dock) {
            if (!dock || !dock.dataset.attendanceMap) {
                return {};
            }
            try {
                return JSON.parse(dock.dataset.attendanceMap);
            } catch (e) {
                return {};
            }
        },

        buildBadge(item, map, display) {
            const meta = item.attendanceValue && map[item.attendanceValue] ? map[item.attendanceValue] : null;
            const label = (meta && meta.label) || item.attendanceLabel;
            const hasLabel = 'icon' !== display && !!label;

            if (!label && !meta) {
                return '';
            }

            // Guard: if no icon and no label to show, skip
            const hasIcon = meta && meta.icon;
            if (!hasIcon && !hasLabel) {
                return '';
            }

            const pill = document.createElement('span');
            pill.className = 'apeiron-kit-comment-pill';

            // Match PHP: add is-icon-only OR is-icon-text
            if ('icon' === display) {
                pill.classList.add('is-icon-only');
            } else {
                pill.classList.add('is-icon-text');
            }

            // Match PHP: add status-index-* class for Bridge Kehadiran color system
            if (meta && typeof meta.index === 'number' && meta.index >= 0) {
                if (meta.index <= 2) {
                    pill.classList.add('status-index-' + meta.index);
                } else {
                    pill.classList.add('status-index-3-plus');
                }
            }

            // Use CSS custom properties for per-item colors (matches PHP render)
            const vars = [];
            if (meta) {
                if (meta.pill_background) {
                    vars.push('--pill-bg:' + meta.pill_background);
                }
                if (meta.pill_color) {
                    vars.push('--pill-color:' + meta.pill_color);
                }
                if (meta.icon_color) {
                    vars.push('--pill-icon-color:' + meta.icon_color);
                }
            }
            if (vars.length) {
                pill.setAttribute('style', vars.join(';'));
            }

            // Match PHP: icon or dot fallback
            if (hasIcon && meta.icon) {
                const icon = document.createElement('span');
                icon.className = 'apeiron-kit-comment-pill-icon';
                icon.innerHTML = meta.icon; // Safe: sourced from server-side Icons_Manager render in data-attendance-map
                pill.appendChild(icon);
            } else if (label) {
                // Dot fallback when icon is empty but label exists (matches PHP pill-dot)
                const dotWrap = document.createElement('span');
                dotWrap.className = 'apeiron-kit-comment-pill-icon';
                const dot = document.createElement('span');
                dot.className = 'apeiron-kit-comment-pill-dot';
                dotWrap.appendChild(dot);
                pill.appendChild(dotWrap);
            }

            if (hasLabel) {
                const text = document.createElement('span');
                text.className = 'apeiron-kit-comment-pill-text';
                text.textContent = label;
                pill.appendChild(text);
            }

            return pill.outerHTML;
        },

        formatDate(timestamp, formatType) {
            if (!timestamp) {
                return '';
            }

            // If timestamp is already a string (old format), try to parse it or return as is
            if (typeof timestamp === 'string') {
                // Try to parse if it looks like a date string
                const parsed = Date.parse(timestamp);
                if (!isNaN(parsed)) {
                    timestamp = Math.floor(parsed / 1000);
                } else {
                    // If it's already formatted, return as is
                    return timestamp;
                }
            }

            // Ensure timestamp is a number
            if (typeof timestamp !== 'number') {
                timestamp = parseInt(timestamp, 10);
            }

            // If still invalid, return empty
            if (isNaN(timestamp) || timestamp <= 0) {
                return '';
            }

            const now = Math.floor(Date.now() / 1000);
            const diff = now - timestamp;

            // Normalize formatType
            const format = formatType || 'relative';

            if (format === 'relative') {
                return Comments.getRelativeTime(diff);
            }

            if (format === 'custom') {
                const date = new Date(timestamp * 1000);
                const day = date.getDate();
                const months = [
                    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
                    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
                ];
                const month = months[date.getMonth()];
                const year = date.getFullYear();
                return `${day} ${month} ${year}`;
            }

            // Default: format as standard date
            const date = new Date(timestamp * 1000);
            return date.toLocaleDateString('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        },

        getRelativeTime(diff) {
            if (diff < 60) {
                return 'Baru saja';
            }

            const minutes = Math.floor(diff / 60);
            if (minutes < 60) {
                return `${minutes} menit yang lalu`;
            }

            const hours = Math.floor(diff / 3600);
            if (hours < 24) {
                return `${hours} jam yang lalu`;
            }

            const days = Math.floor(diff / 86400);
            if (days < 7) {
                return `${days} hari yang lalu`;
            }

            const weeks = Math.floor(days / 7);
            if (weeks < 4) {
                return `${weeks} minggu yang lalu`;
            }

            const months = Math.floor(days / 30);
            if (months < 12) {
                return `${months} bulan yang lalu`;
            }

            const years = Math.floor(days / 365);
            return `${years} tahun yang lalu`;
        },

        renderItem(item, map, display, dateFormat = 'relative', dockElement = null) {
            const li = document.createElement('li');
            li.className = 'apeiron-kit-comment-item';

            const wrapper = document.createElement('div');
            wrapper.className = 'apeiron-kit-comment-wrapper';

            const avatar = document.createElement('div');
            avatar.className = 'apeiron-kit-comment-avatar';
            if (item.sticker && item.sticker.src) {
                avatar.classList.add('has-sticker');
                const media = Comments.buildStickerMedia(item.sticker, item.name, dockElement);
                if (media) {
                    avatar.appendChild(media);
                }
            } else {
                const avatarImg = document.createElement('img');
                // Fallback chain (matches PHP render_comment_avatar exactly):
                // 1. Elementor custom default avatar (from widget setting)
                // 2. Plugin asset avatar (man-avatar.webp via ApeironKit global)
                // Note: item.avatar (Gravatar) is intentionally excluded to match PHP behavior
                const defaultAvatar = dockElement ? (dockElement.dataset.defaultAvatar || '') : '';
                const pluginAvatar = (typeof ApeironKit !== 'undefined' && ApeironKit.defaultAvatarUrl) ? ApeironKit.defaultAvatarUrl : '';
                avatarImg.src = defaultAvatar || pluginAvatar || '';
                avatarImg.alt = item.name || 'avatar';
                avatar.appendChild(avatarImg);
            }
            wrapper.appendChild(avatar);

            const content = document.createElement('div');
            content.className = 'apeiron-kit-comment-content';

            const info = document.createElement('div');
            info.className = 'apeiron-kit-comment-info';

            const author = document.createElement('span');
            author.className = 'apeiron-kit-comment-author';
            author.textContent = item.name;
            info.appendChild(author);

            const badge = Comments.buildBadge(item, map, display);
            if (badge) {
                info.insertAdjacentHTML('beforeend', badge);
            }

            content.appendChild(info);

            const text = document.createElement('div');
            text.className = 'apeiron-kit-comment-text';
            text.innerHTML = item.message; // Safe: server already sanitized via wp_kses_post()
            content.appendChild(text);

            if (item.createdAt) {
                const time = document.createElement('span');
                time.className = 'apeiron-kit-comment-time';
                time.textContent = Comments.formatDate(item.createdAt, dateFormat) || '';
                content.appendChild(time);
            }

            wrapper.appendChild(content);
            li.appendChild(wrapper);

            return li;
        },

        buildStickerMedia(sticker, name, dockElement) {
            if (!sticker || !sticker.src) {
                return null;
            }

            // Get sticker avatar size from CSS variable or default to 50px
            let stickerSize = '50px';
            if (dockElement) {
                try {
                    const computedStyle = window.getComputedStyle(dockElement);
                    const cssSize = computedStyle.getPropertyValue('--apeiron-sticker-avatar-size').trim();
                    if (cssSize) {
                        stickerSize = cssSize;
                    }
                } catch (e) {
                    // Fallback to default if error
                }
            }

            const stickerWrapper = document.createElement('span');
            stickerWrapper.className = 'apeiron-kit-comment-sticker';
            stickerWrapper.style.width = stickerSize;
            stickerWrapper.style.height = stickerSize;

            if (sticker.type === 'video') {
                const video = document.createElement('video');
                video.src = sticker.src;
                video.autoplay = true;
                video.loop = true;
                video.muted = true;
                video.playsInline = true;
                video.className = 'apeiron-kit-sticker-avatar';
                stickerWrapper.appendChild(video);
            } else {
                const img = document.createElement('img');
                img.src = sticker.src;
                img.alt = name || 'sticker';
                img.className = 'apeiron-kit-sticker-avatar';
                stickerWrapper.appendChild(img);
            }

            return stickerWrapper;
        },

        initPagination() {
            document.querySelectorAll('.apeiron-kit-comment-pagination').forEach((pagination) => {
                if (pagination.dataset.initialized === 'yes') {
                    return;
                }
                pagination.dataset.initialized = 'yes';

                const list = pagination.previousElementSibling;
                if (!list || !list.classList.contains('apeiron-kit-comment-list')) {
                    return;
                }

                const items = Array.from(list.querySelectorAll('.apeiron-kit-comment-item'));
                const total = parseInt(pagination.dataset.total || items.length, 10);
                const perPage = parseInt(pagination.dataset.perPage || 5, 10);
                const totalPages = Math.ceil(total / perPage);
                let currentPage = parseInt(pagination.dataset.current || 1, 10);

                const prevBtn = pagination.querySelector('.apeiron-kit-comment-prev');
                const nextBtn = pagination.querySelector('.apeiron-kit-comment-next');
                const currentSpan = pagination.querySelector('.apeiron-kit-comment-page-current');
                const totalSpan = pagination.querySelector('.apeiron-kit-comment-page-total');

                if (totalSpan) {
                    totalSpan.textContent = totalPages;
                }

                const showPage = (page) => {
                    currentPage = Math.max(1, Math.min(page, totalPages));
                    const start = (currentPage - 1) * perPage;
                    const end = start + perPage;

                    items.forEach((item, index) => {
                        if (index >= start && index < end) {
                            item.style.display = '';
                        } else {
                            item.style.display = 'none';
                        }
                    });

                    if (prevBtn) {
                        prevBtn.disabled = currentPage <= 1;
                    }
                    if (nextBtn) {
                        nextBtn.disabled = currentPage >= totalPages;
                    }
                    if (currentSpan) {
                        currentSpan.textContent = currentPage;
                    }
                    pagination.dataset.current = currentPage;
                };

                if (prevBtn) {
                    prevBtn.addEventListener('click', () => {
                        if (currentPage > 1) {
                            showPage(currentPage - 1);
                        }
                    });
                }

                if (nextBtn) {
                    nextBtn.addEventListener('click', () => {
                        if (currentPage < totalPages) {
                            showPage(currentPage + 1);
                        }
                    });
                }

                showPage(currentPage);
            });
        },

        init() {
            document.querySelectorAll('[data-apeiron-comment-form]').forEach((form) => {
                // Guard: skip if already initialized to prevent duplicate listeners
                if (form._apeironCommentInit) return;
                form._apeironCommentInit = true;

                const dock = form.closest('.apeiron-comment-dock');
                const map = Comments.parseMap(dock);
                const display = dock ? dock.dataset.attendanceDisplay : 'icon';
                // Read date format from data attribute, ensure it's properly read
                let dateFormat = 'relative';
                if (dock && dock.dataset.dateFormat) {
                    dateFormat = dock.dataset.dateFormat;
                } else if (dock) {
                    // Try reading from attribute directly
                    const attrFormat = dock.getAttribute('data-date-format');
                    if (attrFormat) {
                        dateFormat = attrFormat;
                    }
                }

                form.addEventListener('submit', (event) => {
                    event.preventDefault();
                    // Prevent double submit while request is in-flight
                    if (form.classList.contains('is-loading')) return;
                    const select = form.querySelector('select[name="attendance"]');
                    const labelInput = form.querySelector('input[name="attendance_label"]');
                    if (select && labelInput) {
                        const option = select.options[select.selectedIndex];
                        labelInput.value = option ? option.text : '';
                    }

                    const data = new FormData(form);
                    const payload = Object.fromEntries(data.entries());
                    form.classList.add('is-loading');
                    const list = dock ? dock.querySelector('.apeiron-kit-comment-list') : null;

                    fetch(
                        `${ApeironKit.restUrl}/comments`,
                        {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-WP-Nonce': ApeironKit.nonce,
                            },
                            body: JSON.stringify(payload),
                        }
                    )
                        .then((response) => {
                            if (!response.ok) {
                                throw new Error('Invalid response');
                            }
                            return response.json();
                        })
                        .then((result) => {
                            form.reset();
                            const stickerField = form.querySelector('.apeiron-kit-sticker-field');
                            if (stickerField) {
                                stickerField.querySelectorAll('.apeiron-kit-sticker-option.is-selected').forEach((btn) => btn.classList.remove('is-selected'));
                                const hiddenSrc = stickerField.querySelector('input[name="sticker_src"]');
                                const hiddenType = stickerField.querySelector('input[name="sticker_type"]');
                                if (hiddenSrc) hiddenSrc.value = '';
                                if (hiddenType) hiddenType.value = '';
                            }
                            const notice = document.createElement('div');
                            notice.className = 'apeiron-kit-comment-notice';
                            notice.setAttribute('role', 'alert');
                            notice.setAttribute('aria-live', 'polite');
                            notice.textContent = result.message || form.dataset.successMessage || 'Terima kasih atas ucapannya!';
                            form.appendChild(notice);
                            setTimeout(() => notice.remove(), 4000);

                            if (result.comment && list) {
                                const finalDateFormat = dateFormat || 'relative';
                                const item = Comments.renderItem(result.comment, map, display, finalDateFormat, dock);
                                list.prepend(item);

                                // Check if list needs scrollable class
                                const limit = parseInt(dock ? (dock.dataset.commentsLimit || 10) : 10, 10);
                                const allItems = Array.from(list.querySelectorAll('.apeiron-kit-comment-item'));

                                // Add scrollable class if comments exceed limit
                                if (allItems.length > limit && !list.classList.contains('apeiron-kit-comment-list-scrollable')) {
                                    list.classList.add('apeiron-kit-comment-list-scrollable');
                                }

                                const pagination = dock ? dock.querySelector('.apeiron-kit-comment-pagination') : null;
                                if (pagination) {
                                    const total = parseInt(pagination.dataset.total || 0, 10) + 1;
                                    pagination.dataset.total = total;
                                    pagination.dataset.initialized = 'no';
                                    const perPage = parseInt(pagination.dataset.perPage || 5, 10);
                                    const totalPages = Math.ceil(total / perPage);
                                    const totalSpan = pagination.querySelector('.apeiron-kit-comment-page-total');
                                    if (totalSpan) {
                                        totalSpan.textContent = totalPages;
                                    }

                                    // Show pagination if it was hidden and now has enough items
                                    if (total > perPage && pagination.style.display === 'none') {
                                        pagination.style.display = '';
                                    }

                                    const items = Array.from(list.querySelectorAll('.apeiron-kit-comment-item'));
                                    items.forEach((item, index) => {
                                        if (index < perPage) {
                                            item.style.display = '';
                                        } else {
                                            item.style.display = 'none';
                                        }
                                    });
                                    pagination.dataset.current = '1';
                                    const prevBtn = pagination.querySelector('.apeiron-kit-comment-prev');
                                    const nextBtn = pagination.querySelector('.apeiron-kit-comment-next');
                                    const currentSpan = pagination.querySelector('.apeiron-kit-comment-page-current');
                                    if (prevBtn) prevBtn.disabled = true;
                                    if (nextBtn) nextBtn.disabled = totalPages <= 1;
                                    if (currentSpan) currentSpan.textContent = '1';
                                    Comments.initPagination();
                                }
                            }
                        })
                        .catch(() => {
                            const errNotice = document.createElement('div');
                            errNotice.className = 'apeiron-kit-comment-notice';
                            errNotice.setAttribute('role', 'alert');
                            errNotice.setAttribute('aria-live', 'assertive');
                            errNotice.style.background = '#fef2f2';
                            errNotice.style.color = '#991b1b';
                            errNotice.style.borderColor = '#fecaca';
                            errNotice.textContent = form.dataset.errorMessage || 'Gagal mengirim komentar.';
                            form.appendChild(errNotice);
                            setTimeout(() => errNotice.remove(), 4000);
                        })
                        .finally(() => form.classList.remove('is-loading'));
                });
            });
        },
    };

    document.addEventListener(
        'DOMContentLoaded',
        function () {
            StickerPicker.init();
            Comments.init();
            Comments.initPagination();
        }
    );

    // Elementor Editor Integration
    jQuery(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-comment-dock.default',
                function ($scope) {
                    var el = $scope[0] || $scope;
                    if (!el) return;
                    // Reset init flags within THIS scope so re-init works after Elementor re-render
                    el.querySelectorAll('[data-apeiron-comment-form]').forEach(function (form) {
                        form._apeironCommentInit = false;
                    });
                    Comments.init();
                    Comments.initPagination();
                    StickerPicker.init();
                }
            );
        }
    });
}(jQuery));
