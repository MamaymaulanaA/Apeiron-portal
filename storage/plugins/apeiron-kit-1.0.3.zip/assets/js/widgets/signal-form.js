(function ($) {
    'use strict';

    const SignalForm = {
        init() {
            document.querySelectorAll('[data-apeiron-wa-form]').forEach((wrapper) => {
                const form = wrapper.querySelector('form');
                if (!form || form._apeironSignalInit) {
                    return;
                }
                form._apeironSignalInit = true;
                let config = {};
                try {
                    config = JSON.parse(wrapper.getAttribute('data-apeiron-wa-form') || '{}');
                } catch (e) {
                    config = {};
                }

                form.addEventListener('submit', (event) => {
                    event.preventDefault();
                    const formData = new FormData(form);
                    let template = config.template || '';
                    formData.forEach((value, key) => {
                        const token = new RegExp(`\\[${key}\\]`, 'gi');
                        template = template.replace(token, value);
                    });
                    const phone = (config.phone || '').replace(/\D/g, '');
                    const waUrl = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(template)}`;
                    window.open(waUrl, '_blank');
                });
            });
        },
    };

    document.addEventListener(
        'DOMContentLoaded',
        function () {
            SignalForm.init();
        }
    );

    // Elementor Editor Integration
    jQuery(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-signal-form.default',
                function ($scope) {
                    var el = $scope[0] || $scope;
                    if (!el) return;
                    // Re-init Signal Form (WhatsApp form) within scope
                    el.querySelectorAll('[data-apeiron-wa-form]').forEach(function (wrapper) {
                        var form = wrapper.querySelector('form');
                        if (!form || form._apeironSignalInit) return;
                        form._apeironSignalInit = true;
                        var config = {};
                        try { config = JSON.parse(wrapper.getAttribute('data-apeiron-wa-form') || '{}'); } catch (e) { config = {}; }
                        form.addEventListener('submit', function (event) {
                            event.preventDefault();
                            var formData = new FormData(form);
                            var template = config.template || '';
                            formData.forEach(function (value, key) {
                                var token = new RegExp('\\[' + key + '\\]', 'gi');
                                template = template.replace(token, value);
                            });
                            var phone = (config.phone || '').replace(/\D/g, '');
                            var waUrl = 'https://api.whatsapp.com/send?phone=' + phone + '&text=' + encodeURIComponent(template);
                            window.open(waUrl, '_blank');
                        });
                    });
                }
            );
        }
    });
}(jQuery));
