/**
 * Apeiron Kit - Admin License JavaScript
 *
 * Handles license management, server configuration, and related AJAX operations.
 *
 * @package ApeironKit
 * @since 1.0.0
 */

(function ($) {
    'use strict';

    var ApeironLicense = {
        nonce: '',
        apiKeyRequired: true,
        hasApiKey: false,
        currentApiUrl: '',
        currentLicenseKey: '',

        /**
         * Initialize the license management module
         */
        init: function (config) {
            this.nonce = config.nonce || '';
            this.apiKeyRequired = config.apiKeyRequired !== false;
            this.hasApiKey = config.hasApiKey === true;
            this.currentApiUrl = config.currentApiUrl || '';
            this.currentLicenseKey = config.currentLicenseKey || '';

            this.bindEvents();
        },

        /**
         * Bind all event handlers
         */
        bindEvents: function () {
            var self = this;

            // Toggle license key input visibility
            $('#show-license-key-checkbox').on('change', function () {
                $('#license-key-input-wrapper').slideToggle(200);
            });

            // Save server configuration (legacy button)
            $('#save-server-config-btn').on('click', function () {
                self.saveServerConfig($(this));
            });

            // Save API Key only (new button)
            $('#save-api-key-btn').on('click', function () {
                self.saveServerConfig($(this));
            });

            // Activate license
            $('#license-activate-btn').on('click', function () {
                self.activateLicense($(this));
            });

            // Check license status
            $('#license-check-btn').on('click', function () {
                self.checkLicense($(this));
            });

            // Deactivate license
            $('#license-deactivate-btn').on('click', function () {
                self.deactivateLicense($(this));
            });

            // Test server connection
            $('#test-server-connection-btn').on('click', function () {
                self.testConnection($(this));
            });
        },

        /**
         * Save server configuration
         */
        saveServerConfig: function ($btn) {
            var self = this;
            var apiUrl = $('#api-url-input').val().trim();
            var apiKey = $('#api-key-input').val().trim();

            if (!apiUrl) {
                apiUrl = this.currentApiUrl;
            }

            if (!apiUrl) {
                this.showToast('#server-config-message', 'error', ApeironLicenseL10n.enterServerUrl);
                return;
            }

            if (apiUrl.indexOf('https://') !== 0) {
                this.showToast('#server-config-message', 'error', ApeironLicenseL10n.httpsRequired);
                return;
            }

            if (this.apiKeyRequired && !apiKey && !this.hasApiKey) {
                this.showToast('#server-config-message', 'error', ApeironLicenseL10n.enterApiKey);
                return;
            }

            this.setButtonLoading($btn, ApeironLicenseL10n.saving);

            $.post(ajaxurl, {
                action: 'apeiron_save_server_config',
                api_url: apiUrl,
                api_key: apiKey,
                nonce: this.nonce
            }, function (res) {
                if (res.success) {
                    self.showToast('#server-config-message', 'success', res.data.message || ApeironLicenseL10n.saved);
                    setTimeout(function () { location.reload(); }, 1200);
                } else {
                    self.showToast('#server-config-message', 'error', res.data.message || ApeironLicenseL10n.saveFailed);
                    self.resetButton($btn, 'dashicons-cloud-saved', ApeironLicenseL10n.saveConfig);
                }
            }).fail(function () {
                self.showToast('#server-config-message', 'error', ApeironLicenseL10n.error);
                self.resetButton($btn, 'dashicons-cloud-saved', ApeironLicenseL10n.saveConfig);
            });
        },

        /**
         * Activate license
         */
        activateLicense: function ($btn) {
            var self = this;
            var $input = $('#license-key-input');
            var licenseKey = $input.length && $input.is(':visible') ? $input.val().trim() : this.currentLicenseKey;

            if (!licenseKey) {
                this.showToast('#license-message', 'error', ApeironLicenseL10n.enterLicenseKey);
                return;
            }

            this.setButtonLoading($btn, ApeironLicenseL10n.activating);

            $.post(ajaxurl, {
                action: 'apeiron_activate_license',
                license_key: licenseKey,
                nonce: this.nonce
            }, function (res) {
                if (res.success) {
                    self.showToast('#license-message', 'success', res.data.message || ApeironLicenseL10n.activated);
                    setTimeout(function () { location.reload(); }, 1200);
                } else {
                    self.showToast('#license-message', 'error', res.data.message || ApeironLicenseL10n.activateFailed);
                    self.resetButton($btn, 'dashicons-update', ApeironLicenseL10n.activateChange);
                }
            }).fail(function () {
                self.showToast('#license-message', 'error', ApeironLicenseL10n.error);
                self.resetButton($btn, 'dashicons-update', ApeironLicenseL10n.activateChange);
            });
        },

        /**
         * Check license status
         */
        checkLicense: function ($btn) {
            var self = this;

            this.setButtonLoading($btn, ApeironLicenseL10n.checking);

            $.post(ajaxurl, {
                action: 'apeiron_check_license',
                nonce: this.nonce
            }, function (res) {
                if (res.success) {
                    self.showToast('#license-message', 'success', res.data.message || ApeironLicenseL10n.statusUpdated);
                    setTimeout(function () { location.reload(); }, 1200);
                } else {
                    self.showToast('#license-message', 'error', res.data.message || ApeironLicenseL10n.checkFailed);
                    self.resetButton($btn, 'dashicons-search', ApeironLicenseL10n.checkStatus);
                }
            }).fail(function () {
                self.showToast('#license-message', 'error', ApeironLicenseL10n.error);
                self.resetButton($btn, 'dashicons-search', ApeironLicenseL10n.checkStatus);
            });
        },

        /**
         * Deactivate license
         */
        deactivateLicense: function ($btn) {
            if (!confirm(ApeironLicenseL10n.confirmDeactivate)) {
                return;
            }

            var self = this;

            this.setButtonLoading($btn, ApeironLicenseL10n.deactivating);

            $.post(ajaxurl, {
                action: 'apeiron_deactivate_license',
                nonce: this.nonce
            }, function (res) {
                if (res.success) {
                    self.showToast('#license-message', 'success', res.data.message || ApeironLicenseL10n.deactivated);
                    setTimeout(function () { location.reload(); }, 1200);
                } else {
                    self.showToast('#license-message', 'error', res.data.message || ApeironLicenseL10n.deactivateFailed);
                    self.resetButton($btn, 'dashicons-no', ApeironLicenseL10n.deactivate);
                }
            }).fail(function () {
                self.showToast('#license-message', 'error', ApeironLicenseL10n.error);
                self.resetButton($btn, 'dashicons-no', ApeironLicenseL10n.deactivate);
            });
        },

        /**
         * Test server connection
         */
        testConnection: function ($btn) {
            var self = this;

            this.setButtonLoading($btn, ApeironLicenseL10n.testing);

            $.post(ajaxurl, {
                action: 'apeiron_test_server_connection',
                nonce: this.nonce
            }, function (res) {
                if (res.success) {
                    self.showToast('#server-config-message', 'success', res.data.message || ApeironLicenseL10n.connectionSuccess);
                } else {
                    var errorMsg = res.data.message || ApeironLicenseL10n.connectionFailed;
                    if (res.data.error_code) {
                        errorMsg += ' (Error: ' + res.data.error_code + ')';
                    }
                    self.showToast('#server-config-message', 'error', errorMsg);
                }
                self.resetButton($btn, 'dashicons-admin-network', ApeironLicenseL10n.testConnection);
            }).fail(function () {
                self.showToast('#server-config-message', 'error', ApeironLicenseL10n.testError);
                self.resetButton($btn, 'dashicons-admin-network', ApeironLicenseL10n.testConnection);
            });
        },

        /**
         * Set button to loading state
         */
        setButtonLoading: function ($btn, text) {
            $btn.prop('disabled', true)
                .html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> ' + text);
        },

        /**
         * Reset button to normal state
         */
        resetButton: function ($btn, icon, text) {
            $btn.prop('disabled', false)
                .html('<span class="dashicons ' + icon + '" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> ' + text);
        },

        /**
         * Show toast notification
         */
        showToast: function (selector, type, msg) {
            $(selector)
                .removeClass('apeiron-toast--success apeiron-toast--error')
                .addClass('apeiron-toast--' + type)
                .text(msg)
                .slideDown(200);
        }
    };

    // Export to global scope
    window.ApeironLicense = ApeironLicense;

})(jQuery);
