(function ($) {
    'use strict';

    const Countdown = {
        _intervals: new Map(),
        _parts: new Map(),

        destroy(el) {
            const id = this._intervals.get(el);
            if (id) {
                clearInterval(id);
                this._intervals.delete(el);
            }
            this._parts.delete(el);
        },

        init() {
            this.initScope(document);
        },

        initScope(scope) {
            const container = scope.jquery ? scope[0] : scope;
            let els = [];

            if (container.querySelectorAll) {
                els = Array.from(container.querySelectorAll('[data-apeiron-countdown]'));
            }

            // If container itself has the attribute, include it without overwriting children
            if (container.hasAttribute && container.hasAttribute('data-apeiron-countdown')) {
                if (els.indexOf(container) === -1) {
                    els.push(container);
                }
            }

            if (els.length === 0) {
                // Try to find inside container's parent (for Elementor widget wrappers)
                const parent = container.closest ? container.closest('.elementor-widget-apeiron-pulse-countdown') : null;
                if (parent) {
                    els = Array.from(parent.querySelectorAll('[data-apeiron-countdown]'));
                }
            }

            if (els.length === 0) {
                return;
            }

            els.forEach((el) => {
                // Cleanup any existing timer for this element
                this.destroy(el);

                const target = el.getAttribute('data-apeiron-countdown');
                if (!target) {
                    return;
                }

                // Parse timezone offset from WordPress site settings
                const offset = parseFloat(el.getAttribute('data-timezone-offset') || '0');

                // Parse target date — treat as site timezone, convert to UTC timestamp
                const localDate = new Date(target);
                if (isNaN(localDate.getTime())) {
                    return;
                }

                // Adjust: the date string has no timezone, so browser parses it as local.
                // We need to interpret it as the WordPress site timezone instead.
                const browserOffsetMinutes = localDate.getTimezoneOffset(); // browser offset in minutes (negated)
                const siteOffsetMinutes = offset * 60; // site offset in minutes
                const eventAt = localDate.getTime() + (browserOffsetMinutes * 60 * 1000) + (siteOffsetMinutes * 60 * 1000);

                // Cache element references for performance (avoid querying DOM every tick)
                this._parts.set(el, {
                    days: el.querySelector('[data-part="days"]'),
                    hours: el.querySelector('[data-part="hours"]'),
                    minutes: el.querySelector('[data-part="minutes"]'),
                    seconds: el.querySelector('[data-part="seconds"]'),
                });

                // Immediately tick once
                this._tick(el, eventAt);

                // Only start interval if countdown hasn't expired
                const diff = eventAt - Date.now();
                if (diff > 0) {
                    const intervalId = setInterval(() => {
                        this._tick(el, eventAt);
                    }, 1000);
                    this._intervals.set(el, intervalId);
                }
            });
        },

        _tick(el, eventAt) {
            const now = Date.now();
            const diff = Math.max(eventAt - now, 0);

            const totalSeconds = Math.floor(diff / 1000);
            const days = Math.floor(totalSeconds / 86400);
            const hours = Math.floor((totalSeconds % 86400) / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const secs = totalSeconds % 60;

            // Use cached element references
            const parts = this._parts.get(el);
            if (!parts) {
                return;
            }

            if (parts.days) parts.days.textContent = String(days).padStart(2, '0');
            if (parts.hours) parts.hours.textContent = String(hours).padStart(2, '0');
            if (parts.minutes) parts.minutes.textContent = String(minutes).padStart(2, '0');
            if (parts.seconds) parts.seconds.textContent = String(secs).padStart(2, '0');

            // Handle expired state
            if (diff <= 0) {
                this.destroy(el);

                // Add expired class
                el.classList.add('is-expired');

                // Show expired text if configured
                const expiredText = el.getAttribute('data-expired-text');
                if (expiredText) {
                    var msgEl = el.querySelector('.apeiron-kit-countdown__expired');
                    if (!msgEl) {
                        msgEl = document.createElement('div');
                        msgEl.className = 'apeiron-kit-countdown__expired';
                        msgEl.textContent = expiredText;
                        el.appendChild(msgEl);
                    }
                }
            }
        },
    };

    document.addEventListener(
        'DOMContentLoaded',
        function () {
            Countdown.init();
        }
    );

    // Elementor Editor Integration
    jQuery(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-pulse-countdown.default',
                function ($scope) {
                    Countdown.initScope($scope);
                }
            );
        }
    });
}(jQuery));
