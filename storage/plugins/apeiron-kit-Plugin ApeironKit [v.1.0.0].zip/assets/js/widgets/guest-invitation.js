/**
 * Apeiron Kit — Guest Invitation Manager
 * Frontend JavaScript (extracted from inline render)
 *
 * Dependencies: SheetJS (apeiron-sheetjs) — loaded conditionally
 * No jQuery dependency.
 */
(function () {
    'use strict';

    // =========================================================================
    // Toast Notification System
    // =========================================================================
    var toastContainer = null;

    function getToastContainer() {
        if (toastContainer && document.body.contains(toastContainer)) {
            return toastContainer;
        }
        toastContainer = document.createElement('div');
        toastContainer.className = 'apeiron-toast-container';
        document.body.appendChild(toastContainer);
        return toastContainer;
    }

    function showToast(message, type, duration) {
        type = type || 'info';
        duration = duration || 3000;

        var container = getToastContainer();
        var toast = document.createElement('div');
        toast.className = 'apeiron-toast is-' + type;
        toast.textContent = message;
        container.appendChild(toast);

        setTimeout(function () {
            toast.classList.add('is-hiding');
            setTimeout(function () {
                if (toast.parentNode) toast.parentNode.removeChild(toast);
            }, 300);
        }, duration);
    }

    // =========================================================================
    // HTML Escape Helper
    // =========================================================================
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) { return map[m]; });
    }

    // =========================================================================
    // Global Data Store
    // =========================================================================
    if (typeof window.apeironInvitationData === 'undefined') {
        window.apeironInvitationData = {};
    }

    // =========================================================================
    // Template Button CSS Custom Properties Init
    // =========================================================================
    function initTemplateButtons(container) {
        if (!container) return;
        var btns = container.querySelectorAll('.apeiron-btn-template[data-bg]');
        btns.forEach(function (btn) {
            btn.style.setProperty('--apeiron-tpl-bg', btn.getAttribute('data-bg'));
            btn.style.setProperty('--apeiron-tpl-color', btn.getAttribute('data-color') || '#fff');
            btn.style.setProperty('--apeiron-tpl-border', btn.getAttribute('data-border') || 'transparent');
        });
    }

    // =========================================================================
    // Drag & Drop Handlers
    // =========================================================================
    function initDropzones(container) {
        if (!container) return;
        var dropzones = container.querySelectorAll('.apeiron-dropzone');
        dropzones.forEach(function (dropzone) {
            var fileInput = dropzone.querySelector('.apeiron-dropzone-input');
            if (!fileInput) return;

            dropzone.addEventListener('dragenter', function (e) {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.add('is-dragging');
            });

            dropzone.addEventListener('dragover', function (e) {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.add('is-dragging');
            });

            dropzone.addEventListener('dragleave', function (e) {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.remove('is-dragging');
            });

            dropzone.addEventListener('drop', function (e) {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.remove('is-dragging');
                if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                    fileInput.files = e.dataTransfer.files;
                }
            });
        });
    }

    // =========================================================================
    // Change Template Function
    // =========================================================================
    window.apeironChangeTemplate = function (widgetId, type, template, buttonElement) {
        var textarea = document.getElementById('message_template_' + widgetId);
        if (textarea) {
            textarea.value = template.replace(/\\n/g, '\n');
            if (window.apeironInvitationData[widgetId]) {
                window.apeironInvitationData[widgetId].template = template.replace(/\\n/g, '\n');
            }
        }

        // Add active state for visual feedback
        if (buttonElement && buttonElement.nodeType === 1) {
            var container = buttonElement.closest('.apeiron-invitation-wrapper');
            if (container) {
                var buttons = container.querySelectorAll('.apeiron-btn-template');
                buttons.forEach(function (btn) { btn.classList.remove('is-active'); });
                buttonElement.classList.add('is-active');
            }
        }
    };

    // =========================================================================
    // Import Excel Function (SheetJS)
    // =========================================================================
    window.apeironImportExcel = function (widgetId) {
        var fileInput = document.getElementById('import_excel_' + widgetId);
        if (!fileInput || !fileInput.files.length) {
            showToast('Silakan pilih file Excel terlebih dahulu.', 'warning');
            return;
        }

        // Check if SheetJS is loaded
        if (typeof XLSX === 'undefined') {
            showToast('Library SheetJS sedang dimuat. Silakan tunggu sebentar dan coba lagi.', 'warning');
            return;
        }

        var file = fileInput.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
            try {
                var data = new Uint8Array(e.target.result);
                var workbook = XLSX.read(data, { type: 'array' });

                // Get first sheet
                var firstSheetName = workbook.SheetNames[0];
                var worksheet = workbook.Sheets[firstSheetName];

                // Convert to JSON (array of arrays)
                var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });

                // Get textarea for guest names
                var guestNamesTextarea = document.getElementById('guest_names_' + widgetId);
                if (!guestNamesTextarea) {
                    showToast('Element tidak ditemukan. Silakan refresh halaman.', 'error');
                    return;
                }

                // Process data — skip header row, use first column as name
                var guestNames = [];
                for (var i = 1; i < jsonData.length; i++) {
                    var row = jsonData[i];
                    if (row[0] && row[0].toString().trim()) {
                        var name = row[0].toString().trim();
                        // If second column exists (phone number)
                        if (row[1] && row[1].toString().trim()) {
                            name += ' - ' + row[1].toString().trim();
                        }
                        guestNames.push(name);
                    }
                }

                if (guestNames.length === 0) {
                    showToast('Tidak ada data yang ditemukan di file Excel.', 'warning');
                    return;
                }

                // Fill textarea with imported names
                var currentValue = guestNamesTextarea.value.trim();
                var separator = currentValue ? '\n' : '';
                guestNamesTextarea.value = currentValue + separator + guestNames.join('\n');

                showToast('Berhasil mengimport ' + guestNames.length + ' nama dari file Excel.', 'success');

                // Clear file input
                fileInput.value = '';
            } catch (error) {
                console.error('Error importing Excel:', error);
                showToast('Terjadi kesalahan saat membaca file Excel. Pastikan format valid (.xlsx / .xls).', 'error');
            }
        };

        reader.onerror = function () {
            showToast('Gagal membaca file. Silakan coba lagi.', 'error');
        };

        reader.readAsArrayBuffer(file);
    };

    // =========================================================================
    // URL Helpers
    // =========================================================================
    function normalizeBaseUrl(url) {
        try {
            var u = new URL(url);
            if (!u.pathname.endsWith('/')) {
                u.pathname += '/';
            }
            return u.toString();
        } catch (e) {
            var qIndex = url.indexOf('?');
            if (qIndex > -1) {
                var path = url.substring(0, qIndex);
                var query = url.substring(qIndex);
                if (!path.endsWith('/')) path += '/';
                return path + query;
            } else {
                if (!url.endsWith('/')) url += '/';
                return url;
            }
        }
    }

    function appendQueryParam(url, key, value) {
        try {
            var u = new URL(url);
            u.searchParams.set(key, value);
            return u.toString();
        } catch (e) {
            var separator = url.indexOf('?') > -1 ? '&' : '?';
            return url + separator + encodeURIComponent(key) + '=' + encodeURIComponent(value);
        }
    }

    function buildInvitationLink(baseLink, guestName) {
        var cleanName = guestName.trim();
        baseLink = normalizeBaseUrl(baseLink);

        // Remove existing to= parameter
        try {
            var u = new URL(baseLink);
            u.searchParams.delete('to');
            baseLink = u.toString();
        } catch (e) {
            baseLink = baseLink.replace(/[?&]to=[^&]*/g, '');
            baseLink = baseLink.replace(/[?&]$/, '');
        }

        return appendQueryParam(baseLink, 'to', cleanName);
    }

    // =========================================================================
    // Create Guest List Function
    // =========================================================================
    window.apeironCreateGuestList = function (widgetId) {
        var guestNamesTextarea = document.getElementById('guest_names_' + widgetId);
        var messageTemplate = document.getElementById('message_template_' + widgetId);
        var guestListTbody = document.getElementById('guest_list_' + widgetId);
        var linkInput = document.getElementById('invitation_link_input_' + widgetId);

        // Validate invitation link input
        if (!linkInput || !linkInput.value.trim()) {
            showToast('Silakan masukkan link undangan terlebih dahulu.', 'warning');
            if (linkInput) linkInput.focus();
            return;
        }

        if (!guestNamesTextarea || !guestNamesTextarea.value.trim()) {
            showToast('Silakan masukkan nama tamu terlebih dahulu.', 'warning');
            return;
        }

        if (!messageTemplate || !messageTemplate.value.trim()) {
            showToast('Silakan pilih template ucapan terlebih dahulu.', 'warning');
            return;
        }

        // Get invitation link
        var baseInvitationLink = linkInput.value.trim();
        if (!/^https?:\/\//i.test(baseInvitationLink)) {
            baseInvitationLink = 'https://' + baseInvitationLink;
        }

        var template = messageTemplate.value;

        // Normalize base URL
        baseInvitationLink = normalizeBaseUrl(baseInvitationLink);

        var guestNames = guestNamesTextarea.value.split('\n').filter(function (name) {
            return name.trim().length > 0;
        });

        // Store data
        if (!window.apeironInvitationData[widgetId]) {
            window.apeironInvitationData[widgetId] = { template: '', guests: [] };
        }

        window.apeironInvitationData[widgetId].guests = guestNames.map(function (name) {
            var cleanName = name.trim();
            var guestLink = buildInvitationLink(baseInvitationLink, cleanName);

            var personalizedMessage = template
                .replace(/\[nama\]/g, cleanName)
                .replace(/\[link-undangan\]/g, guestLink);

            return {
                name: cleanName,
                message: personalizedMessage,
                link: guestLink
            };
        });

        window.apeironInvitationData[widgetId].template = template;

        // Render guest list
        if (guestListTbody) {
            var html = '';
            window.apeironInvitationData[widgetId].guests.forEach(function (guest, index) {
                var rowNum = index + 1;
                html += '<tr>';
                html += '<td>' + rowNum + '</td>';
                html += '<td>' + escapeHtml(guest.name) + '</td>';
                html += '<td class="apeiron-action-buttons">';
                // WhatsApp
                html += '<button type="button" class="apeiron-action-btn apeiron-btn-wa" data-action="wa" data-widget="' + escapeHtml(widgetId) + '" data-index="' + index + '" title="Share via WhatsApp" aria-label="Share via WhatsApp">';
                html += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';
                html += '</button>';
                // Facebook
                html += '<button type="button" class="apeiron-action-btn apeiron-btn-fb" data-action="fb" data-widget="' + escapeHtml(widgetId) + '" data-index="' + index + '" title="Share via Facebook" aria-label="Share via Facebook">';
                html += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>';
                html += '</button>';
                // Instagram
                html += '<button type="button" class="apeiron-action-btn apeiron-btn-ig" data-action="ig" data-widget="' + escapeHtml(widgetId) + '" data-index="' + index + '" title="Share via Instagram" aria-label="Share via Instagram">';
                html += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>';
                html += '</button>';
                // Copy
                html += '<button type="button" class="apeiron-action-btn apeiron-btn-copy" data-action="copy" data-widget="' + escapeHtml(widgetId) + '" data-index="' + index + '" title="Copy Message" aria-label="Copy Message">';
                html += '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>';
                html += '</button>';
                html += '</td>';
                html += '</tr>';
            });
            guestListTbody.innerHTML = html;
        }

        showToast('Berhasil membuat daftar ' + guestNames.length + ' tamu.', 'success');
    };

    // =========================================================================
    // Share WhatsApp
    // =========================================================================
    window.apeironShareWA = function (widgetId, guestIndex) {
        var guest = window.apeironInvitationData[widgetId] && window.apeironInvitationData[widgetId].guests[guestIndex];
        if (!guest) return;

        var waMessage = encodeURIComponent(guest.message);
        var waUrl = 'https://wa.me/?text=' + waMessage;
        window.open(waUrl, '_blank', 'noopener,noreferrer');
    };

    // =========================================================================
    // Share Facebook
    // =========================================================================
    window.apeironShareFB = function (widgetId, guestIndex) {
        var guest = window.apeironInvitationData[widgetId] && window.apeironInvitationData[widgetId].guests[guestIndex];
        if (!guest) return;

        var shareUrl = encodeURIComponent(guest.link);
        var shareText = encodeURIComponent(guest.message);
        var fbUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + shareUrl + '&quote=' + shareText;
        window.open(fbUrl, '_blank', 'width=626,height=436,noopener,noreferrer');
    };

    // =========================================================================
    // Share Instagram (copy to clipboard)
    // =========================================================================
    window.apeironShareIG = function (widgetId, guestIndex) {
        var guest = window.apeironInvitationData[widgetId] && window.apeironInvitationData[widgetId].guests[guestIndex];
        if (!guest) return;

        var shareContent = guest.message + '\n\n' + guest.link;
        copyToClipboard(shareContent, 'Konten berhasil di-copy! Silakan paste di Instagram.');
    };

    // =========================================================================
    // Copy Message
    // =========================================================================
    window.apeironCopyMessage = function (widgetId, guestIndex) {
        var guest = window.apeironInvitationData[widgetId] && window.apeironInvitationData[widgetId].guests[guestIndex];
        if (!guest) return;

        copyToClipboard(guest.message, 'Pesan berhasil di-copy!');
    };

    // =========================================================================
    // Clipboard helper (DRY)
    // =========================================================================
    function copyToClipboard(text, successMessage) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
                showToast(successMessage, 'success');
            }).catch(function () {
                fallbackCopy(text, successMessage);
            });
        } else {
            fallbackCopy(text, successMessage);
        }
    }

    function fallbackCopy(text, successMessage) {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            showToast(successMessage, 'success');
        } catch (e) {
            showToast('Gagal menyalin teks.', 'error');
        }
        document.body.removeChild(textarea);
    }

    // =========================================================================
    // Event Delegation for Action Buttons (replaces inline onclick in table)
    // =========================================================================
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.apeiron-action-btn[data-action]');
        if (!btn) return;

        var action = btn.getAttribute('data-action');
        var widgetId = btn.getAttribute('data-widget');
        var index = parseInt(btn.getAttribute('data-index'), 10);

        if (!action || !widgetId || isNaN(index)) return;

        switch (action) {
            case 'wa':
                window.apeironShareWA(widgetId, index);
                break;
            case 'fb':
                window.apeironShareFB(widgetId, index);
                break;
            case 'ig':
                window.apeironShareIG(widgetId, index);
                break;
            case 'copy':
                window.apeironCopyMessage(widgetId, index);
                break;
        }
    });

    // =========================================================================
    // Init: run on DOMContentLoaded and Elementor frontend/init
    // =========================================================================
    function initAllWidgets() {
        var containers = document.querySelectorAll('.apeiron-invitation-container');
        containers.forEach(function (container) {
            var widgetId = container.id.replace('apeiron-invitation-', '');
            if (widgetId && !window.apeironInvitationData[widgetId]) {
                window.apeironInvitationData[widgetId] = {
                    template: '',
                    guests: []
                };
            }
            initTemplateButtons(container);
            initDropzones(container);
        });
    }

    // Init on DOMContentLoaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAllWidgets);
    } else {
        initAllWidgets();
    }

    // Re-init on Elementor frontend/init (editor preview)
    if (typeof jQuery !== 'undefined') {
        jQuery(window).on('elementor/frontend/init', function () {
            if (typeof elementorFrontend !== 'undefined') {
                elementorFrontend.hooks.addAction('frontend/element_ready/apeiron-guest-invitation-manager.default', function ($scope) {
                    var container = $scope[0].querySelector('.apeiron-invitation-container');
                    if (container) {
                        var widgetId = container.id.replace('apeiron-invitation-', '');
                        if (widgetId) {
                            window.apeironInvitationData[widgetId] = {
                                template: '',
                                guests: []
                            };
                        }
                        initTemplateButtons(container);
                        initDropzones(container);
                    }
                });
            }
        });
    }

})();
