(function ($) {
    'use strict';

    const SoundPlayer = {
        init() {
            document.querySelectorAll('[data-apeiron-sound-trigger]').forEach((trigger) => {
                const audioId = trigger.getAttribute('data-audio');
                const audio = document.getElementById(audioId);

                if (!audio) {
                    return;
                }

                trigger.addEventListener('click', (event) => {
                    event.preventDefault();
                    if (audio.paused) {
                        audio.play();
                    } else {
                        audio.pause();
                    }
                });

                audio.addEventListener('play', () => trigger.classList.add('is-playing'));
                audio.addEventListener('pause', () => trigger.classList.remove('is-playing'));
            });
        },
    };

    const SoundscapePlayer = {
        /**
         * Initialize a single Soundscape Player widget.
         * Scoped via the container element.
         * Uses AbortController for clean event teardown on re-init.
         */
        initWidget(container) {
            if (!container || container.dataset.apeironSoundscapeInit === 'yes') {
                return;
            }
            container.dataset.apeironSoundscapeInit = 'yes';

            const player = container.querySelector('.apeiron-soundscape-player');
            if (!player) {
                return;
            }

            // AbortController for clean event cleanup on re-init (Fix P4)
            const ac = new AbortController();
            player._apeironAbort = ac;

            const srcType = player.dataset.srcType || 'upload';
            const autoplay = player.dataset.autoplay === 'yes';
            const loop = player.dataset.loop === 'yes';
            const startSec = parseFloat(player.dataset.start) || 0;
            const endSec = parseFloat(player.dataset.end) || 0;
            const hasRange = startSec > 0 && endSec > 0;

            // State management via CSS class
            function setPlaying() {
                player.classList.add('is-playing');
            }
            function setPaused() {
                player.classList.remove('is-playing');
            }

            if (srcType === 'youtube') {
                SoundscapePlayer.initYouTube(player, autoplay, startSec, endSec, setPlaying, setPaused, ac.signal);
            } else {
                SoundscapePlayer.initAudio(player, autoplay, loop, startSec, endSec, hasRange, setPlaying, setPaused, ac.signal);
            }
        },

        initAudio(player, autoplay, loop, startSec, endSec, hasRange, setPlaying, setPaused, signal) {
            const audio = player.querySelector('audio');
            if (!audio) {
                return;
            }

            if (loop) {
                audio.loop = true;
            }

            // Time range handling
            if (hasRange) {
                audio.addEventListener('timeupdate', function () {
                    if (audio.currentTime >= endSec) {
                        if (loop) {
                            audio.currentTime = startSec;
                        } else {
                            audio.pause();
                        }
                    }
                }, { signal: signal });
                audio.addEventListener('ended', function () {
                    if (!loop) {
                        setPaused();
                        audio.currentTime = startSec;
                    }
                }, { signal: signal });
            }

            // Sync icon state with audio events
            audio.addEventListener('play', function () {
                setPlaying();
            }, { signal: signal });
            audio.addEventListener('pause', function () {
                setPaused();
            }, { signal: signal });
            audio.addEventListener('ended', function () {
                setPaused();
            }, { signal: signal });

            // Click to toggle play/pause (Fix P1: removed duplicate touchend handler)
            player.addEventListener('click', function (ev) {
                ev.preventDefault();
                ev.stopPropagation();
                player._apeironAutoplayUnlocked = true; // prevent autoplay fallback from double-firing
                if (audio.paused) {
                    if (hasRange) {
                        if (audio.currentTime >= endSec || audio.currentTime < startSec || audio.currentTime === 0) {
                            audio.currentTime = startSec;
                        }
                    }
                    audio.play().catch(function () {
                        setPaused();
                    });
                } else {
                    audio.pause();
                }
            }, { signal: signal });

            // Tab visibility handler — pause when hidden, resume when visible (Fix P2, adopted from ELKIT)
            var wasPlayingOnHide = false;
            document.addEventListener('visibilitychange', function () {
                if (document.visibilityState === 'hidden') {
                    wasPlayingOnHide = !audio.paused;
                    if (!audio.paused) {
                        audio.pause();
                    }
                } else if (document.visibilityState === 'visible' && wasPlayingOnHide) {
                    audio.play().catch(function () {
                        setPaused();
                    });
                    wasPlayingOnHide = false;
                }
            }, { signal: signal });

            // Autoplay with mobile fallback (Hybrid Safe Method)
            if (autoplay) {
                if (hasRange) {
                    audio.currentTime = startSec;
                }
                audio.play().then(function () {
                    setPlaying();
                    player._apeironAutoplayUnlocked = true;
                }).catch(function () {
                    // Browser blocked autoplay (mobile policy).
                    // Wait for first genuine user gesture to unlock audio.
                    setPaused();
                    var unlockHandler = function () {
                        // Guard: skip if already unlocked (e.g. user clicked play button directly)
                        if (player._apeironAutoplayUnlocked) return;
                        player._apeironAutoplayUnlocked = true;
                        // Skip if audio is already playing (user toggled manually)
                        if (!audio.paused) return;
                        if (hasRange) {
                            audio.currentTime = startSec;
                        }
                        audio.play().then(function () {
                            setPlaying();
                        }).catch(function () {
                            setPaused();
                        });
                    };
                    // Valid user gestures for mobile audio unlock:
                    // - click: universal (desktop + mobile)
                    // - touchend: required by iOS Safari (touchstart alone is NOT enough)
                    // - touchstart: works on Chrome Android
                    // NOTE: scroll is NOT a valid user gesture and is intentionally excluded
                    var gestureOpts = { once: true, capture: true, signal: signal };
                    document.addEventListener('click', unlockHandler, gestureOpts);
                    document.addEventListener('touchend', unlockHandler, gestureOpts);
                    document.addEventListener('touchstart', unlockHandler, gestureOpts);
                });
            } else {
                setPaused();
            }
        },

        initYouTube(player, autoplay, startSec, endSec, setPlaying, setPaused, signal) {
            const ytContainer = player.querySelector('[data-video]');
            if (!ytContainer) {
                return;
            }

            const videoUrl = ytContainer.dataset.video;
            const playerId = ytContainer.id + '-player';

            function extractVideoID(url) {
                const r = /^.*((youtu.be\/)|(v\/)|(\/((u\/\w\/)|(embed\/)|(watch\?))))\??v?=?([^#&?]*).*/;
                const m = url.match(r);
                return (m && m[7].length === 11) ? m[7] : null;
            }

            let ytPlayer = null;
            // Store YT player reference on DOM element for cleanup (Fix P5)
            player._apeironYTPlayer = null;

            function initYT() {
                ytContainer.innerHTML = '<div id="' + playerId + '"></div>';
                ytContainer.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;';
                ytPlayer = new YT.Player(playerId, {
                    height: '1',
                    width: '1',
                    videoId: extractVideoID(videoUrl),
                    playerVars: {
                        autoplay: autoplay ? 1 : 0,
                        loop: 0,
                        start: startSec || undefined,
                        end: endSec || undefined,
                        playsinline: 1
                    },
                    events: {
                        'onReady': function (ev) {
                            if (autoplay) {
                                ev.target.playVideo();
                                setPlaying();
                            } else {
                                setPaused();
                            }
                        }
                    }
                });
                player._apeironYTPlayer = ytPlayer;
            }

            function toggleYT() {
                if (!ytPlayer || !ytPlayer.getPlayerState) return;
                const s = ytPlayer.getPlayerState();
                if (s === 1 || s === 3) {
                    ytPlayer.pauseVideo();
                    setPaused();
                } else {
                    ytPlayer.playVideo();
                    setPlaying();
                }
            }

            player.addEventListener('click', function (ev) {
                ev.preventDefault();
                ev.stopPropagation();
                toggleYT();
            }, { signal: signal });

            // Tab visibility handler for YouTube (Fix P2)
            var wasYTPlayingOnHide = false;
            document.addEventListener('visibilitychange', function () {
                if (!ytPlayer || !ytPlayer.getPlayerState) return;
                if (document.visibilityState === 'hidden') {
                    var s = ytPlayer.getPlayerState();
                    wasYTPlayingOnHide = (s === 1 || s === 3);
                    if (wasYTPlayingOnHide) {
                        ytPlayer.pauseVideo();
                        setPaused();
                    }
                } else if (document.visibilityState === 'visible' && wasYTPlayingOnHide) {
                    ytPlayer.playVideo();
                    setPlaying();
                    wasYTPlayingOnHide = false;
                }
            }, { signal: signal });

            // Load YouTube IFrame API if not already loaded
            if (!document.querySelector('script[src*="youtube.com/iframe_api"]')) {
                const tag = document.createElement('script');
                tag.src = 'https://www.youtube.com/iframe_api';
                document.head.appendChild(tag);
            }

            // Hook into API ready callback
            const origCb = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = function () {
                if (origCb) origCb();
                initYT();
            };

            if (window.YT && window.YT.Player) {
                initYT();
            }

            if (!autoplay) {
                setPaused();
            }
        },

        /**
         * Cleanup a widget: abort events, stop audio/YT, reset state (Fix P4, P5)
         */
        cleanupWidget(container) {
            const player = container ? container.querySelector('.apeiron-soundscape-player') : null;
            if (!player) return;

            // Abort all event listeners registered via AbortController
            if (player._apeironAbort) {
                player._apeironAbort.abort();
                player._apeironAbort = null;
            }

            // Stop and reset HTML5 audio
            const audio = player.querySelector('audio');
            if (audio) {
                audio.pause();
                audio.currentTime = 0;
            }

            // Stop and destroy YouTube player
            if (player._apeironYTPlayer) {
                try {
                    if (player._apeironYTPlayer.getPlayerState && player._apeironYTPlayer.getPlayerState() === 1) {
                        player._apeironYTPlayer.stopVideo();
                    }
                    player._apeironYTPlayer.destroy();
                } catch (e) {
                    // YT player may already be destroyed
                }
                player._apeironYTPlayer = null;
            }

            // Reset visual state
            player.classList.remove('is-playing');
        },

        /**
         * Init from scope (Elementor editor re-render support)
         * Properly cleans up before re-initializing (Fix P4, P5)
         */
        initScope($scope) {
            const el = $scope[0] || $scope;
            if (el) {
                // Cleanup previous instance before re-init
                SoundscapePlayer.cleanupWidget(el);
                el.dataset.apeironSoundscapeInit = '';
            }
            SoundscapePlayer.initWidget(el);
        },

        init() {
            document.querySelectorAll('.elementor-widget-apeiron-soundscape').forEach(function (el) {
                SoundscapePlayer.initWidget(el);
            });
        }
    };

    document.addEventListener(
        'DOMContentLoaded',
        function () {
            SoundPlayer.init();
            SoundscapePlayer.init();
        }
    );

    // Elementor Editor Integration
    jQuery(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-soundscape.default',
                function ($scope) {
                    SoundscapePlayer.initScope($scope);
                }
            );
        }
    });
}(jQuery));
