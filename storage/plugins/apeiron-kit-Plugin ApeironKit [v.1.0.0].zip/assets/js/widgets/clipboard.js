(function ($) {
    'use strict';

    /**
     * Clipboard handler for Apeiron ClipboardTap widget.
     *
     * Reads data-apeiron-clipboard and data-copy-message attributes
     * from the button element to perform copy and show feedback.
     */
    var Clipboard = {

        /**
         * Initialize clipboard buttons within a given scope.
         *
         * @param {HTMLElement} scope - Root element to search within.
         */
        initScope: function (scope) {
            var buttons = scope.querySelectorAll('[data-apeiron-clipboard]');
            for (var i = 0; i < buttons.length; i++) {
                this.bindButton(buttons[i]);
            }
        },

        /**
         * Bind click handler to a single clipboard button.
         * Uses a guard flag to prevent duplicate listeners.
         *
         * @param {HTMLElement} btn - The button element.
         */
        bindButton: function (btn) {
            if (btn._apeironClipboardInit) return;
            btn._apeironClipboardInit = true;

            var self = this;
            btn.addEventListener('click', function () {
                var text = btn.getAttribute('data-apeiron-clipboard') || '';
                if (!text) return;

                var $textEl = $(btn).find('.elementor-button-text');
                var $iconEl = $(btn).find('.elementor-button-icon');
                var originalText = $textEl.length ? $textEl.text() : '';
                var copyMessage = btn.getAttribute('data-copy-message') || 'Copied!';

                var showCopied = function () {
                    if ($textEl.length) {
                        $textEl.text(copyMessage);
                    }
                    if ($iconEl.length) {
                        $iconEl.hide();
                    }
                    btn.classList.add('is-copied');

                    setTimeout(function () {
                        if ($textEl.length) {
                            $textEl.text(originalText);
                        }
                        if ($iconEl.length) {
                            $iconEl.show();
                        }
                        btn.classList.remove('is-copied');
                    }, 1800);
                };

                // Use modern Clipboard API with fallback
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(showCopied).catch(function () {
                        self.fallbackCopyText(text, showCopied);
                    });
                } else {
                    self.fallbackCopyText(text, showCopied);
                }
            });
        },

        /**
         * Fallback copy method for older browsers.
         * Uses a temporary textarea and execCommand('copy').
         *
         * @param {string}   text     - Text to copy.
         * @param {Function} callback - Called on success.
         */
        fallbackCopyText: function (text, callback) {
            var textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            textarea.style.pointerEvents = 'none';
            document.body.appendChild(textarea);
            textarea.select();
            textarea.setSelectionRange(0, 99999);

            try {
                document.execCommand('copy');
                if (callback) callback();
            } catch (err) {
                // Silent fail — clipboard is non-critical
            } finally {
                document.body.removeChild(textarea);
            }
        }
    };

    // Initialize on DOMContentLoaded
    document.addEventListener('DOMContentLoaded', function () {
        Clipboard.initScope(document);
    });

    // Elementor Editor Integration — re-init when widget is ready
    $(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-clipboard-tap.default',
                function ($scope) {
                    var el = $scope[0] || $scope;
                    if (!el) return;
                    // Reset guard flags so buttons re-bind after editor re-render
                    var buttons = el.querySelectorAll('[data-apeiron-clipboard]');
                    for (var i = 0; i < buttons.length; i++) {
                        buttons[i]._apeironClipboardInit = false;
                    }
                    Clipboard.initScope(el);
                }
            );
        }
    });
}(jQuery));
