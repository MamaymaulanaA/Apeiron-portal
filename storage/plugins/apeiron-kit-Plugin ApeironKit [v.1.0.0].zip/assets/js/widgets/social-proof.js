(function ($) {
    'use strict';

    var SocialProof = {
        _timers: new Map(),
        _state: new Map(),

        /**
         * Cleanup all timers and state for a given popup element.
         */
        destroy: function (el) {
            var timers = this._timers.get(el);
            if (timers) {
                clearTimeout(timers.show);
                clearTimeout(timers.hide);
                clearTimeout(timers.next);
                this._timers.delete(el);
            }
            this._state.delete(el);

            // Force hide popup immediately
            el.classList.remove('show');
            el.style.display = 'none';
        },

        /**
         * Initialize all Social Proof widgets on the page.
         */
        init: function () {
            this.initScope(document);
        },

        /**
         * Initialize widgets within a given scope (Elementor $scope or document).
         */
        initScope: function (scope) {
            var container = scope.jquery ? scope[0] : scope;
            var popups = [];

            if (container.querySelectorAll) {
                popups = Array.prototype.slice.call(
                    container.querySelectorAll('.apeiron-social-proof-popup[data-entries]')
                );
            }

            // If container itself is the popup
            if (container.classList &&
                container.classList.contains('apeiron-social-proof-popup') &&
                container.hasAttribute('data-entries')) {
                if (popups.indexOf(container) === -1) {
                    popups.push(container);
                }
            }

            // Fallback: try parent Elementor widget wrapper
            if (popups.length === 0 && container.closest) {
                var parent = container.closest('.elementor-widget-apeiron-social-proof');
                if (parent) {
                    popups = Array.prototype.slice.call(
                        parent.querySelectorAll('.apeiron-social-proof-popup[data-entries]')
                    );
                }
            }

            if (popups.length === 0) {
                return;
            }

            var self = this;
            popups.forEach(function (el) {
                self._initElement(el);
            });
        },

        /**
         * Initialize a single popup element.
         */
        _initElement: function (el) {
            // Destroy any existing instance on this element
            this.destroy(el);

            // Parse data attributes
            var entries;
            try {
                entries = JSON.parse(el.getAttribute('data-entries') || '[]');
            } catch (e) {
                if (typeof console !== 'undefined') {
                    console.warn('SocialProof: Invalid data-entries JSON', e);
                }
                return;
            }

            if (!entries || entries.length === 0) {
                return;
            }

            var textTemplate = el.getAttribute('data-text-template') || '{name} telah membeli {product} pada:';
            var displayDuration = parseInt(el.getAttribute('data-display-duration'), 10) || 3000;
            var intervalDuration = parseInt(el.getAttribute('data-interval-duration'), 10) || 2000;

            // Cache child element references
            var popupImage = el.querySelector('.apeiron-popup-image');
            var popupName = el.querySelector('.apeiron-popup-name');
            var popupDesc = el.querySelector('.apeiron-popup-desc');
            var popupDate = el.querySelector('.apeiron-popup-date');

            if (!popupImage || !popupName || !popupDesc || !popupDate) {
                return;
            }

            // Store state for this element
            this._state.set(el, {
                entries: entries,
                textTemplate: textTemplate,
                displayDuration: displayDuration,
                intervalDuration: intervalDuration,
                currentIndex: 0,
                popupImage: popupImage,
                popupName: popupName,
                popupDesc: popupDesc,
                popupDate: popupDate
            });

            // Initialize timer tracking
            this._timers.set(el, { show: null, hide: null, next: null });

            // Start after initial delay (1500ms baseline)
            var self = this;
            this._timers.get(el).next = setTimeout(function () {
                self._showNextEntry(el);
            }, 1500);
        },

        /**
         * Show the next entry in the popup cycle.
         */
        _showNextEntry: function (el) {
            var state = this._state.get(el);
            if (!state) return;

            if (state.currentIndex >= state.entries.length) {
                state.currentIndex = 0;
            }

            var entry = state.entries[state.currentIndex];

            // Update image using DOM API (security fix)
            state.popupImage.textContent = '';
            if (entry.image) {
                var img = document.createElement('img');
                img.src = entry.image;
                img.alt = entry.name || '';
                state.popupImage.appendChild(img);
            } else {
                // SVG placeholder — static content, safe to use innerHTML
                state.popupImage.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="color:#94a3b8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
            }

            // Update text
            state.popupName.textContent = entry.name || '';

            // Template parsing — retain innerHTML (data is wp_json_encode safe)
            var descHtml = this._parseTemplate(state.textTemplate, entry.name || '', entry.product || '');
            descHtml = descHtml.replace(entry.name || '', '').replace(/^[\s,]+/, '');
            state.popupDesc.innerHTML = descHtml;

            state.popupDate.textContent = this._formatDate(entry.datetime || '');

            // Show with animation
            el.style.display = 'block';
            // Force reflow to ensure initial state is applied
            void el.offsetHeight;
            // Add show class to trigger CSS animation
            el.classList.add('show');

            // Schedule hide after displayDuration
            var self = this;
            var timers = this._timers.get(el);
            if (!timers) return;

            timers.show = setTimeout(function () {
                el.classList.remove('show');

                // Wait for CSS transition to complete (400ms matches CSS)
                timers.hide = setTimeout(function () {
                    el.style.display = 'none';
                    state.currentIndex++;

                    // Schedule next entry after intervalDuration
                    timers.next = setTimeout(function () {
                        self._showNextEntry(el);
                    }, state.intervalDuration);
                }, 400);
            }, state.displayDuration);
        },

        /**
         * Parse text template with name and product placeholders.
         */
        _parseTemplate: function (template, name, product) {
            return template
                .replace(/\{name\}/g, '<span class="apeiron-popup-name-inline">' + name + '</span>')
                .replace(/\{product\}/g, '<span class="apeiron-popup-product">' + product + '</span>');
        },

        /**
         * Format a date string to Indonesian locale with timezone.
         */
        _formatDate: function (dateStr) {
            if (!dateStr) return '-';

            var date = new Date(dateStr);
            if (isNaN(date.getTime())) return dateStr || '-';

            var options = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            return date.toLocaleDateString('id-ID', options) + ' (' + this._getTimezone(date) + ')';
        },

        /**
         * Get timezone abbreviation for Indonesian timezones,
         * with UTC offset fallback for non-Indonesian visitors.
         */
        _getTimezone: function (date) {
            var offset = -date.getTimezoneOffset() / 60;
            if (offset >= 7 && offset < 8) return 'WIB';
            if (offset >= 8 && offset < 9) return 'WITA';
            if (offset >= 9) return 'WIT';
            return 'UTC' + (offset >= 0 ? '+' : '') + offset;
        }
    };

    // Frontend: Initialize on DOMContentLoaded
    document.addEventListener('DOMContentLoaded', function () {
        SocialProof.init();
    });

    // Elementor Editor Integration
    jQuery(window).on('elementor/frontend/init', function () {
        if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
            elementorFrontend.hooks.addAction(
                'frontend/element_ready/apeiron-social-proof.default',
                function ($scope) {
                    SocialProof.initScope($scope);
                }
            );
        }
    });

}(jQuery));
