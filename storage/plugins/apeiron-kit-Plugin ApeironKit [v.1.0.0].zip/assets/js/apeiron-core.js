/**
 * Apeiron Kit — Core Script
 *
 * This file acts as the anchor for wp_localize_script.
 * The `ApeironKit` global object (ajaxUrl, restUrl, nonce, defaultAvatarUrl)
 * is attached to this script handle by AssetManager::register_assets().
 *
 * Per-widget scripts that need ApeironKit data should declare
 * this handle ('apeiron-core') as a dependency.
 *
 * @package ApeironKit
 */
