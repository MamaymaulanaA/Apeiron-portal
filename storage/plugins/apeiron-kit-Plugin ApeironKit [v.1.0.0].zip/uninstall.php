<?php
/**
 * Uninstall handler for Apeiron Kit
 *
 * This file runs when the plugin is deleted from WordPress admin.
 * It cleans up all plugin data from the database.
 *
 * @package ApeironKit
 * @since 1.0.0
 */

// Exit if not called by WordPress uninstall
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete all plugin options from database
 */
$options_to_delete = [
	'apeiron_kit_settings',
	'apeiron_kit_license',
	'apeiron_kit_license_cache',
	'apeiron_kit_license_salt',
	'apeiron_kit_license_api_url',
	'apeiron_kit_api_key_encrypted',
	'apeiron_kit_api_salt',
	'apeiron_social_proof_settings',
	'apeiron_kit_disabled_widgets',
];

foreach ( $options_to_delete as $option ) {
	delete_option( $option );
}

/**
 * Delete all plugin transients
 */
$transients_to_delete = [
	'apeiron_kit_license_valid',
	'apeiron_kit_activation_notice',
];

foreach ( $transients_to_delete as $transient ) {
	delete_transient( $transient );
}

/**
 * Clean up rate limit transients (pattern-based)
 * These are created with dynamic keys based on IP hash
 */
global $wpdb;
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		'_transient_apeiron_comment_rate_%',
		'_transient_timeout_apeiron_comment_rate_%'
	)
);

/**
 * Clear all scheduled hooks
 */
wp_clear_scheduled_hook( 'apeiron_kit_check_license' );

/**
 * Optional: Delete uploaded client photos
 * Uncomment the following code if you want to remove uploaded files on uninstall
 * WARNING: This will permanently delete user-uploaded images
 */
/*
$upload_dir = wp_upload_dir();
$photos_dir = trailingslashit( $upload_dir['basedir'] ) . 'apeiron-client-photos';

if ( is_dir( $photos_dir ) ) {
	$files = glob( $photos_dir . '/*' );
	if ( is_array( $files ) ) {
		foreach ( $files as $file ) {
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}
	}
	rmdir( $photos_dir );
}
*/
