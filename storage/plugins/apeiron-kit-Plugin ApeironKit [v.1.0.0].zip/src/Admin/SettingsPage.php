<?php

namespace ApeironKit\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ApeironKit\Admin\Tabs\GeneralTab;
use ApeironKit\Admin\Tabs\LicenseTab;
use ApeironKit\Admin\Tabs\StickerTab;
use ApeironKit\Admin\Tabs\SocialProofTab;
use ApeironKit\Admin\Ajax\SocialProofHandler;
use ApeironKit\Admin\Ajax\WidgetToggleHandler;
use ApeironKit\Core\LicenseManager;

/**
 * Admin Settings Page Controller.
 * 
 * Orchestrates menu registration, settings, and delegates
 * rendering to individual Tab classes.
 */
class SettingsPage {

	private string $option_name = 'apeiron_kit_settings';
	private string $main_slug   = 'apeiron-kit';
	private string $license_slug = 'apeiron-kit-license';
	private string $stickers_slug = 'apeiron-kit-stickers';
	private string $social_proof_slug = 'apeiron-kit-social-proof';
	
	private LicenseManager $license_manager;
	private SocialProofHandler $social_proof_handler;
	private WidgetToggleHandler $widget_toggle_handler;
	
	private GeneralTab $general_tab;
	private LicenseTab $license_tab;
	private StickerTab $sticker_tab;
	private SocialProofTab $social_proof_tab;

	public function __construct() {
		$this->license_manager = LicenseManager::instance();
		$this->social_proof_handler = new SocialProofHandler();
		$this->widget_toggle_handler = new WidgetToggleHandler();
		
		// Initialize tabs
		$this->general_tab = new GeneralTab();
		$this->license_tab = new LicenseTab();
		$this->sticker_tab = new StickerTab();
		$this->social_proof_tab = new SocialProofTab();
	}

	/**
	 * Register all hooks and actions.
	 */
	public function register(): void {
		add_action( 'admin_menu', [ $this, 'add_menu' ] );
		add_action( 'admin_init', [ $this, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ], 20 );
		
		// Register AJAX handlers
		$this->social_proof_handler->register();
		$this->widget_toggle_handler->register();
	}

	/**
	 * Get menu icon URL.
	 *
	 * @return string
	 */
	private function get_menu_icon_url(): string {
		return APEIRON_KIT_URL . 'assets/img/icon.png';
	}

	/**
	 * Add admin menu pages.
	 */
	public function add_menu(): void {
		add_menu_page(
			'ApeironKit',
			'ApeironKit',
			'manage_options',
			$this->main_slug,
			[ $this, 'render_page' ],
			$this->get_menu_icon_url(),
			58
		);

		add_submenu_page(
			$this->main_slug,
			__( 'Lisensi', 'apeiron-kit' ),
			__( 'Lisensi', 'apeiron-kit' ),
			'manage_options',
			$this->license_slug,
			[ $this, 'render_license_page' ]
		);

		add_submenu_page(
			$this->main_slug,
			__( 'Stiker', 'apeiron-kit' ),
			__( 'Stiker', 'apeiron-kit' ),
			'manage_options',
			$this->stickers_slug,
			[ $this, 'render_sticker_page' ]
		);

		add_submenu_page(
			$this->main_slug,
			__( 'Social Proof', 'apeiron-kit' ),
			__( 'Social Proof', 'apeiron-kit' ),
			'manage_options',
			$this->social_proof_slug,
			[ $this, 'render_social_proof_page' ]
		);
	}

	/**
	 * Register plugin settings.
	 */
	public function register_settings(): void {
		register_setting(
			'apeiron_kit_settings',
			$this->option_name,
			[
				'sanitize_callback' => [ $this, 'sanitize' ],
				'default'           => [
					'comment_moderation' => 'auto',
				],
			]
		);

		add_settings_section(
			'apeiron_kit_main',
			'',
			function () {},
			'apeiron-kit'
		);

		add_settings_field(
			'comment_moderation',
			__( 'Moderasi Komentar', 'apeiron-kit' ),
			[ $this, 'render_select_field' ],
			'apeiron-kit',
			'apeiron_kit_main',
			[
				'name'    => 'comment_moderation',
				'options' => [
					'auto'   => __( 'Terbit otomatis', 'apeiron-kit' ),
					'manual' => __( 'Tahan untuk ditinjau', 'apeiron-kit' ),
				],
			]
		);
	}

	/**
	 * Render main settings page.
	 */
	public function render_page(): void {
		$this->general_tab->render();
	}

	/**
	 * Render license page.
	 */
	public function render_license_page(): void {
		$this->license_tab->render();
	}

	/**
	 * Render sticker page.
	 */
	public function render_sticker_page(): void {
		$this->sticker_tab->render();
	}

	/**
	 * Render social proof page.
	 */
	public function render_social_proof_page(): void {
		$this->social_proof_tab->render();
	}

	/**
	 * Render select field for settings API.
	 *
	 * @param array $args Field arguments.
	 */
	public function render_select_field( array $args ): void {
		$options = get_option( $this->option_name, [] );
		$value   = $options[ $args['name'] ] ?? '';
		
		$descriptions = [
			'comment_moderation' => __( 'Pilih apakah komentar langsung diterbitkan atau perlu ditinjau terlebih dahulu.', 'apeiron-kit' ),
		];
		
		$description = $descriptions[ $args['name'] ] ?? '';

		echo '<select name="' . esc_attr( $this->option_name . '[' . $args['name'] . ']' ) . '" style="min-width: 250px; padding: 10px 14px; border: 1px solid #0000000D; border-radius: 8px; font-size: 14px; background: #fff;">';
		foreach ( $args['options'] as $key => $label ) {
			printf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $key ),
				selected( $value, $key, false ),
				esc_html( $label )
			);
		}
		echo '</select>';
		
		if ( ! empty( $description ) ) {
			echo '<p class="description" style="margin-top: 8px; font-size: 13px; color: #646970;">' . esc_html( $description ) . '</p>';
		}
	}

	/**
	 * Sanitize settings input.
	 *
	 * @param mixed $input Input data.
	 * @return array
	 */
	public function sanitize( $input ): array {
		return [
			'comment_moderation' => ( $input['comment_moderation'] ?? 'auto' ) === 'manual' ? 'manual' : 'auto',
		];
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_scripts( string $hook ): void {
		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '';
		
		$allowed_pages = [
			$this->main_slug,
			$this->license_slug,
			$this->stickers_slug,
			$this->social_proof_slug,
		];

		$is_apeiron_page = $this->is_apeiron_page( $current_page, $hook, $allowed_pages );

		if ( ! $is_apeiron_page ) {
			return;
		}

		wp_enqueue_script( 'jquery' );
		
		// Register and enqueue admin settings CSS
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$css_file = trailingslashit( APEIRON_KIT_URL ) . 'assets/css/admin-settings' . $suffix . '.css';
		$css_path = trailingslashit( APEIRON_KIT_PATH ) . 'assets/css/admin-settings' . $suffix . '.css';
		
		$version = file_exists( $css_path ) ? filemtime( $css_path ) : APEIRON_KIT_VERSION;
		
		wp_register_style(
			'apeiron-kit-admin',
			$css_file,
			[],
			$version
		);
		
		wp_enqueue_style( 'apeiron-kit-admin' );

		// Enqueue media uploader for social proof page
		if ( $this->social_proof_slug === $current_page ) {
			wp_enqueue_media();
		}
	}

	/**
	 * Check if current page is an Apeiron Kit admin page.
	 *
	 * @param string $current_page Current page slug.
	 * @param string $hook Current hook.
	 * @param array  $allowed_pages Allowed page slugs.
	 * @return bool
	 */
	private function is_apeiron_page( string $current_page, string $hook, array $allowed_pages ): bool {
		// Method 1: Check by GET parameter
		if ( ! empty( $current_page ) && in_array( $current_page, $allowed_pages, true ) ) {
			return true;
		}
		
		// Method 2: Check by hook name
		$allowed_hooks = [
			'toplevel_page_' . $this->main_slug,
			$this->main_slug . '_page_' . $this->license_slug,
			$this->main_slug . '_page_' . $this->stickers_slug,
			$this->main_slug . '_page_' . $this->social_proof_slug,
		];
		
		if ( in_array( $hook, $allowed_hooks, true ) ) {
			return true;
		}
		
		// Method 3: Check by screen ID
		$current_screen = get_current_screen();
		if ( $current_screen ) {
			$screen_id = $current_screen->id;
			foreach ( $allowed_pages as $page ) {
				if ( strpos( $screen_id, $page ) !== false ) {
					return true;
				}
			}
		}

		return false;
	}
}
