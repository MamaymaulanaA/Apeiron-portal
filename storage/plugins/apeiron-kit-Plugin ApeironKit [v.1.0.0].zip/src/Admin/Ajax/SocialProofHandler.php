<?php

namespace ApeironKit\Admin\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Proof AJAX handlers.
 */
class SocialProofHandler {

	/**
	 * Option name for social proof settings.
	 */
	private const OPTION_NAME = 'apeiron_social_proof_settings';

	/**
	 * AJAX nonce action.
	 */
	private const NONCE_ACTION = 'apeiron_social_proof';

	/**
	 * Default settings.
	 */
	private array $defaults = [
		'display_duration'    => 3,
		'interval_duration'   => 2,
		'animation_type'      => 'slide-top',
		'popup_position'      => 'bottom-right',
		'text_template'       => '{name} telah membeli {product} pada:',
		'image_border_radius' => 10,
		'entries'             => [],
	];

	/**
	 * Register AJAX handlers.
	 */
	public function register(): void {
		add_action( 'wp_ajax_apeiron_save_social_proof', [ $this, 'save_settings' ] );
		add_action( 'wp_ajax_apeiron_delete_social_proof_entry', [ $this, 'delete_entry' ] );
		add_action( 'wp_ajax_apeiron_upload_client_photo', [ $this, 'upload_photo' ] );
	}

	/**
	 * Save social proof settings.
	 */
	public function save_settings(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Tidak memiliki izin.', 'apeiron-kit' ) ] );
		}

		$settings = wp_parse_args( get_option( self::OPTION_NAME, [] ), $this->defaults );

		parse_str( wp_unslash( $_POST['form_data'] ?? '' ), $form_data );

		// Check if adding entry
		if ( ! empty( $form_data['add_entry'] ) ) {
			$entry_name = sanitize_text_field( $form_data['entry_name'] ?? '' );
			$entry_product = sanitize_text_field( $form_data['entry_product'] ?? '' );
			$entry_image = esc_url_raw( $form_data['entry_image'] ?? '' );
			$entry_datetime = sanitize_text_field( $form_data['entry_datetime'] ?? '' );

			if ( empty( $entry_name ) || empty( $entry_product ) || empty( $entry_datetime ) ) {
				wp_send_json_error( [ 'message' => __( 'Nama, produk, dan datetime wajib diisi.', 'apeiron-kit' ) ] );
			}

			$entries = $settings['entries'] ?? [];
			$entries[] = [
				'name'     => $entry_name,
				'product'  => $entry_product,
				'image'    => $entry_image,
				'datetime' => $entry_datetime,
			];

			$settings['entries'] = $entries;
		} else {
			// Update settings
			$settings['display_duration']    = absint( $form_data['display_duration'] ?? $settings['display_duration'] );
			$settings['interval_duration']   = absint( $form_data['interval_duration'] ?? $settings['interval_duration'] );
			$settings['animation_type']      = sanitize_text_field( $form_data['animation_type'] ?? $settings['animation_type'] );
			$settings['popup_position']      = sanitize_text_field( $form_data['popup_position'] ?? $settings['popup_position'] );
			$settings['text_template']       = sanitize_text_field( $form_data['text_template'] ?? $settings['text_template'] );
			$settings['image_border_radius'] = absint( $form_data['image_border_radius'] ?? $settings['image_border_radius'] ?? 10 );
		}

		update_option( self::OPTION_NAME, $settings );
		wp_send_json_success( [ 'message' => __( 'Berhasil disimpan!', 'apeiron-kit' ) ] );
	}

	/**
	 * Delete social proof entry.
	 */
	public function delete_entry(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Tidak memiliki izin.', 'apeiron-kit' ) ] );
		}

		$settings = get_option( self::OPTION_NAME, [] );
		$entries = $settings['entries'] ?? [];

		$raw_index = isset( $_POST['entry_index'] ) ? wp_unslash( $_POST['entry_index'] ) : null;
		if ( ! is_scalar( $raw_index ) ) {
			wp_send_json_error( [ 'message' => __( 'Entry tidak ditemukan.', 'apeiron-kit' ) ] );
		}
		$index = filter_var(
			(string) $raw_index,
			FILTER_VALIDATE_INT,
			[
				'options' => [
					'min_range' => 0,
				],
			]
		);

		if ( false === $index || $index >= count( $entries ) ) {
			wp_send_json_error( [ 'message' => __( 'Entry tidak ditemukan.', 'apeiron-kit' ) ] );
		}

		unset( $entries[ $index ] );
		$entries = array_values( $entries ); // Re-index array

		$settings['entries'] = $entries;
		update_option( self::OPTION_NAME, $settings );

		wp_send_json_success( [ 'message' => __( 'Entry berhasil dihapus.', 'apeiron-kit' ) ] );
	}

	/**
	 * Upload client photo.
	 */
	public function upload_photo(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Tidak memiliki izin.', 'apeiron-kit' ) ] );
		}

		// Check if file was uploaded
		if ( ! isset( $_FILES['client_photo'] ) || $_FILES['client_photo']['error'] !== UPLOAD_ERR_OK ) {
			wp_send_json_error( [ 'message' => __( 'Tidak ada file yang diupload atau terjadi error.', 'apeiron-kit' ) ] );
		}

		$file = $_FILES['client_photo'];
		
		// Validate file extension
		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		$allowed_extensions = [ 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp' ];

		if ( ! in_array( $ext, $allowed_extensions, true ) ) {
			wp_send_json_error( [ 'message' => __( 'Format file tidak diizinkan. Gunakan PNG, JPG, GIF, SVG, atau WebP.', 'apeiron-kit' ) ] );
		}

		// Validate file size (max 5MB)
		$max_size = 5 * 1024 * 1024;
		if ( $file['size'] > $max_size ) {
			wp_send_json_error( [ 'message' => __( 'Ukuran file terlalu besar. Maksimal 5MB.', 'apeiron-kit' ) ] );
		}

		// Validate MIME type
		$file_type = wp_check_filetype( $file['name'], [
			'png'  => 'image/png',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'gif'  => 'image/gif',
			'svg'  => 'image/svg+xml',
			'webp' => 'image/webp',
		] );

		if ( ! $file_type['type'] ) {
			wp_send_json_error( [ 'message' => __( 'Tipe file tidak valid.', 'apeiron-kit' ) ] );
		}

		// Create upload directory
		$upload_dir = wp_upload_dir();
		$client_photos_dir = trailingslashit( $upload_dir['basedir'] ) . 'apeiron-client-photos';
		
		if ( ! is_dir( $client_photos_dir ) ) {
			wp_mkdir_p( $client_photos_dir );
		}

		// Generate unique filename
		$filename = sanitize_file_name( pathinfo( $file['name'], PATHINFO_FILENAME ) );
		$unique_filename = $filename . '_' . time() . '_' . wp_generate_password( 6, false ) . '.' . $ext;
		$file_path = trailingslashit( $client_photos_dir ) . $unique_filename;

		// Move uploaded file
		if ( ! move_uploaded_file( $file['tmp_name'], $file_path ) ) {
			wp_send_json_error( [ 'message' => __( 'Gagal menyimpan file.', 'apeiron-kit' ) ] );
		}

		// Sanitize SVG files to prevent XSS
		if ( 'svg' === $ext ) {
			$sanitized = \ApeironKit\Support\StickerManager::sanitize_svg_file( $file_path );
			if ( ! $sanitized ) {
				@unlink( $file_path );
				wp_send_json_error( [ 'message' => __( 'File SVG mengandung konten berbahaya dan telah ditolak.', 'apeiron-kit' ) ] );
			}
		}

		// Get file URL
		$file_url = trailingslashit( $upload_dir['baseurl'] ) . 'apeiron-client-photos/' . $unique_filename;

		// Return success with file URL
		wp_send_json_success( [
			'message' => __( 'Foto berhasil diupload!', 'apeiron-kit' ),
			'url'     => $file_url,
		] );
	}

	/**
	 * Get settings.
	 *
	 * @return array
	 */
	public function get_settings(): array {
		return wp_parse_args( get_option( self::OPTION_NAME, [] ), $this->defaults );
	}

	/**
	 * Get nonce action.
	 *
	 * @return string
	 */
	public static function get_nonce_action(): string {
		return self::NONCE_ACTION;
	}
}
