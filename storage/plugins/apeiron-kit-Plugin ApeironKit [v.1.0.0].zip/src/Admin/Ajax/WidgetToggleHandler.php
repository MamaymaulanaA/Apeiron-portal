<?php

namespace ApeironKit\Admin\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Widget Toggle AJAX handler.
 *
 * Handles requests to enable/disable individual widgets
 * from the plugin dashboard. Includes strict whitelist
 * validation to prevent arbitrary values from being saved.
 *
 * @package ApeironKit
 * @since 1.0.0
 */
class WidgetToggleHandler {

	/**
	 * Option name for disabled widgets list.
	 */
	private const OPTION_NAME = 'apeiron_kit_disabled_widgets';

	/**
	 * AJAX nonce action.
	 */
	private const NONCE_ACTION = 'apeiron_widget_toggle';

	/**
	 * Strict whitelist of valid widget slugs.
	 *
	 * Only these values are accepted. Any other value
	 * will be rejected with an error response.
	 *
	 * @var string[]
	 */
	private const ALLOWED_WIDGETS = [
		'comment_dock',
		'pulse_countdown',
		'guest_manager',
		'clipboard_tap',
		'soundscape',
		'signal_form',
		'social_proof',
		'autoscroll',
	];

	/**
	 * Map of toggle slug => Elementor widget type.
	 *
	 * @var array<string, string>
	 */
	private const WIDGET_SLUG_TO_TYPE = [
		'comment_dock'    => 'apeiron-comment-dock',
		'pulse_countdown' => 'apeiron-pulse-countdown',
		'guest_manager'   => 'apeiron-guest-invitation-manager',
		'clipboard_tap'   => 'apeiron-clipboard-tap',
		'soundscape'      => 'apeiron-soundscape',
		'signal_form'     => 'apeiron-signal-form',
		'social_proof'    => 'apeiron-social-proof',
		'autoscroll'      => 'apeiron-autoscroll',
	];

	/**
	 * Register AJAX hooks.
	 */
	public function register(): void {
		add_action( 'wp_ajax_apeiron_toggle_widget', [ $this, 'handle_toggle' ] );
		add_action( 'wp_ajax_apeiron_check_widget_usage', [ $this, 'handle_check_usage' ] );
	}

	/**
	 * Handle widget toggle AJAX request.
	 *
	 * Security checks performed:
	 * 1. Nonce verification
	 * 2. Capability check (manage_options)
	 * 3. sanitize_key() on widget slug
	 * 4. Whitelist validation against ALLOWED_WIDGETS
	 * 5. Duplicate prevention in disabled array
	 */
	public function handle_toggle(): void {
		// 1. Verify nonce
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		// 2. Check capability
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [
				'message' => __( 'Anda tidak memiliki izin untuk mengubah pengaturan ini.', 'apeiron-kit' ),
			] );
		}

		// 3. Sanitize widget slug
		$widget = isset( $_POST['widget'] ) ? sanitize_key( wp_unslash( $_POST['widget'] ) ) : '';

		if ( empty( $widget ) ) {
			wp_send_json_error( [
				'message' => __( 'Widget slug tidak boleh kosong.', 'apeiron-kit' ),
			] );
		}

		// 4. Whitelist validation — reject any value not in the allowed list
		if ( ! in_array( $widget, self::ALLOWED_WIDGETS, true ) ) {
			wp_send_json_error( [
				'message' => __( 'Widget tidak dikenali.', 'apeiron-kit' ),
			] );
		}

		// Get desired state: 'on' = enable (remove from disabled), 'off' = disable (add to disabled)
		$state = isset( $_POST['state'] ) ? sanitize_key( wp_unslash( $_POST['state'] ) ) : '';

		if ( ! in_array( $state, [ 'on', 'off' ], true ) ) {
			wp_send_json_error( [
				'message' => __( 'State tidak valid. Gunakan "on" atau "off".', 'apeiron-kit' ),
			] );
		}

		// Get current disabled list with type-safe default
		$disabled = get_option( self::OPTION_NAME, [] );

		// Guard: ensure value is always an array
		if ( ! is_array( $disabled ) ) {
			$disabled = [];
		}

		if ( 'off' === $state ) {
			// Disable widget: add to list, prevent duplicates
			if ( ! in_array( $widget, $disabled, true ) ) {
				$disabled[] = $widget;
			}
		} else {
			// Enable widget: remove from list
			$disabled = array_values( array_diff( $disabled, [ $widget ] ) );
		}

		// Sanitize entire array before saving — remove any invalid entries
		$disabled = array_values( array_filter( $disabled, function ( $slug ) {
			return in_array( $slug, self::ALLOWED_WIDGETS, true );
		} ) );

		// Save with autoload enabled (accessed every frontend request)
		update_option( self::OPTION_NAME, $disabled, true );

		// Schedule Elementor CSS cache clear AFTER response is sent (non-blocking).
		// This avoids making the user wait for file-system operations.
		add_action( 'shutdown', static function () {
			if ( class_exists( '\Elementor\Plugin' )
				&& isset( \Elementor\Plugin::$instance->files_manager )
			) {
				\Elementor\Plugin::$instance->files_manager->clear_cache();
			}
		} );

		wp_send_json_success( [
			'message' => 'off' === $state
				? __( 'Widget berhasil dinonaktifkan.', 'apeiron-kit' )
				: __( 'Widget berhasil diaktifkan.', 'apeiron-kit' ),
			'widget'   => $widget,
			'state'    => $state,
			'disabled' => $disabled,
		] );
	}

	/**
	 * Get list of currently disabled widgets.
	 *
	 * @return string[]
	 */
	public function get_disabled_widgets(): array {
		$disabled = get_option( self::OPTION_NAME, [] );

		if ( ! is_array( $disabled ) ) {
			return [];
		}

		// Filter against whitelist to remove any stale/invalid entries
		return array_values( array_filter( $disabled, function ( $slug ) {
			return in_array( $slug, self::ALLOWED_WIDGETS, true );
		} ) );
	}

	/**
	 * Check if a specific widget is disabled.
	 *
	 * @param string $widget_slug Widget slug to check.
	 * @return bool True if widget is disabled.
	 */
	public function is_widget_disabled( string $widget_slug ): bool {
		return in_array( $widget_slug, $this->get_disabled_widgets(), true );
	}

	/**
	 * Get the nonce action string.
	 *
	 * @return string
	 */
	public static function get_nonce_action(): string {
		return self::NONCE_ACTION;
	}

	/**
	 * Get the option name.
	 *
	 * @return string
	 */
	public static function get_option_name(): string {
		return self::OPTION_NAME;
	}

	/**
	 * Get the list of allowed widget slugs.
	 *
	 * @return string[]
	 */
	public static function get_allowed_widgets(): array {
		return self::ALLOWED_WIDGETS;
	}

	/**
	 * Handle widget usage check AJAX request.
	 *
	 * Scans _elementor_data across all posts to count how many
	 * pages use a specific widget. Uses a single SQL LIKE query
	 * for performance (no JSON decode per row).
	 */
	public function handle_check_usage(): void {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [
				'message' => __( 'Tidak memiliki izin.', 'apeiron-kit' ),
			] );
		}

		$widget = isset( $_POST['widget'] ) ? sanitize_key( wp_unslash( $_POST['widget'] ) ) : '';

		if ( ! in_array( $widget, self::ALLOWED_WIDGETS, true ) ) {
			wp_send_json_error( [
				'message' => __( 'Widget tidak dikenali.', 'apeiron-kit' ),
			] );
		}

		$widget_type = self::WIDGET_SLUG_TO_TYPE[ $widget ] ?? '';

		if ( empty( $widget_type ) ) {
			wp_send_json_success( [ 'count' => 0, 'pages' => [] ] );
		}

		global $wpdb;

		// Single SQL query — search for widget type string in serialized Elementor data
		// This avoids loading and decoding every post's JSON
		$results = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.ID, p.post_title
			 FROM {$wpdb->postmeta} pm
			 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE pm.meta_key = '_elementor_data'
			   AND pm.meta_value LIKE %s
			   AND p.post_status IN ('publish', 'draft', 'private')
			 LIMIT 50",
			'%"widgetType":"' . $wpdb->esc_like( $widget_type ) . '"%'
		) );

		$pages = [];
		foreach ( $results as $row ) {
			$pages[] = [
				'id'       => (int) $row->ID,
				'title'    => $row->post_title ?: __( '(Tanpa Judul)', 'apeiron-kit' ),
				'edit_url' => get_edit_post_link( (int) $row->ID, 'raw' ),
			];
		}

		wp_send_json_success( [
			'used'  => count( $pages ) > 0,
			'count' => count( $pages ),
			'pages' => $pages,
		] );
	}
}
