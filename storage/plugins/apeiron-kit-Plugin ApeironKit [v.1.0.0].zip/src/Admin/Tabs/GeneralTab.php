<?php

namespace ApeironKit\Admin\Tabs;

/**
 * General settings tab - main plugin settings page.
 */
class GeneralTab extends AbstractTab {

	/**
	 * @inheritDoc
	 */
	public function get_slug(): string {
		return 'apeiron-kit';
	}

	/**
	 * @inheritDoc
	 */
	public function get_title(): string {
		return __( 'Pengaturan Apeiron Kit', 'apeiron-kit' );
	}

	/**
	 * @inheritDoc
	 */
	public function render(): void {
		$options = get_option( $this->get_option_name(), [] );
		$comment_moderation = $options['comment_moderation'] ?? 'auto';
		?>
		<div class="wrap apeiron-settings-wrap">
			<div class="apeiron-settings-header">
				<div>
					<h1><?php esc_html_e( 'Pengaturan Apeiron Kit', 'apeiron-kit' ); ?></h1>
					<p><?php esc_html_e( 'Kelola preferensi dan konfigurasi plugin', 'apeiron-kit' ); ?></p>
				</div>
			</div>
			
			<!-- Status Card -->
			<div class="apeiron-status-card">
				<div class="apeiron-status-row">
					<div class="apeiron-status-main">
						<div class="apeiron-status-icon">
							<span class="dashicons dashicons-admin-settings"></span>
						</div>
						<div class="apeiron-status-info">
							<h2><?php esc_html_e( 'Apeiron Kit', 'apeiron-kit' ); ?></h2>
							<span><?php printf( esc_html__( 'Versi %s', 'apeiron-kit' ), defined( 'APEIRON_KIT_VERSION' ) ? APEIRON_KIT_VERSION : '1.0.0' ); ?></span>
						</div>
					</div>
					<div class="apeiron-quick-links">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=apeiron-kit-license' ) ); ?>" class="apeiron-quick-link">
							<span class="dashicons dashicons-admin-network" style="font-size:16px;width:16px;height:16px"></span>
							<?php esc_html_e( 'Lisensi', 'apeiron-kit' ); ?>
						</a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=apeiron-kit-stickers' ) ); ?>" class="apeiron-quick-link">
							<span class="dashicons dashicons-images-alt2" style="font-size:16px;width:16px;height:16px"></span>
							<?php esc_html_e( 'Stiker', 'apeiron-kit' ); ?>
						</a>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=apeiron-kit-social-proof' ) ); ?>" class="apeiron-quick-link">
							<span class="dashicons dashicons-megaphone" style="font-size:16px;width:16px;height:16px"></span>
							<?php esc_html_e( 'Social Proof', 'apeiron-kit' ); ?>
						</a>
					</div>
				</div>
			</div>

			<div class="apeiron-grid">
				<div>
					<!-- General Settings Card -->
					<?php $this->render_settings_card( $comment_moderation ); ?>

					<!-- Features Overview -->
					<?php $this->render_features_card(); ?>
				</div>

				<!-- Sidebar -->
				<div>
					<?php $this->render_sidebar(); ?>
				</div>
			</div>
		</div>

		<?php $this->render_inline_script(); ?>
		<?php
	}

	/**
	 * Render settings card with form.
	 *
	 * @param string $comment_moderation Current moderation setting.
	 */
	private function render_settings_card( string $comment_moderation ): void {
		?>
		<div class="apeiron-card">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--green">
					<span class="dashicons dashicons-admin-generic"></span>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'Preferensi Umum', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php esc_html_e( 'Pengaturan dasar untuk widget Apeiron Kit', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<form action="options.php" method="post" id="apeiron-settings-form">
				<?php settings_fields( 'apeiron_kit_settings' ); ?>

				<div class="apeiron-form-group">
					<label class="apeiron-label">
						<?php esc_html_e( 'Moderasi Komentar', 'apeiron-kit' ); ?>
					</label>
					<select name="<?php echo esc_attr( $this->get_option_name() ); ?>[comment_moderation]" class="apeiron-select">
						<option value="auto" <?php selected( $comment_moderation, 'auto' ); ?>>
							<?php esc_html_e( 'Terbit otomatis', 'apeiron-kit' ); ?>
						</option>
						<option value="manual" <?php selected( $comment_moderation, 'manual' ); ?>>
							<?php esc_html_e( 'Tahan untuk ditinjau', 'apeiron-kit' ); ?>
						</option>
					</select>
					<p class="apeiron-hint">
						<?php esc_html_e( 'Pilih apakah komentar langsung diterbitkan atau perlu ditinjau terlebih dahulu.', 'apeiron-kit' ); ?>
					</p>
				</div>

				<div class="apeiron-actions">
					<button type="submit" class="apeiron-btn apeiron-btn--primary" id="save-settings-btn">
						<span class="dashicons dashicons-saved" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
						<?php esc_html_e( 'Simpan Pengaturan', 'apeiron-kit' ); ?>
					</button>
				</div>
			</form>

			<div id="settings-message" class="apeiron-toast"></div>
		</div>
		<?php
	}

	/**
	 * Render features overview card with toggle switches.
	 */
	private function render_features_card(): void {
		$disabled = get_option( 'apeiron_kit_disabled_widgets', [] );
		if ( ! is_array( $disabled ) ) {
			$disabled = [];
		}

		$features = [
			[ 'slug' => 'comment_dock',     'icon' => 'format-chat',       'color' => 'green',  'label' => __( 'Comment Dock', 'apeiron-kit' ) ],
			[ 'slug' => 'pulse_countdown',  'icon' => 'clock',             'color' => 'purple', 'label' => __( 'Countdown Timer', 'apeiron-kit' ) ],
			[ 'slug' => 'guest_manager',    'icon' => 'groups',            'color' => 'blue',   'label' => __( 'Guest Manager', 'apeiron-kit' ) ],
			[ 'slug' => 'clipboard_tap',    'icon' => 'clipboard',         'color' => 'amber',  'label' => __( 'Clipboard Tap', 'apeiron-kit' ) ],
			[ 'slug' => 'soundscape',       'icon' => 'controls-volumeon', 'color' => 'pink',   'label' => __( 'Audio MP3', 'apeiron-kit' ) ],
			[ 'slug' => 'signal_form',      'icon' => 'share',             'color' => 'teal',   'label' => __( 'Signal Form', 'apeiron-kit' ) ],
			[ 'slug' => 'social_proof',     'icon' => 'megaphone',         'color' => 'amber',  'label' => __( 'Social Proof', 'apeiron-kit' ) ],
			[ 'slug' => 'autoscroll',       'icon' => 'arrow-down-alt',    'color' => 'purple', 'label' => __( 'Auto Scroll', 'apeiron-kit' ) ],
		];
		?>
		<div class="apeiron-card" style="margin-top:24px">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--blue">
					<span class="dashicons dashicons-screenoptions"></span>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'Widget Tersedia', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php esc_html_e( 'Aktifkan atau nonaktifkan widget sesuai kebutuhan', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<div class="apeiron-feature-grid">
				<?php foreach ( $features as $feature ) :
					$is_active = ! in_array( $feature['slug'], $disabled, true );
				?>
					<div class="apeiron-feature">
						<div class="apeiron-feature__icon apeiron-feature__icon--<?php echo esc_attr( $feature['color'] ); ?>">
							<span class="dashicons dashicons-<?php echo esc_attr( $feature['icon'] ); ?>"></span>
						</div>
						<span class="apeiron-feature__text"><?php echo esc_html( $feature['label'] ); ?></span>
						<label class="apeiron-toggle">
							<input type="checkbox"
								class="apeiron-widget-toggle"
								data-widget="<?php echo esc_attr( $feature['slug'] ); ?>"
								<?php checked( $is_active ); ?>
							/>
							<span class="apeiron-toggle__slider"></span>
						</label>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render sidebar cards.
	 */
	private function render_sidebar(): void {
		?>
		<div class="apeiron-sidebar-card" style="margin-bottom:16px">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
				<?php esc_html_e( 'Tips Pengaturan', 'apeiron-kit' ); ?>
			</h4>
			<ul>
				<li><?php esc_html_e( 'Gunakan "Tahan untuk ditinjau" untuk moderasi komentar spam', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Perubahan berlaku untuk semua widget baru', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Pastikan lisensi aktif untuk akses penuh', 'apeiron-kit' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Pengaturan ini dapat di-override pada setiap widget individual.', 'apeiron-kit' ); ?></p>
		</div>

		<div class="apeiron-sidebar-card">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
				<?php esc_html_e( 'Butuh Bantuan?', 'apeiron-kit' ); ?>
			</h4>
			<ul>
				<li><?php esc_html_e( 'Pastikan Elementor sudah aktif', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Periksa status lisensi jika widget tidak muncul', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Clear cache setelah mengubah pengaturan', 'apeiron-kit' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Hubungi support jika mengalami kendala.', 'apeiron-kit' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render inline JavaScript for settings form and widget toggles.
	 */
	private function render_inline_script(): void {
		$nonce = wp_create_nonce( \ApeironKit\Admin\Ajax\WidgetToggleHandler::get_nonce_action() );

		// Build widget label map for modal display
		$widget_labels = [
			'comment_dock'    => __( 'Comment Dock', 'apeiron-kit' ),
			'pulse_countdown' => __( 'Countdown Timer', 'apeiron-kit' ),
			'guest_manager'   => __( 'Guest Manager', 'apeiron-kit' ),
			'clipboard_tap'   => __( 'Clipboard Tap', 'apeiron-kit' ),
			'soundscape'      => __( 'Audio MP3', 'apeiron-kit' ),
			'signal_form'     => __( 'Signal Form', 'apeiron-kit' ),
			'social_proof'    => __( 'Social Proof', 'apeiron-kit' ),
			'autoscroll'      => __( 'Auto Scroll', 'apeiron-kit' ),
		];
		?>

		<!-- Widget Usage Warning Modal -->
		<div id="apeiron-usage-modal" class="apeiron-modal" style="display:none">
			<div class="apeiron-modal__backdrop"></div>
			<div class="apeiron-modal__dialog">
				<div class="apeiron-modal__header">
					<svg class="apeiron-modal__icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d63638" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
					<span class="apeiron-modal__title"><?php esc_html_e( 'Widget Sedang Digunakan', 'apeiron-kit' ); ?></span>
				</div>
				<p class="apeiron-modal__desc" id="apeiron-modal-desc"></p>
				<ul class="apeiron-modal__pages" id="apeiron-modal-pages"></ul>
				<p class="apeiron-modal__warning"><?php esc_html_e( 'Menonaktifkan widget bisa merusak layout halaman tersebut.', 'apeiron-kit' ); ?></p>
				<div class="apeiron-modal__actions">
					<button type="button" class="apeiron-btn apeiron-btn--secondary" id="apeiron-modal-cancel"><?php esc_html_e( 'Batal', 'apeiron-kit' ); ?></button>
					<button type="button" class="apeiron-btn apeiron-btn--danger" id="apeiron-modal-confirm"><?php esc_html_e( 'Nonaktifkan', 'apeiron-kit' ); ?></button>
				</div>
			</div>
		</div>

		<!-- Toast Notification -->
		<div id="apeiron-toast" class="apeiron-toast-container"></div>

		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var widgetLabels = <?php echo wp_json_encode( $widget_labels ); ?>;

			// --- Toast ---
			var toastTimer = null;
			function showToast(message, type) {
				var $c = $('#apeiron-toast');
				if (toastTimer) { clearTimeout(toastTimer); toastTimer = null; }
				var icons = {
					success: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#68de7c" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>',
					error:   '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>',
					loading: '<span class="apeiron-toast-spinner"></span>'
				};
				$c.html('<div class="apeiron-toast-item">' + (icons[type] || '') + '<span>' + message + '</span></div>');
				$c.removeClass('is-visible is-hiding').addClass('is-visible');
				if (type !== 'loading') {
					toastTimer = setTimeout(function() { dismissToast(); }, type === 'error' ? 4000 : 3000);
				}
			}
			function dismissToast() {
				var $c = $('#apeiron-toast');
				if (!$c.hasClass('is-visible')) return;
				$c.addClass('is-hiding');
				setTimeout(function() { $c.removeClass('is-visible is-hiding').empty(); }, 200);
			}

			$('#apeiron-settings-form').on('submit', function(e) {
				var $btn = $('#save-settings-btn');
				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Menyimpan...', 'apeiron-kit' ) ); ?>');
			});

			// --- Modal ---
			var $modal  = $('#apeiron-usage-modal');
			var modalCb = null;

			function showModal(widget, count, pages) {
				var label = widgetLabels[widget] || widget;
				$('#apeiron-modal-desc').text(
					label + ' <?php echo esc_js( __( 'digunakan di', 'apeiron-kit' ) ); ?> ' + count + ' <?php echo esc_js( __( 'halaman:', 'apeiron-kit' ) ); ?>'
				);
				var $list = $('#apeiron-modal-pages').empty();
				$.each(pages, function(i, p) {
					var $li = $('<li>');
					$li.append($('<span>').text(p.title));
					if (p.edit_url) {
						$li.append(' <a href="' + p.edit_url + '" target="_blank" class="apeiron-modal__edit-link"><span class="dashicons dashicons-edit" style="font-size:14px;width:14px;height:14px;vertical-align:middle"></span></a>');
					}
					$list.append($li);
				});
				$modal.css('display', 'flex');
				$modal[0].offsetHeight;
				$modal.addClass('is-visible');
			}

			function hideModal() {
				$modal.removeClass('is-visible');
				setTimeout(function() { $modal.css('display', 'none'); }, 200);
			}

			function dismissModal(proceed) {
				hideModal();
				if (modalCb) modalCb(proceed);
				modalCb = null;
			}

			$('#apeiron-modal-cancel').on('click', function() { dismissModal(false); });
			$('#apeiron-modal-confirm').on('click', function() { dismissModal(true); });
			$('.apeiron-modal__backdrop').on('click', function() { dismissModal(false); });

			// --- Widget toggle handler (optimistic UI) ---
			$('.apeiron-widget-toggle').on('change', function() {
				var $toggle  = $(this);
				var $label   = $toggle.closest('.apeiron-toggle');
				var widget   = $toggle.data('widget');
				var isOn     = $toggle.is(':checked');

				if ($toggle.data('ajax-busy')) {
					$toggle.prop('checked', !isOn);
					return;
				}

				if (!isOn) {
					// Disabling: check usage first
					$toggle.data('ajax-busy', true);
					showToast('<?php echo esc_js( __( 'Memeriksa penggunaan...', 'apeiron-kit' ) ); ?>', 'loading');

					$.ajax({
						url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
						type: 'POST',
						data: {
							action: 'apeiron_check_widget_usage',
							nonce:  '<?php echo esc_js( $nonce ); ?>',
							widget: widget
						},
						success: function(response) {
							dismissToast();
							if (response.success && response.data.count > 0) {
								modalCb = function(proceed) {
									if (proceed) {
										doToggle($toggle, $label, widget, 'off');
									} else {
										$toggle.prop('checked', true);
										$toggle.data('ajax-busy', false);
									}
								};
								showModal(widget, response.data.count, response.data.pages);
							} else {
								doToggle($toggle, $label, widget, 'off');
							}
						},
						error: function() {
							dismissToast();
							doToggle($toggle, $label, widget, 'off');
						}
					});
				} else {
					// Enabling: direct toggle (no usage check needed)
					$toggle.data('ajax-busy', true);
					doToggle($toggle, $label, widget, 'on');
				}
			});

			function doToggle($toggle, $label, widget, state) {
				var label = widgetLabels[widget] || widget;
				showToast(label + ' <?php echo esc_js( __( 'sedang diproses...', 'apeiron-kit' ) ); ?>', 'loading');

				$.ajax({
					url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
					type: 'POST',
					data: {
						action: 'apeiron_toggle_widget',
						nonce:  '<?php echo esc_js( $nonce ); ?>',
						widget: widget,
						state:  state
					},
					success: function(response) {
						if (response.success) {
							var msg = state === 'on'
								? label + ' <?php echo esc_js( __( 'berhasil diaktifkan', 'apeiron-kit' ) ); ?>'
								: label + ' <?php echo esc_js( __( 'berhasil dinonaktifkan', 'apeiron-kit' ) ); ?>';
							showToast(msg, 'success');
						} else {
							// Revert toggle on failure
							$toggle.prop('checked', state !== 'on');
							showToast('<?php echo esc_js( __( 'Gagal mengubah status widget', 'apeiron-kit' ) ); ?>', 'error');
						}
					},
					error: function() {
						$toggle.prop('checked', state !== 'on');
						showToast('<?php echo esc_js( __( 'Gagal mengubah status widget', 'apeiron-kit' ) ); ?>', 'error');
					},
					complete: function() {
						$toggle.data('ajax-busy', false);
					}
				});
			}
		});
		</script>

		<style>
		/* Toggle switch */
		.apeiron-feature { display:flex; align-items:center; gap:10px; }
		.apeiron-toggle { position:relative; display:inline-block; width:36px; height:20px; margin-left:auto; flex-shrink:0; cursor:pointer; }
		.apeiron-toggle input { opacity:0; width:0; height:0; }
		.apeiron-toggle__slider { position:absolute; inset:0; background:#ccd0d4; border-radius:20px; transition:background .2s ease, opacity .2s ease; }
		.apeiron-toggle__slider::before { content:''; position:absolute; width:14px; height:14px; left:3px; bottom:3px; background:#fff; border-radius:50%; transition:transform .2s ease; }
		.apeiron-toggle input:checked + .apeiron-toggle__slider { background:#083c57; }
		.apeiron-toggle input:checked + .apeiron-toggle__slider::before { transform:translateX(16px); }
		.apeiron-toggle input:disabled + .apeiron-toggle__slider { opacity:.5; cursor:wait; }

		/* Toast notification */
		.apeiron-toast-container { position:fixed; bottom:32px; left:50%; transform:translateX(-50%) translateY(8px); z-index:100200; pointer-events:none; opacity:0; transition:opacity .2s ease, transform .2s ease; }
		.apeiron-toast-container.is-visible { opacity:1; transform:translateX(-50%) translateY(0); }
		.apeiron-toast-container.is-hiding { opacity:0; transform:translateX(-50%) translateY(8px); }
		.apeiron-toast-item { display:inline-flex; align-items:center; gap:8px; background:#083C57; color:#fff; font-size:13px; line-height:1.4; padding:10px 18px; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,.18); max-width:300px; white-space:nowrap; }
		.apeiron-toast-spinner { display:inline-block; width:14px; height:14px; border:2px solid rgba(255,255,255,.25); border-top-color:#fff; border-radius:50%; animation:apeironSpin .6s linear infinite; flex-shrink:0; }
		@keyframes apeironSpin { to { transform:rotate(360deg); } }

		/* Usage warning modal */
		.apeiron-modal { position:fixed; inset:0; z-index:100100; display:none; align-items:center; justify-content:center; opacity:0; transition:opacity .15s ease; }
		.apeiron-modal.is-visible { opacity:1; }
		.apeiron-modal__backdrop { position:absolute; inset:0; background:rgba(0,0,0,.35); }
		.apeiron-modal__dialog { position:relative; background:#fff; border-radius:10px; padding:20px; max-width:340px; width:88%; text-align:left; box-shadow:0 6px 24px rgba(0,0,0,.12); transform:translateY(8px) scale(.97); transition:transform .15s ease; }
		.apeiron-modal.is-visible .apeiron-modal__dialog { transform:translateY(0) scale(1); }
		.apeiron-modal__header { display:flex; align-items:center; gap:8px; margin-bottom:10px; }
		.apeiron-modal__icon { flex-shrink:0; }
		.apeiron-modal__title { font-size:14px; font-weight:600; color:#1d2327; margin:0; }
		.apeiron-modal__desc { font-size:12px; color:#646970; margin:0 0 8px; line-height:1.4; }
		.apeiron-modal__pages { list-style:none; margin:0 0 10px; padding:0; max-height:120px; overflow-y:auto; background:#f9f9f9; border-radius:6px; }
		.apeiron-modal__pages li { padding:5px 10px; font-size:12px; color:#1d2327; border-bottom:1px solid #f0f0f1; display:flex; align-items:center; justify-content:space-between; }
		.apeiron-modal__pages li:last-child { border-bottom:0; }
		.apeiron-modal__edit-link { color:#2271b1; text-decoration:none; flex-shrink:0; margin-left:6px; }
		.apeiron-modal__edit-link:hover { color:#135e96; }
		.apeiron-modal__warning { font-size:11px; color:#996800; border-left:3px solid #dba617; background:#fcf9e8; border-radius:0 4px 4px 0; padding:6px 10px; margin:0 0 14px; line-height:1.4; }
		.apeiron-modal__actions { display:flex; gap:8px; justify-content:flex-end; }
		.apeiron-btn--secondary { background:#f0f0f1; color:#50575e; border:1px solid #c3c4c7; padding:6px 14px; border-radius:6px; cursor:pointer; font-size:12px; font-weight:500; transition:background .15s; }
		.apeiron-btn--secondary:hover { background:#e0e0e0; }
		.apeiron-btn--danger { background:#d63638; color:#fff; border:1px solid #d63638; padding:6px 14px; border-radius:6px; cursor:pointer; font-size:12px; font-weight:500; transition:background .15s; }
		.apeiron-btn--danger:hover { background:#b32d2e; }
		</style>
		<?php
	}
}
