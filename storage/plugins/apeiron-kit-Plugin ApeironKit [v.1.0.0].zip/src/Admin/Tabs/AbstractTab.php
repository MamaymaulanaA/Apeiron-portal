<?php

namespace ApeironKit\Admin\Tabs;

/**
 * Abstract Tab class for admin settings tabs.
 */
abstract class AbstractTab {

	/**
	 * Get tab slug.
	 *
	 * @return string
	 */
	abstract public function get_slug(): string;

	/**
	 * Get tab title.
	 *
	 * @return string
	 */
	abstract public function get_title(): string;

	/**
	 * Render tab content.
	 *
	 * @return void
	 */
	abstract public function render(): void;

	/**
	 * Get option name for settings.
	 *
	 * @return string
	 */
	protected function get_option_name(): string {
		return 'apeiron_kit_settings';
	}

	/**
	 * Get plugin URL.
	 *
	 * @return string
	 */
	protected function get_plugin_url(): string {
		return APEIRON_KIT_URL;
	}

	/**
	 * Get plugin path.
	 *
	 * @return string
	 */
	protected function get_plugin_path(): string {
		return APEIRON_KIT_PATH;
	}
}
