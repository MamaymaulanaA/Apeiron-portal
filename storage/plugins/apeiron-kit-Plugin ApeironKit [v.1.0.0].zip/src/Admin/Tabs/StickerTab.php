<?php

namespace ApeironKit\Admin\Tabs;

/**
 * Sticker management tab.
 */
class StickerTab extends AbstractTab {

	/**
	 * @inheritDoc
	 */
	public function get_slug(): string {
		return 'apeiron-kit-stickers';
	}

	/**
	 * @inheritDoc
	 */
	public function get_title(): string {
		return __( 'Stiker', 'apeiron-kit' );
	}

	/**
	 * @inheritDoc
	 */
	public function render(): void {
		$default_folder = 'assets/stickers/gift';
		$folder = isset( $_GET['folder'] ) ? sanitize_text_field( $_GET['folder'] ) : $default_folder;
		$stickers = $this->load_stickers( $folder, true );
		$total_stickers = count( $stickers );
		$image_count = count( array_filter( $stickers, fn( $s ) => $s['type'] === 'image' ) );
		$video_count = $total_stickers - $image_count;
		?>
		<div class="wrap apeiron-sticker-wrap">
			<?php $this->render_header(); ?>

			<!-- Status Card -->
			<?php $this->render_status_card( $total_stickers, $image_count, $video_count ); ?>

			<div class="apeiron-grid">
				<div>
					<!-- Upload Card -->
					<?php $this->render_upload_card(); ?>

					<!-- Sticker Gallery -->
					<?php $this->render_gallery_card( $stickers, $total_stickers ); ?>
				</div>

				<!-- Sidebar -->
				<div>
					<?php $this->render_sidebar( $total_stickers, $image_count, $video_count ); ?>
				</div>
			</div>
		</div>

		<?php $this->render_inline_script( $folder ); ?>
		<?php
	}

	/**
	 * Load stickers from folder.
	 *
	 * @param string $folder Relative folder path.
	 * @param bool   $allow_video Allow video files.
	 * @return array
	 */
	private function load_stickers( string $folder, bool $allow_video = true ): array {
		$folder = trim( (string) $folder );
		if ( empty( $folder ) ) {
			return [];
		}

		$relative = ltrim( wp_normalize_path( $folder ), '/\\' );
		if ( empty( $relative ) ) {
			return [];
		}

		$base_path = trailingslashit( APEIRON_KIT_PATH ) . $relative;
		$base_url  = trailingslashit( APEIRON_KIT_URL ) . $relative;

		if ( ! is_dir( $base_path ) || ! is_readable( $base_path ) ) {
			return [];
		}

		$pattern = $allow_video 
			? '*.{png,jpg,jpeg,gif,svg,webp,webm,mp4}'
			: '*.{png,jpg,jpeg,gif,svg,webp}';
		
		$files = glob( trailingslashit( $base_path ) . $pattern, GLOB_BRACE );

		if ( empty( $files ) ) {
			return [];
		}

		$items = [];
		foreach ( $files as $file ) {
			$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
			$type = in_array( $ext, [ 'webm', 'mp4' ], true ) ? 'video' : 'image';
			
			if ( ! $allow_video && 'video' === $type ) {
				continue;
			}
			
			$items[] = [
				'id'       => md5( $file ),
				'url'      => trailingslashit( $base_url ) . basename( $file ),
				'relative' => trailingslashit( $relative ) . basename( $file ),
				'type'     => $type,
				'name'     => ucwords( str_replace( [ '-', '_' ], ' ', pathinfo( $file, PATHINFO_FILENAME ) ) ),
			];
		}

		return $items;
	}

	/**
	 * Render header.
	 */
	private function render_header(): void {
		?>
		<div class="apeiron-sticker-header">
			<div>
				<h1><?php esc_html_e( 'Kelola Stiker', 'apeiron-kit' ); ?></h1>
				<p><?php esc_html_e( 'Upload dan kelola koleksi stiker untuk widget undangan digital', 'apeiron-kit' ); ?></p>
			</div>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=apeiron-kit' ) ); ?>" class="apeiron-btn apeiron-btn--ghost">
				<span class="dashicons dashicons-arrow-left-alt" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
				<?php esc_html_e( 'Kembali', 'apeiron-kit' ); ?>
			</a>
		</div>
		<?php
	}

	/**
	 * Render status card.
	 */
	private function render_status_card( int $total, int $images, int $videos ): void {
		?>
		<div class="apeiron-status-card">
			<div class="apeiron-status-row">
				<div class="apeiron-status-main">
					<div class="apeiron-status-icon">
						<span class="dashicons dashicons-images-alt2"></span>
					</div>
					<div class="apeiron-status-info">
						<h2><?php printf( esc_html__( '%d Stiker', 'apeiron-kit' ), $total ); ?></h2>
						<span><?php esc_html_e( 'Tersedia di koleksi Anda', 'apeiron-kit' ); ?></span>
					</div>
				</div>
				<div class="apeiron-status-badges">
					<span class="apeiron-badge apeiron-badge--purple">
						<span class="dashicons dashicons-format-image" style="font-size:14px;width:14px;height:14px"></span>
						<?php printf( esc_html__( '%d Gambar', 'apeiron-kit' ), $images ); ?>
					</span>
					<span class="apeiron-badge apeiron-badge--blue">
						<span class="dashicons dashicons-video-alt3" style="font-size:14px;width:14px;height:14px"></span>
						<?php printf( esc_html__( '%d Video', 'apeiron-kit' ), $videos ); ?>
					</span>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render upload card.
	 */
	private function render_upload_card(): void {
		?>
		<div class="apeiron-card" style="margin-bottom:16px">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--purple">
					<span class="dashicons dashicons-cloud-upload"></span>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'Upload Stiker', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php esc_html_e( 'Tambah stiker baru ke koleksi', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<div class="apeiron-upload-zone" id="upload-zone">
				<input type="file" id="sticker-upload-input" accept=".png,.jpg,.jpeg,.gif,.svg,.webp,.webm,.mp4" multiple>
				<div class="apeiron-upload-zone__icon">
					<span class="dashicons dashicons-cloud-upload"></span>
				</div>
				<div class="apeiron-upload-zone__title"><?php esc_html_e( 'Klik atau seret file ke sini', 'apeiron-kit' ); ?></div>
				<div class="apeiron-upload-zone__hint"><?php esc_html_e( 'PNG, JPG, GIF, SVG, WebP, WebM, MP4', 'apeiron-kit' ); ?></div>
			</div>

			<div class="apeiron-progress" id="upload-progress">
				<div class="apeiron-progress__bar">
					<div class="apeiron-progress__fill" id="progress-fill"></div>
				</div>
				<div class="apeiron-progress__text" id="progress-text">0%</div>
			</div>

			<div id="upload-message" class="apeiron-toast"></div>
		</div>
		<?php
	}

	/**
	 * Render gallery card.
	 */
	private function render_gallery_card( array $stickers, int $total ): void {
		?>
		<div class="apeiron-card">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--pink">
					<span class="dashicons dashicons-format-gallery"></span>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'Koleksi Stiker', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php printf( esc_html__( '%d item tersedia', 'apeiron-kit' ), $total ); ?></p>
				</div>
			</div>

			<?php if ( empty( $stickers ) ) : ?>
				<div class="apeiron-empty">
					<div class="apeiron-empty__icon">
						<span class="dashicons dashicons-images-alt"></span>
					</div>
					<div class="apeiron-empty__title"><?php esc_html_e( 'Belum ada stiker', 'apeiron-kit' ); ?></div>
					<div class="apeiron-empty__text"><?php esc_html_e( 'Upload stiker pertama Anda menggunakan form di atas', 'apeiron-kit' ); ?></div>
				</div>
			<?php else : ?>
				<div class="apeiron-sticker-grid">
					<?php foreach ( $stickers as $sticker ) : ?>
						<div class="apeiron-sticker-item" data-path="<?php echo esc_attr( $sticker['relative'] ); ?>">
							<div class="apeiron-sticker-item__preview">
								<?php if ( 'video' === $sticker['type'] ) : ?>
									<video src="<?php echo esc_url( $sticker['url'] ); ?>" muted loop playsinline onmouseover="this.play()" onmouseout="this.pause();this.currentTime=0;"></video>
								<?php else : ?>
									<img src="<?php echo esc_url( $sticker['url'] ); ?>" alt="<?php echo esc_attr( $sticker['name'] ); ?>" loading="lazy">
								<?php endif; ?>
							</div>
							<div class="apeiron-sticker-item__info">
								<div class="apeiron-sticker-item__name" title="<?php echo esc_attr( $sticker['name'] ); ?>"><?php echo esc_html( $sticker['name'] ); ?></div>
								<span class="apeiron-sticker-item__type apeiron-sticker-item__type--<?php echo esc_attr( $sticker['type'] ); ?>">
									<span class="dashicons dashicons-<?php echo $sticker['type'] === 'video' ? 'video-alt3' : 'format-image'; ?>" style="font-size:10px;width:10px;height:10px"></span>
									<?php echo esc_html( ucfirst( $sticker['type'] ) ); ?>
								</span>
							</div>
							<button type="button" class="apeiron-sticker-item__delete" data-path="<?php echo esc_attr( $sticker['relative'] ); ?>" title="<?php esc_attr_e( 'Hapus', 'apeiron-kit' ); ?>">
								<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px"></span>
							</button>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render sidebar.
	 */
	private function render_sidebar( int $total, int $images, int $videos ): void {
		?>
		<div class="apeiron-sidebar-card" style="margin-bottom:16px">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="18" x2="15" y2="18"/><line x1="10" y1="22" x2="14" y2="22"/><path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/></svg>
				<?php esc_html_e( 'Tips Upload', 'apeiron-kit' ); ?>
			</h4>
			<ul>
				<li><?php esc_html_e( 'Gunakan WebP untuk gambar ringan', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Video pendek max 2-3 detik', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Resolusi optimal 200x200 px', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Nama file tanpa spasi', 'apeiron-kit' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Hapus stiker yang tidak terpakai untuk performa optimal.', 'apeiron-kit' ); ?></p>
		</div>

		<div class="apeiron-sidebar-card">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
				<?php esc_html_e( 'Statistik', 'apeiron-kit' ); ?>
			</h4>
			<div class="apeiron-stats">
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo esc_html( $total ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Total', 'apeiron-kit' ); ?></div>
				</div>
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo esc_html( $images ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Gambar', 'apeiron-kit' ); ?></div>
				</div>
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo esc_html( $videos ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Video', 'apeiron-kit' ); ?></div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render inline script.
	 */
	private function render_inline_script( string $folder ): void {
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var nonce = '<?php echo wp_create_nonce( 'apeiron_sticker_management' ); ?>';
			var folder = '<?php echo esc_js( $folder ); ?>';
			var ajaxUrl = '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';

			var $zone = $('#upload-zone');
			var $input = $('#sticker-upload-input');

			$zone.on('click', function(e) { 
				if (e.target !== $input[0]) {
					$input.trigger('click'); 
				}
			});

			$zone.on('dragover dragenter', function(e) { 
				e.preventDefault(); 
				$(this).addClass('dragover'); 
			}).on('dragleave dragend drop', function(e) { 
				e.preventDefault(); 
				$(this).removeClass('dragover'); 
			});

			$zone.on('drop', function(e) {
				var files = e.originalEvent.dataTransfer.files;
				if (files.length > 0) doUpload(files);
			});

			$input.on('change', function() {
				if (this.files.length > 0) doUpload(this.files);
			});

			function doUpload(files) {
				var formData = new FormData();
				for (var i = 0; i < files.length; i++) {
					formData.append('sticker_files[]', files[i]);
				}
				formData.append('action', 'apeiron_upload_sticker');
				formData.append('folder', folder);
				formData.append('allow_video', 'yes');
				formData.append('nonce', nonce);

				$('#upload-progress').show();
				$('#progress-fill').css('width', '0%');
				$('#progress-text').text('Uploading...');
				$('#upload-message').hide();

				$.ajax({
					url: ajaxUrl,
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					timeout: 120000,
					xhr: function() {
						var xhr = new XMLHttpRequest();
						xhr.upload.onprogress = function(e) {
							if (e.lengthComputable) {
								var pct = Math.round((e.loaded / e.total) * 100);
								$('#progress-fill').css('width', pct + '%');
								$('#progress-text').text(pct + '%');
							}
						};
						return xhr;
					},
					success: function(res) {
						$('#upload-progress').hide();
						if (res && res.success) {
							showToast('#upload-message', 'success', res.data?.message || 'Upload berhasil!');
							setTimeout(function() { location.reload(); }, 1200);
						} else {
							showToast('#upload-message', 'error', res.data?.message || 'Upload gagal');
						}
					},
					error: function(xhr, status, error) {
						$('#upload-progress').hide();
						var msg = 'Upload error';
						if (xhr.responseJSON?.data?.message) msg = xhr.responseJSON.data.message;
						else if (status === 'timeout') msg = 'Timeout - file terlalu besar';
						showToast('#upload-message', 'error', msg);
					}
				});
				
				$input.val('');
			}

			$(document).on('click', '.apeiron-sticker-item__delete', function(e) {
				e.stopPropagation();
				e.preventDefault();
				if (!confirm('<?php echo esc_js( __( 'Hapus stiker ini?', 'apeiron-kit' ) ); ?>')) return;

				var $btn = $(this);
				var $item = $btn.closest('.apeiron-sticker-item');
				var path = $btn.data('path');

				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:14px;width:14px;height:14px"></span>');

				$.ajax({
					url: ajaxUrl,
					type: 'POST',
					data: {
						action: 'apeiron_delete_sticker',
						sticker_path: path,
						nonce: nonce
					},
					success: function(res) {
						if (res && res.success) {
							$item.fadeOut(300, function() { 
								$(this).remove(); 
								setTimeout(function() { location.reload(); }, 500);
							});
						} else {
							alert(res?.data?.message || '<?php echo esc_js( __( 'Gagal menghapus.', 'apeiron-kit' ) ); ?>');
							$btn.prop('disabled', false).html('<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px"></span>');
						}
					},
					error: function() {
						alert('<?php echo esc_js( __( 'Terjadi kesalahan saat menghapus stiker.', 'apeiron-kit' ) ); ?>');
						$btn.prop('disabled', false).html('<span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px"></span>');
					}
				});
			});

			function showToast(sel, type, msg) {
				$(sel).removeClass('apeiron-toast--success apeiron-toast--error').addClass('apeiron-toast--' + type).text(msg).slideDown(200);
			}
		});
		</script>
		<?php
	}
}
