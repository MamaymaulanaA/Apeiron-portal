<?php

namespace ApeironKit\Admin\Tabs;

use ApeironKit\Admin\Ajax\SocialProofHandler;

/**
 * Social Proof management tab.
 */
class SocialProofTab extends AbstractTab {

	private SocialProofHandler $handler;

	public function __construct() {
		$this->handler = new SocialProofHandler();
	}

	/**
	 * @inheritDoc
	 */
	public function get_slug(): string {
		return 'apeiron-kit-social-proof';
	}

	/**
	 * @inheritDoc
	 */
	public function get_title(): string {
		return __( 'Social Proof', 'apeiron-kit' );
	}

	/**
	 * @inheritDoc
	 */
	public function render(): void {
		$settings = $this->handler->get_settings();
		$entries = $settings['entries'] ?? [];
		$total_entries = count( $entries );
		?>
		<div class="wrap apeiron-sp-wrap">
			<!-- Header -->
			<?php $this->render_header( $total_entries ); ?>

			<div class="sp-grid">
				<div>
					<!-- Settings Card -->
					<?php $this->render_settings_card( $settings ); ?>

					<!-- Client Data Card -->
					<?php $this->render_client_data_card( $entries, $total_entries ); ?>
				</div>

				<!-- Preview Card -->
				<div>
					<?php $this->render_preview_card( $entries ); ?>
					<?php $this->render_tips_card(); ?>
				</div>
			</div>

			<!-- Toast -->
			<div id="sp-toast" class="sp-toast"></div>
		</div>

		<?php $this->render_inline_script(); ?>
		<?php
	}

	/**
	 * Render header.
	 */
	private function render_header( int $total_entries ): void {
		?>
		<div class="sp-header">
			<div class="sp-header-content">
				<div class="sp-header-left">
					<div class="sp-header-icon">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
					</div>
					<div>
						<h1><?php esc_html_e( 'Social Proof Generator', 'apeiron-kit' ); ?></h1>
						<p><?php esc_html_e( 'Tingkatkan kepercayaan pengunjung dengan notifikasi pembelian', 'apeiron-kit' ); ?></p>
					</div>
				</div>
				<div class="sp-stats">
					<div class="sp-stat">
						<div class="sp-stat__value"><?php echo esc_html( $total_entries ); ?></div>
						<div class="sp-stat__label"><?php esc_html_e( 'Total Client', 'apeiron-kit' ); ?></div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render settings card.
	 */
	private function render_settings_card( array $settings ): void {
		?>
		<div class="sp-card" style="margin-bottom:24px">
			<div class="sp-card__header">
				<div class="sp-card__header-left">
					<div class="sp-card__icon sp-card__icon--purple">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
					</div>
					<div>
						<h3 class="sp-card__title"><?php esc_html_e( 'Pengaturan Popup', 'apeiron-kit' ); ?></h3>
						<p class="sp-card__subtitle"><?php esc_html_e( 'Konfigurasi tampilan dan animasi', 'apeiron-kit' ); ?></p>
					</div>
				</div>
			</div>
			<div class="sp-card__body">
				<form id="sp-settings-form">
					<div class="sp-form-row">
						<div class="sp-form-group">
							<label class="sp-label"><?php esc_html_e( 'Durasi Tampil', 'apeiron-kit' ); ?></label>
							<select name="display_duration" class="sp-select">
								<?php for ( $i = 1; $i <= 10; $i++ ) : ?>
									<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $settings['display_duration'], $i ); ?>><?php echo esc_html( $i . ' detik' ); ?></option>
								<?php endfor; ?>
							</select>
						</div>
						<div class="sp-form-group">
							<label class="sp-label"><?php esc_html_e( 'Jeda Antar Popup', 'apeiron-kit' ); ?></label>
							<select name="interval_duration" class="sp-select">
								<?php for ( $i = 1; $i <= 10; $i++ ) : ?>
									<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $settings['interval_duration'], $i ); ?>><?php echo esc_html( $i . ' detik' ); ?></option>
								<?php endfor; ?>
							</select>
						</div>
					</div>

					<div class="sp-form-row">
						<div class="sp-form-group">
							<label class="sp-label"><?php esc_html_e( 'Jenis Animasi', 'apeiron-kit' ); ?></label>
							<select name="animation_type" class="sp-select">
								<option value="fade" <?php selected( $settings['animation_type'], 'fade' ); ?>>Fade</option>
								<option value="slide-top" <?php selected( $settings['animation_type'], 'slide-top' ); ?>>Slide dari Atas</option>
								<option value="slide-bottom" <?php selected( $settings['animation_type'], 'slide-bottom' ); ?>>Slide dari Bawah</option>
								<option value="slide-left" <?php selected( $settings['animation_type'], 'slide-left' ); ?>>Slide dari Kiri</option>
								<option value="slide-right" <?php selected( $settings['animation_type'], 'slide-right' ); ?>>Slide dari Kanan</option>
							</select>
						</div>
						<div class="sp-form-group">
							<label class="sp-label"><?php esc_html_e( 'Posisi Popup', 'apeiron-kit' ); ?></label>
							<select name="popup_position" class="sp-select">
								<option value="top-right" <?php selected( $settings['popup_position'], 'top-right' ); ?>>Atas Kanan</option>
								<option value="top-left" <?php selected( $settings['popup_position'], 'top-left' ); ?>>Atas Kiri</option>
								<option value="bottom-right" <?php selected( $settings['popup_position'], 'bottom-right' ); ?>>Bawah Kanan</option>
								<option value="bottom-left" <?php selected( $settings['popup_position'], 'bottom-left' ); ?>>Bawah Kiri</option>
							</select>
						</div>
					</div>

					<div class="sp-form-group">
						<label class="sp-label"><?php esc_html_e( 'Template Teks', 'apeiron-kit' ); ?></label>
						<input type="text" name="text_template" class="sp-input" value="<?php echo esc_attr( $settings['text_template'] ); ?>" placeholder="{name} telah membeli {product} pada:">
						<p class="sp-hint"><?php esc_html_e( 'Gunakan {name} untuk nama client dan {product} untuk nama produk/tema', 'apeiron-kit' ); ?></p>
					</div>

					<div class="sp-form-group">
						<label class="sp-label"><?php esc_html_e( 'Border Radius Foto Client', 'apeiron-kit' ); ?></label>
						<input type="number" name="image_border_radius" class="sp-input" value="<?php echo esc_attr( $settings['image_border_radius'] ?? 10 ); ?>" min="0" max="50" step="1">
						<p class="sp-hint"><?php esc_html_e( 'Atur border radius foto client (0 = tidak ada radius, 10 = default)', 'apeiron-kit' ); ?></p>
					</div>

					<div style="padding-top:20px;border-top:2px solid #f1f5f9;margin-top:12px">
						<button type="submit" class="sp-btn sp-btn--primary" style="width:100%;justify-content:center">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
							<span><?php esc_html_e( 'Simpan Pengaturan', 'apeiron-kit' ); ?></span>
						</button>
					</div>
				</form>
			</div>
		</div>
		<?php
	}

	/**
	 * Render client data card.
	 */
	private function render_client_data_card( array $entries, int $total_entries ): void {
		?>
		<div class="sp-card">
			<div class="sp-card__header">
				<div class="sp-card__header-left">
					<div class="sp-card__icon sp-card__icon--blue">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
					</div>
					<div>
						<h3 class="sp-card__title"><?php esc_html_e( 'Data Client', 'apeiron-kit' ); ?></h3>
						<p class="sp-card__subtitle"><?php printf( esc_html__( '%d client terdaftar', 'apeiron-kit' ), $total_entries ); ?></p>
					</div>
				</div>
			</div>
			<div class="sp-card__body">
				<!-- Add Entry Form -->
				<?php $this->render_add_entry_form(); ?>

				<!-- Entries List -->
				<?php $this->render_entries_list( $entries ); ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Render add entry form.
	 */
	private function render_add_entry_form(): void {
		?>
		<div class="sp-entry-form">
			<div class="sp-entry-form__title">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
				<span><?php esc_html_e( 'Tambah Client Baru', 'apeiron-kit' ); ?></span>
			</div>

			<div class="sp-form-row">
				<div class="sp-form-group">
					<label class="sp-label"><?php esc_html_e( 'Nama Client', 'apeiron-kit' ); ?> <span class="sp-label__required">*</span></label>
					<input type="text" id="entry-name" class="sp-input" placeholder="Contoh: Budi & Sari">
				</div>
				<div class="sp-form-group">
					<label class="sp-label"><?php esc_html_e( 'Nama Tema/Produk', 'apeiron-kit' ); ?> <span class="sp-label__required">*</span></label>
					<input type="text" id="entry-product" class="sp-input" placeholder="Contoh: Tema Elegant">
				</div>
			</div>

			<div class="sp-form-row">
				<div class="sp-form-group" style="width:100%">
					<label class="sp-label"><?php esc_html_e( 'Foto Client (Opsional)', 'apeiron-kit' ); ?></label>
					
					<!-- Upload Zone -->
					<div class="apeiron-upload-zone" id="client-photo-upload-zone">
						<input type="file" id="client-photo-upload-input" accept=".png,.jpg,.jpeg,.gif,.svg,.webp" style="display:none">
						<div class="apeiron-upload-zone__icon">
							<span class="dashicons dashicons-camera"></span>
						</div>
						<div class="apeiron-upload-zone__title"><?php esc_html_e( 'Klik atau seret foto ke sini', 'apeiron-kit' ); ?></div>
						<div class="apeiron-upload-zone__hint"><?php esc_html_e( 'PNG, JPG, GIF, SVG, WebP', 'apeiron-kit' ); ?></div>
					</div>

					<!-- Preview Area -->
					<div id="client-photo-preview" style="display:none">
						<div>
							<img id="client-photo-preview-img" src="" alt="Preview">
							<div id="client-photo-preview-info">
								<div class="preview-label">Foto Client</div>
								<div class="preview-filename" id="client-photo-filename">Foto terpilih</div>
							</div>
							<button type="button" id="remove-client-photo-btn" title="<?php esc_attr_e( 'Hapus Foto', 'apeiron-kit' ); ?>">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
							</button>
						</div>
					</div>

					<!-- Progress Bar -->
					<div class="apeiron-progress" id="client-photo-progress" style="display:none">
						<div class="apeiron-progress__bar">
							<div class="apeiron-progress__fill" id="client-photo-progress-fill"></div>
						</div>
						<div class="apeiron-progress__text" id="client-photo-progress-text">0%</div>
					</div>

					<!-- Hidden Input for Image URL -->
					<input type="hidden" id="entry-image" value="">
				</div>
				<div class="sp-form-group">
					<label class="sp-label"><?php esc_html_e( 'Tanggal & Waktu', 'apeiron-kit' ); ?> <span class="sp-label__required">*</span></label>
					<input type="datetime-local" id="entry-datetime" class="sp-input">
					<p class="sp-hint"><?php esc_html_e( 'Waktu pembelian yang akan ditampilkan', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<div style="margin-top:8px;padding-top:24px;border-top:2px solid #f1f5f9">
				<button type="button" id="add-entry-btn" class="sp-btn sp-btn--success" style="width:100%;justify-content:center">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
					<span><?php esc_html_e( 'Tambah Client', 'apeiron-kit' ); ?></span>
				</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Render entries list.
	 */
	private function render_entries_list( array $entries ): void {
		?>
		<div class="sp-entries" id="entries-list">
			<?php if ( empty( $entries ) ) : ?>
				<div class="sp-empty">
					<div class="sp-empty__icon">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
					</div>
					<div class="sp-empty__title"><?php esc_html_e( 'Belum ada data client', 'apeiron-kit' ); ?></div>
					<div class="sp-empty__text"><?php esc_html_e( 'Tambahkan data client untuk menampilkan notifikasi social proof', 'apeiron-kit' ); ?></div>
				</div>
			<?php else : ?>
				<?php foreach ( $entries as $index => $entry ) : 
					$entry_image = $entry['image'] ?? '';
					$entry_product = $entry['product'] ?? 'Apeiron';
					$datetime = ! empty( $entry['datetime'] ) ? date_i18n( 'j M Y, H:i', strtotime( $entry['datetime'] ) ) : '-';
				?>
					<div class="sp-entry" data-index="<?php echo esc_attr( $index ); ?>">
						<div class="sp-entry__avatar">
							<?php if ( ! empty( $entry_image ) ) : ?>
								<img src="<?php echo esc_url( $entry_image ); ?>" alt="<?php echo esc_attr( $entry['name'] ?? '' ); ?>">
							<?php else : ?>
								<span class="sp-entry__avatar-placeholder">
									<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
								</span>
							<?php endif; ?>
						</div>
						<div class="sp-entry__content">
							<div class="sp-entry__name"><?php echo esc_html( $entry['name'] ?? '' ); ?></div>
							<div class="sp-entry__meta">
								<span>
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
									<?php echo esc_html( $entry_product ); ?>
								</span>
								<span>
									<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
									<?php echo esc_html( $datetime ); ?>
								</span>
							</div>
						</div>
						<div class="sp-entry__actions">
							<button type="button" class="sp-btn sp-btn--danger sp-btn--sm delete-entry-btn" data-index="<?php echo esc_attr( $index ); ?>">
								<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
							</button>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render preview card.
	 */
	private function render_preview_card( array $entries ): void {
		$preview_image = ! empty( $entries ) && ! empty( $entries[0]['image'] ) ? $entries[0]['image'] : '';
		$preview_name = ! empty( $entries ) ? $entries[0]['name'] ?? 'Apeiron & Partners' : 'Apeiron & Partners';
		$preview_product = ! empty( $entries ) ? $entries[0]['product'] ?? 'Tema Elegant' : 'Tema Elegant';
		$preview_date = ! empty( $entries ) && ! empty( $entries[0]['datetime'] ) 
			? date_i18n( 'l, j F Y H:i (T)', strtotime( $entries[0]['datetime'] ) )
			: date_i18n( 'l, j F Y H:i (T)' );
		?>
		<div class="sp-card sp-preview-card">
			<div class="sp-card__header">
				<div class="sp-card__header-left">
					<div class="sp-card__icon sp-card__icon--amber">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
					</div>
					<div>
						<h3 class="sp-card__title"><?php esc_html_e( 'Preview', 'apeiron-kit' ); ?></h3>
						<p class="sp-card__subtitle"><?php esc_html_e( 'Tampilan notifikasi', 'apeiron-kit' ); ?></p>
					</div>
				</div>
			</div>
			<div class="sp-card__body" style="padding:0">
				<div class="sp-preview-area">
					<div class="sp-preview-popup" id="preview-popup">
						<div class="sp-preview-popup__img">
							<?php if ( ! empty( $preview_image ) ) : ?>
								<img src="<?php echo esc_url( $preview_image ); ?>" alt="Preview">
							<?php else : ?>
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
							<?php endif; ?>
						</div>
						<div class="sp-preview-popup__text">
							<div class="sp-preview-popup__name" id="preview-name"><?php echo esc_html( $preview_name ); ?></div>
							<div class="sp-preview-popup__desc">telah membeli <em id="preview-product"><?php echo esc_html( $preview_product ); ?></em> pada:</div>
							<div class="sp-preview-popup__date" id="preview-date"><?php echo esc_html( $preview_date ); ?></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render tips card.
	 */
	private function render_tips_card(): void {
		?>
		<div class="sp-card" style="margin-top:16px">
			<div class="sp-card__header">
				<div class="sp-card__header-left">
					<div class="sp-card__icon sp-card__icon--green">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
					</div>
					<div>
						<h3 class="sp-card__title"><?php esc_html_e( 'Tips', 'apeiron-kit' ); ?></h3>
					</div>
				</div>
			</div>
			<div class="sp-card__body" style="padding:16px 24px">
				<ul style="margin:0;padding:0 0 0 18px;font-size:13px;color:#64748b;line-height:1.8">
					<li><?php esc_html_e( 'Gunakan foto client berkualitas tinggi', 'apeiron-kit' ); ?></li>
					<li><?php esc_html_e( 'Tambahkan widget di Elementor untuk menampilkan popup', 'apeiron-kit' ); ?></li>
					<li><?php esc_html_e( 'Durasi 3-5 detik adalah waktu optimal', 'apeiron-kit' ); ?></li>
				</ul>
			</div>
		</div>
		<?php
	}

	/**
	 * Render inline script.
	 */
	private function render_inline_script(): void {
		$nonce = wp_create_nonce( SocialProofHandler::get_nonce_action() );
		$ajax_url = admin_url( 'admin-ajax.php' );
		?>
		<script type="text/javascript">
		(function($) {
			'use strict';
			
			function initSocialProof() {
				var nonce = '<?php echo esc_js( $nonce ); ?>';
				var ajaxUrl = '<?php echo esc_js( $ajax_url ); ?>';

				// Set default datetime
				var now = new Date();
				var dt = now.getFullYear() + '-' + String(now.getMonth()+1).padStart(2,'0') + '-' + String(now.getDate()).padStart(2,'0') + 'T' + String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
				$('#entry-datetime').val(dt);

				function showToast(type, msg) {
					var $t = $('#sp-toast');
					$t.removeClass('sp-toast--success sp-toast--error show').addClass('sp-toast--' + type).text(msg).addClass('show');
					setTimeout(function() { $t.removeClass('show'); }, 3000);
				}

				// Save settings
				$('#sp-settings-form').on('submit', function(e) {
					e.preventDefault();
					var $btn = $(this).find('button[type="submit"]');
					$btn.prop('disabled', true).text('Menyimpan...');
					$.post(ajaxUrl, { action: 'apeiron_save_social_proof', form_data: $(this).serialize(), nonce: nonce }, function(res) {
						showToast(res.success ? 'success' : 'error', res.success ? 'Tersimpan!' : (res.data?.message || 'Gagal'));
						$btn.prop('disabled', false).html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Simpan');
					});
				});

				// Add entry
				$('#add-entry-btn').on('click', function() {
					var name = $('#entry-name').val().trim();
					var product = $('#entry-product').val().trim();
					var image = $('#entry-image').val() || '';
					var datetime = $('#entry-datetime').val();

					if (!name) { showToast('error', 'Masukkan nama client'); $('#entry-name').focus(); return; }
					if (!product) { showToast('error', 'Masukkan nama produk'); $('#entry-product').focus(); return; }
					if (!datetime) { showToast('error', 'Pilih tanggal'); $('#entry-datetime').focus(); return; }

					var $btn = $(this);
					$btn.prop('disabled', true).text('Menambahkan...');

					$.post(ajaxUrl, {
						action: 'apeiron_save_social_proof',
						form_data: 'add_entry=1&entry_name=' + encodeURIComponent(name) + '&entry_product=' + encodeURIComponent(product) + '&entry_image=' + encodeURIComponent(image) + '&entry_datetime=' + encodeURIComponent(datetime),
						nonce: nonce
					}, function(res) {
						if (res.success) {
							showToast('success', 'Berhasil ditambahkan!');
							setTimeout(function() { location.reload(); }, 800);
						} else {
							showToast('error', res.data?.message || 'Gagal');
							$btn.prop('disabled', false).html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg> Tambah Client');
						}
					});
				});

				// Delete entry
				$(document).on('click', '.delete-entry-btn', function() {
					if (!confirm('Hapus data client ini?')) return;
					var $btn = $(this), index = $btn.data('index');
					$btn.prop('disabled', true);
					$.post(ajaxUrl, { action: 'apeiron_delete_social_proof_entry', entry_index: index, nonce: nonce }, function(res) {
						if (res.success) { location.reload(); }
						else { showToast('error', 'Gagal menghapus'); $btn.prop('disabled', false); }
					});
				});

				// Photo upload handlers
				var $uploadZone = $('#client-photo-upload-zone');
				var $uploadInput = $('#client-photo-upload-input');
				var $imageInput = $('#entry-image');
				var $preview = $('#client-photo-preview');
				var $previewImg = $('#client-photo-preview-img');
				var $removeBtn = $('#remove-client-photo-btn');
				var $progress = $('#client-photo-progress');
				var $progressFill = $('#client-photo-progress-fill');
				var $progressText = $('#client-photo-progress-text');

				$uploadZone.on('click', function(e) {
					if (e.target !== $uploadInput[0] && !$(e.target).closest('#remove-client-photo-btn').length) {
						$uploadInput.trigger('click');
					}
				});

				$uploadZone.on('dragover dragenter', function(e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).addClass('dragover');
				}).on('dragleave dragend', function(e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).removeClass('dragover');
				});

				$uploadZone.on('drop', function(e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).removeClass('dragover');
					var files = e.originalEvent.dataTransfer.files;
					if (files.length > 0) {
						doUploadClientPhoto(files[0]);
					}
				});

				$uploadInput.on('change', function() {
					if (this.files.length > 0) {
						doUploadClientPhoto(this.files[0]);
					}
				});

				function doUploadClientPhoto(file) {
					var allowedTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/svg+xml', 'image/webp'];
					if (allowedTypes.indexOf(file.type) === -1) {
						showToast('error', 'Format file tidak diizinkan.');
						return;
					}
					if (file.size > 5 * 1024 * 1024) {
						showToast('error', 'Ukuran file terlalu besar. Maksimal 5MB.');
						return;
					}

					var formData = new FormData();
					formData.append('action', 'apeiron_upload_client_photo');
					formData.append('client_photo', file);
					formData.append('nonce', nonce);

					$progress.show();
					$progressFill.css('width', '0%');
					$progressText.text('Uploading...');
					$uploadZone.hide();

					$.ajax({
						url: ajaxUrl,
						type: 'POST',
						data: formData,
						processData: false,
						contentType: false,
						timeout: 60000,
						xhr: function() {
							var xhr = new XMLHttpRequest();
							xhr.upload.onprogress = function(e) {
								if (e.lengthComputable) {
									var pct = Math.round((e.loaded / e.total) * 100);
									$progressFill.css('width', pct + '%');
									$progressText.text(pct + '%');
								}
							};
							return xhr;
						},
						success: function(res) {
							$progress.hide();
							if (res && res.success && res.data && res.data.url) {
								$imageInput.val(res.data.url);
								$previewImg.attr('src', res.data.url);
								var filename = file.name;
								if (filename.length > 25) filename = filename.substring(0, 22) + '...';
								$('#client-photo-filename').text(filename);
								$preview.show();
								$uploadZone.hide();
								updatePreview();
								showToast('success', res.data.message || 'Foto berhasil diupload!');
							} else {
								$uploadZone.show();
								showToast('error', res.data?.message || 'Upload gagal');
							}
						},
						error: function(xhr, status) {
							$progress.hide();
							$uploadZone.show();
							var msg = status === 'timeout' ? 'Timeout - file terlalu besar' : 'Upload error';
							showToast('error', msg);
						}
					});

					$uploadInput.val('');
				}

				$removeBtn.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					$imageInput.val('');
					$preview.hide();
					$uploadZone.show();
					updatePreview();
					showToast('success', 'Foto dihapus');
				});

				function updatePreview() {
					var name = $('#entry-name').val() || 'Nama Client';
					var product = $('#entry-product').val() || 'Tema';
					var image = $imageInput.val();
					var datetime = $('#entry-datetime').val();
					
					$('#preview-name').text(name);
					$('#preview-product').text(product);
					
					if (image) {
						$('#preview-popup .sp-preview-popup__img').html('<img src="' + image + '" style="width:100%;height:100%;object-fit:cover;">');
					} else {
						$('#preview-popup .sp-preview-popup__img').html('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>');
					}
					
					if (datetime) {
						try {
							var d = new Date(datetime);
							$('#preview-date').text(d.toLocaleDateString('id-ID', {weekday:'long',year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'}) + ' WIB');
						} catch(e) {}
					}
				}
				
				$('#entry-name, #entry-product').on('input', updatePreview);
				$('#entry-datetime').on('change', updatePreview);
				updatePreview();
			}
			
			$(document).ready(function() {
				initSocialProof();
			});
			
		})(jQuery);
		</script>
		<?php
	}
}
