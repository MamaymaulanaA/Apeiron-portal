<?php

namespace ApeironKit\Admin\Tabs;

use ApeironKit\Core\LicenseManager;
use ApeironKit\Core\ApiKeyManager;

/**
 * License management tab.
 */
class LicenseTab extends AbstractTab {

	private LicenseManager $license_manager;

	public function __construct() {
		$this->license_manager = LicenseManager::instance();
	}

	/**
	 * @inheritDoc
	 */
	public function get_slug(): string {
		return 'apeiron-kit-license';
	}

	/**
	 * @inheritDoc
	 */
	public function get_title(): string {
		return __( 'Lisensi', 'apeiron-kit' );
	}

	/**
	 * @inheritDoc
	 */
	public function render(): void {
		$license = $this->license_manager->get_license();
		$status_display = $this->license_manager->get_status_display();
		$current_api_url = $this->license_manager->get_api_url();
		
		$api_url_auto = defined( 'APEIRON_KIT_LICENSE_API_URL' ) && ! empty( APEIRON_KIT_LICENSE_API_URL );
		$api_key_auto = defined( 'APEIRON_KIT_LICENSE_API_KEY' ) && ! empty( APEIRON_KIT_LICENSE_API_KEY );
		
		$api_key_manager = new ApiKeyManager();
		$has_api_key = $api_key_manager->has_api_key();
		$can_edit_server_config = ! $api_url_auto || ! $api_key_auto;
		
		$is_lifetime = empty( $status_display['expires'] );
		$is_license_active = ! empty( $license['key'] ) && $status_display['is_valid'];
		
		$license_key_display = $this->get_license_key_display( $license, $is_license_active );
		?>
		<div class="wrap apeiron-license-wrap">
			<?php $this->render_header(); ?>
			
			<!-- Status Card -->
			<?php $this->render_status_card( $license, $status_display, $is_license_active, $is_lifetime, $license_key_display ); ?>

			<div class="apeiron-grid">
				<div>
					<!-- API Key Configuration -->
					<?php $this->render_api_key_card( $api_key_auto, $has_api_key ); ?>

					<!-- License Key -->
					<?php $this->render_license_key_card( $license, $is_license_active, $license_key_display, $status_display ); ?>
				</div>

				<!-- Sidebar -->
				<div>
					<?php $this->render_sidebar(); ?>
				</div>
			</div>
		</div>

		<?php $this->render_inline_script( $api_url_auto, $api_key_auto, $current_api_url, $has_api_key, $license ); ?>
		<?php
	}

	/**
	 * Get masked license key for display.
	 */
	private function get_license_key_display( array $license, bool $is_license_active ): string {
		if ( empty( $license['key'] ) ) {
			return '';
		}

		if ( $is_license_active ) {
			$key_parts = explode( '-', $license['key'] );
			if ( count( $key_parts ) > 1 ) {
				$last_part = end( $key_parts );
				return 'XXXX-XXXX-XXXX-' . substr( $last_part, -4 );
			}
			return 'XXXX-' . substr( $license['key'], -4 );
		}

		return $license['key'];
	}

	/**
	 * Render page header.
	 */
	private function render_header(): void {
		?>
		<div class="apeiron-license-header">
			<div>
				<h1><?php esc_html_e( 'Manajemen Lisensi', 'apeiron-kit' ); ?></h1>
				<p><?php esc_html_e( 'Kelola lisensi dan koneksi server untuk Apeiron Kit', 'apeiron-kit' ); ?></p>
			</div>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=apeiron-kit' ) ); ?>" class="apeiron-btn apeiron-btn--ghost">
				<span class="dashicons dashicons-arrow-left-alt" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
				<?php esc_html_e( 'Kembali', 'apeiron-kit' ); ?>
			</a>
		</div>
		<?php
	}

	/**
	 * Render status card.
	 */
	private function render_status_card( array $license, array $status_display, bool $is_license_active, bool $is_lifetime, string $license_key_display ): void {
		?>
		<div class="apeiron-status-card <?php echo $is_license_active ? 'is-active' : ( ! empty( $license['key'] ) ? 'is-inactive' : '' ); ?>">
			<div class="apeiron-status-row">
				<div class="apeiron-status-main">
					<div class="apeiron-status-icon <?php echo $is_license_active ? 'is-active' : ( ! empty( $license['key'] ) ? 'is-inactive' : 'is-pending' ); ?>">
						<?php if ( $is_license_active ) : ?>
							<span class="dashicons dashicons-yes-alt"></span>
						<?php elseif ( ! empty( $license['key'] ) ) : ?>
							<span class="dashicons dashicons-warning"></span>
						<?php else : ?>
							<span class="dashicons dashicons-admin-network"></span>
						<?php endif; ?>
					</div>
					<div class="apeiron-status-info">
						<h2>
							<?php 
							if ( $is_license_active ) {
								esc_html_e( 'Lisensi Aktif', 'apeiron-kit' );
							} elseif ( ! empty( $license['key'] ) ) {
								echo esc_html( $status_display['info']['label'] );
							} else {
								esc_html_e( 'Belum Diaktifkan', 'apeiron-kit' );
							}
							?>
						</h2>
						<span>
							<?php 
							if ( ! empty( $license_key_display ) ) {
								echo esc_html( $license_key_display );
							} else {
								esc_html_e( 'Masukkan license key untuk mengaktifkan', 'apeiron-kit' );
							}
							?>
						</span>
					</div>
				</div>
				<div class="apeiron-status-badges">
					<?php if ( $is_license_active ) : ?>
						<?php if ( $is_lifetime ) : ?>
							<span class="apeiron-badge apeiron-badge--success">
								<span class="dashicons dashicons-awards" style="font-size:14px;width:14px;height:14px"></span>
								<?php esc_html_e( 'Lifetime', 'apeiron-kit' ); ?>
							</span>
						<?php elseif ( ! empty( $status_display['expires'] ) ) : ?>
							<span class="apeiron-badge apeiron-badge--info">
								<span class="dashicons dashicons-calendar-alt" style="font-size:14px;width:14px;height:14px"></span>
								<?php echo esc_html( date_i18n( 'd M Y', strtotime( $status_display['expires'] ) ) ); ?>
							</span>
						<?php endif; ?>
						<?php if ( $status_display['limit'] > 0 ) : ?>
							<span class="apeiron-badge apeiron-badge--muted">
								<?php echo esc_html( $status_display['activations'] ); ?>/<?php echo esc_html( $status_display['limit'] ); ?> <?php esc_html_e( 'Aktivasi', 'apeiron-kit' ); ?>
							</span>
						<?php endif; ?>
					<?php elseif ( ! empty( $license['key'] ) ) : ?>
						<span class="apeiron-badge apeiron-badge--warning">
							<span class="dashicons dashicons-info" style="font-size:14px;width:14px;height:14px"></span>
							<?php esc_html_e( 'Perlu Validasi', 'apeiron-kit' ); ?>
						</span>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render API Key configuration card (without URL input).
	 */
	private function render_api_key_card( bool $api_key_auto, bool $has_api_key ): void {
		?>
		<div class="apeiron-card" style="margin-bottom:24px">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--blue">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'API Key', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php esc_html_e( 'Kunci autentikasi untuk koneksi ke license server', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<div class="apeiron-form-group">
				<label class="apeiron-label">
					<?php esc_html_e( 'API Key', 'apeiron-kit' ); ?><span>*</span>
				</label>
				<input 
					type="password" 
					id="api-key-input" 
					class="apeiron-input apeiron-input--mono"
					placeholder="<?php echo esc_attr( $has_api_key ? '••••••••••••••••••••••••' : 'Masukkan API Key' ); ?>"
					<?php echo $api_key_auto ? 'readonly' : ''; ?>
				>
				<p class="apeiron-hint">
				<?php
					if ( $api_key_auto ) {
						esc_html_e( 'Dikonfigurasi via constant (tidak dapat diubah)', 'apeiron-kit' );
					} elseif ( $has_api_key ) {
						esc_html_e( 'API Key tersimpan. Kosongkan jika tidak ingin mengubah.', 'apeiron-kit' );
					} else {
						esc_html_e( 'Masukkan API Key untuk menghubungkan ke license server', 'apeiron-kit' );
					}
				?>
				</p>
			</div>

			<?php if ( ! $api_key_auto ) : ?>
			<div class="apeiron-actions" style="border-top:none;padding-top:0;margin-top:8px">
				<button type="button" class="apeiron-btn apeiron-btn--primary" id="save-api-key-btn">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
					<?php esc_html_e( 'Simpan API Key', 'apeiron-kit' ); ?>
				</button>
				<button type="button" class="apeiron-btn apeiron-btn--outline" id="test-server-connection-btn">
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
					<?php esc_html_e( 'Test Koneksi', 'apeiron-kit' ); ?>
				</button>
			</div>
			<?php endif; ?>

			<div id="server-config-message" class="apeiron-toast"></div>
		</div>
		<?php
	}

	/**
	 * Render license key card.
	 */
	private function render_license_key_card( array $license, bool $is_license_active, string $license_key_display, array $status_display ): void {
		?>
		<div class="apeiron-card">
			<div class="apeiron-card__header">
				<div class="apeiron-card__icon apeiron-card__icon--green">
					<span class="dashicons dashicons-admin-network"></span>
				</div>
				<div>
					<h3 class="apeiron-card__title"><?php esc_html_e( 'License Key', 'apeiron-kit' ); ?></h3>
					<p class="apeiron-card__subtitle"><?php esc_html_e( 'Aktivasi dan kelola license key', 'apeiron-kit' ); ?></p>
				</div>
			</div>

			<?php if ( $is_license_active ) : ?>
				<div class="apeiron-key-display" style="margin-bottom:16px">
					<?php echo esc_html( $license_key_display ); ?>
				</div>
				<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:16px">
					<input type="checkbox" id="show-license-key-checkbox" style="width:16px;height:16px;cursor:pointer">
					<label for="show-license-key-checkbox" style="margin:0;font-size:13px;color:#475569;cursor:pointer">
						<?php esc_html_e( 'Ubah license key', 'apeiron-kit' ); ?>
					</label>
				</div>
				<div id="license-key-input-wrapper" style="display:none;margin-bottom:16px">
					<label class="apeiron-label"><?php esc_html_e( 'License Key Baru', 'apeiron-kit' ); ?></label>
					<input type="text" id="license-key-input" class="apeiron-input apeiron-input--mono" value="" placeholder="Masukkan license key baru">
				</div>
			<?php else : ?>
				<div class="apeiron-form-group">
					<label class="apeiron-label"><?php esc_html_e( 'License Key', 'apeiron-kit' ); ?></label>
					<input type="text" id="license-key-input" class="apeiron-input apeiron-input--mono" value="<?php echo esc_attr( $license['key'] ?? '' ); ?>" placeholder="APEIRON-XXXX-XXXX-XXXX-XXXX">
				</div>
			<?php endif; ?>

			<div class="apeiron-actions">
				<?php if ( empty( $license['key'] ) ) : ?>
					<button type="button" class="apeiron-btn apeiron-btn--primary" id="license-activate-btn">
						<span class="dashicons dashicons-yes" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
						<?php esc_html_e( 'Aktifkan', 'apeiron-kit' ); ?>
					</button>
				<?php else : ?>
					<button type="button" class="apeiron-btn apeiron-btn--primary" id="license-activate-btn">
						<span class="dashicons dashicons-update" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
						<?php esc_html_e( 'Aktifkan / Ubah', 'apeiron-kit' ); ?>
					</button>
					<button type="button" class="apeiron-btn apeiron-btn--outline" id="license-check-btn">
						<span class="dashicons dashicons-search" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
						<?php esc_html_e( 'Periksa Status', 'apeiron-kit' ); ?>
					</button>
					<button type="button" class="apeiron-btn apeiron-btn--danger" id="license-deactivate-btn">
						<span class="dashicons dashicons-no" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span>
						<?php esc_html_e( 'Nonaktifkan', 'apeiron-kit' ); ?>
					</button>
				<?php endif; ?>
			</div>

			<div id="license-message" class="apeiron-toast"></div>

			<?php if ( ! empty( $license['key'] ) && ! empty( $status_display['last_check'] ) ) : ?>
			<div class="apeiron-stats">
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo esc_html( date_i18n( 'd M', $status_display['last_check'] ) ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Terakhir Dicek', 'apeiron-kit' ); ?></div>
				</div>
				<?php if ( $status_display['limit'] > 0 ) : ?>
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo esc_html( $status_display['activations'] ); ?>/<?php echo esc_html( $status_display['limit'] ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Aktivasi', 'apeiron-kit' ); ?></div>
				</div>
				<?php endif; ?>
				<?php $is_lifetime = empty( $status_display['expires'] ); ?>
				<?php if ( $is_lifetime || ! empty( $status_display['expires'] ) ) : ?>
				<div class="apeiron-stat">
					<div class="apeiron-stat__value"><?php echo $is_lifetime ? '∞' : esc_html( date_i18n( 'd/m/y', strtotime( $status_display['expires'] ) ) ); ?></div>
					<div class="apeiron-stat__label"><?php esc_html_e( 'Kedaluwarsa', 'apeiron-kit' ); ?></div>
				</div>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render sidebar.
	 */
	private function render_sidebar(): void {
		?>
		<div class="apeiron-sidebar-card" style="margin-bottom:16px">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
				<?php esc_html_e( 'Tips Keamanan', 'apeiron-kit' ); ?>
			</h4>
			<ul>
				<li><?php esc_html_e( 'Selalu gunakan HTTPS untuk server lisensi', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Jangan bagikan API Key ke pihak lain', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Periksa status setelah migrasi hosting', 'apeiron-kit' ); ?></li>
			</ul>
			<p><?php esc_html_e( 'Status lisensi diperiksa otomatis setiap 24 jam.', 'apeiron-kit' ); ?></p>
		</div>

		<div class="apeiron-sidebar-card">
			<h4>
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083c57" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
				<?php esc_html_e( 'Butuh Bantuan?', 'apeiron-kit' ); ?>
			</h4>
			<ul>
				<li><?php esc_html_e( 'Cek API Key sudah benar dan aktif', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'License key bersifat case-sensitive', 'apeiron-kit' ); ?></li>
				<li><?php esc_html_e( 'Hubungi support jika ada masalah', 'apeiron-kit' ); ?></li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Render inline JavaScript.
	 */
	private function render_inline_script( bool $api_url_auto, bool $api_key_auto, string $current_api_url, bool $has_api_key, array $license ): void {
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var nonce = '<?php echo wp_create_nonce( 'apeiron_license_management' ); ?>';
			var apiKeyRequired = <?php echo $api_key_auto ? 'false' : 'true'; ?>;
			var hasApiKey = <?php echo $has_api_key ? 'true' : 'false'; ?>;

			$('#show-license-key-checkbox').on('change', function() {
				$('#license-key-input-wrapper').slideToggle(200);
			});

			$('#save-api-key-btn').on('click', function() {
				var $btn = $(this);
				var apiKey = $('#api-key-input').val().trim();
				// API URL - prioritize: saved option > constant > default
				var apiUrl = '<?php echo esc_js( $current_api_url ?: 'https://server-apeiron.web.id/api' ); ?>';

				if (apiKeyRequired && !apiKey && !hasApiKey) { showToast('#server-config-message', 'error', '<?php echo esc_js( __( 'Masukkan API Key.', 'apeiron-kit' ) ); ?>'); return; }

				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Menyimpan...', 'apeiron-kit' ) ); ?>');

				$.post(ajaxurl, { action: 'apeiron_save_server_config', api_url: apiUrl, api_key: apiKey, nonce: nonce }, function(res) {
					if (res.success) {
						showToast('#server-config-message', 'success', res.data.message || '<?php echo esc_js( __( 'Berhasil disimpan!', 'apeiron-kit' ) ); ?>');
						setTimeout(function() { location.reload(); }, 1200);
					} else {
						showToast('#server-config-message', 'error', res.data.message || '<?php echo esc_js( __( 'Gagal menyimpan.', 'apeiron-kit' ) ); ?>');
						$btn.prop('disabled', false).html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> <?php echo esc_js( __( 'Simpan API Key', 'apeiron-kit' ) ); ?>');
					}
				}).fail(function() {
					showToast('#server-config-message', 'error', '<?php echo esc_js( __( 'Terjadi kesalahan.', 'apeiron-kit' ) ); ?>');
					$btn.prop('disabled', false).html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> <?php echo esc_js( __( 'Simpan API Key', 'apeiron-kit' ) ); ?>');
				});
			});

			$('#license-activate-btn').on('click', function() {
				var $btn = $(this);
				var $input = $('#license-key-input');
				var licenseKey = $input.length && $input.is(':visible') ? $input.val().trim() : '<?php echo esc_js( $license['key'] ?? '' ); ?>';

				if (!licenseKey) { showToast('#license-message', 'error', '<?php echo esc_js( __( 'Masukkan license key.', 'apeiron-kit' ) ); ?>'); return; }

				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Mengaktifkan...', 'apeiron-kit' ) ); ?>');

				$.post(ajaxurl, { action: 'apeiron_activate_license', license_key: licenseKey, nonce: nonce }, function(res) {
					if (res.success) {
						showToast('#license-message', 'success', res.data.message || '<?php echo esc_js( __( 'Lisensi aktif!', 'apeiron-kit' ) ); ?>');
						setTimeout(function() { location.reload(); }, 1200);
					} else {
						showToast('#license-message', 'error', res.data.message || '<?php echo esc_js( __( 'Gagal mengaktifkan.', 'apeiron-kit' ) ); ?>');
						$btn.prop('disabled', false).html('<span class="dashicons dashicons-update" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Aktifkan / Ubah', 'apeiron-kit' ) ); ?>');
					}
				}).fail(function() {
					showToast('#license-message', 'error', '<?php echo esc_js( __( 'Terjadi kesalahan.', 'apeiron-kit' ) ); ?>');
					$btn.prop('disabled', false).html('<span class="dashicons dashicons-update" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Aktifkan / Ubah', 'apeiron-kit' ) ); ?>');
				});
			});

			$('#license-check-btn').on('click', function() {
				var $btn = $(this);
				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Memeriksa...', 'apeiron-kit' ) ); ?>');

				$.post(ajaxurl, { action: 'apeiron_check_license', nonce: nonce }, function(res) {
					if (res.success) {
						showToast('#license-message', 'success', res.data.message || '<?php echo esc_js( __( 'Status diperbarui!', 'apeiron-kit' ) ); ?>');
						setTimeout(function() { location.reload(); }, 1200);
					} else {
						showToast('#license-message', 'error', res.data.message || '<?php echo esc_js( __( 'Gagal memeriksa.', 'apeiron-kit' ) ); ?>');
						$btn.prop('disabled', false).html('<span class="dashicons dashicons-search" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Periksa Status', 'apeiron-kit' ) ); ?>');
					}
				}).fail(function() {
					showToast('#license-message', 'error', '<?php echo esc_js( __( 'Terjadi kesalahan.', 'apeiron-kit' ) ); ?>');
					$btn.prop('disabled', false).html('<span class="dashicons dashicons-search" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Periksa Status', 'apeiron-kit' ) ); ?>');
				});
			});

			$('#license-deactivate-btn').on('click', function() {
				if (!confirm('<?php echo esc_js( __( 'Yakin ingin menonaktifkan lisensi?', 'apeiron-kit' ) ); ?>')) return;
				var $btn = $(this);
				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Menonaktifkan...', 'apeiron-kit' ) ); ?>');

				$.post(ajaxurl, { action: 'apeiron_deactivate_license', nonce: nonce }, function(res) {
					if (res.success) {
						showToast('#license-message', 'success', res.data.message || '<?php echo esc_js( __( 'Lisensi dinonaktifkan.', 'apeiron-kit' ) ); ?>');
						setTimeout(function() { location.reload(); }, 1200);
					} else {
						showToast('#license-message', 'error', res.data.message || '<?php echo esc_js( __( 'Gagal menonaktifkan.', 'apeiron-kit' ) ); ?>');
						$btn.prop('disabled', false).html('<span class="dashicons dashicons-no" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Nonaktifkan', 'apeiron-kit' ) ); ?>');
					}
				}).fail(function() {
					showToast('#license-message', 'error', '<?php echo esc_js( __( 'Terjadi kesalahan.', 'apeiron-kit' ) ); ?>');
					$btn.prop('disabled', false).html('<span class="dashicons dashicons-no" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Nonaktifkan', 'apeiron-kit' ) ); ?>');
				});
			});

			$('#test-server-connection-btn').on('click', function() {
				var $btn = $(this);
				$btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s linear infinite;font-size:16px;width:16px;height:16px"></span> <?php echo esc_js( __( 'Menguji...', 'apeiron-kit' ) ); ?>');

				$.post(ajaxurl, { action: 'apeiron_test_server_connection', nonce: nonce }, function(res) {
					if (res.success) {
						showToast('#server-config-message', 'success', res.data.message || '<?php echo esc_js( __( 'Koneksi berhasil!', 'apeiron-kit' ) ); ?>');
					} else {
						var errorMsg = res.data.message || '<?php echo esc_js( __( 'Koneksi gagal.', 'apeiron-kit' ) ); ?>';
						if (res.data.error_code) {
							errorMsg += ' (Error: ' + res.data.error_code + ')';
						}
						showToast('#server-config-message', 'error', errorMsg);
					}
					$btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-network" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Test Koneksi', 'apeiron-kit' ) ); ?>');
				}).fail(function() {
					showToast('#server-config-message', 'error', '<?php echo esc_js( __( 'Terjadi kesalahan saat menguji koneksi.', 'apeiron-kit' ) ); ?>');
					$btn.prop('disabled', false).html('<span class="dashicons dashicons-admin-network" style="font-size:16px;width:16px;height:16px;line-height:1.1"></span> <?php echo esc_js( __( 'Test Koneksi', 'apeiron-kit' ) ); ?>');
				});
			});

			function showToast(selector, type, msg) {
				$(selector).removeClass('apeiron-toast--success apeiron-toast--error').addClass('apeiron-toast--' + type).text(msg).slideDown(200);
			}
		});
		</script>
		<?php
	}
}
