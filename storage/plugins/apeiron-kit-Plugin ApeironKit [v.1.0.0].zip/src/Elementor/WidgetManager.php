<?php

namespace ApeironKit\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Elements_Manager;
use Elementor\Widgets_Manager;
use ApeironKit\Elementor\Widgets\AutoScroll;
use ApeironKit\Elementor\Widgets\ClipboardTap;
use ApeironKit\Elementor\Widgets\CommentDock;
use ApeironKit\Elementor\Widgets\GuestInvitationManager;
use ApeironKit\Elementor\Widgets\PulseCountdown;
use ApeironKit\Elementor\Widgets\SignalForm;
use ApeironKit\Elementor\Widgets\SocialProof;
use ApeironKit\Elementor\Widgets\SoundscapePlayer;

class WidgetManager {

	/**
	 * Option name for disabled widgets.
	 */
	private const OPTION_NAME = 'apeiron_kit_disabled_widgets';

	/**
	 * Map of widget class => toggle slug.
	 *
	 * The toggle slug must match the values used in
	 * WidgetToggleHandler::ALLOWED_WIDGETS.
	 *
	 * @var array<class-string, string>
	 */
	private const WIDGET_MAP = [
		PulseCountdown::class        => 'pulse_countdown',
		SoundscapePlayer::class      => 'soundscape',
		SignalForm::class            => 'signal_form',
		ClipboardTap::class          => 'clipboard_tap',
		CommentDock::class           => 'comment_dock',
		GuestInvitationManager::class => 'guest_manager',
		AutoScroll::class            => 'autoscroll',
		SocialProof::class           => 'social_proof',
	];

	/**
	 * @var string[]
	 */
	private array $widgets = [
		PulseCountdown::class,
		SoundscapePlayer::class,
		SignalForm::class,
		ClipboardTap::class,
		CommentDock::class,
		GuestInvitationManager::class,
		AutoScroll::class,
		SocialProof::class,
	];

	public function register(): void {
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_category' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );
	}

	public function register_category( Elements_Manager $manager ): void {
		$manager->add_category(
			'apeiron-kit',
			[
				'title' => __( 'Apeiron Kit', 'apeiron-kit' ),
				'icon'  => 'fa fa-puzzle-piece',
			]
		);
	}

	public function register_widgets( Widgets_Manager $manager ): void {
		$disabled = $this->get_disabled_widgets();

		foreach ( $this->widgets as $widget_class ) {
			// Skip disabled widgets
			$slug = self::WIDGET_MAP[ $widget_class ] ?? '';
			if ( $slug && in_array( $slug, $disabled, true ) ) {
				continue;
			}

			if ( class_exists( $widget_class ) ) {
				$manager->register( new $widget_class() );
			}
		}
	}

	/**
	 * Get the widget map (class => slug).
	 *
	 * @return array<class-string, string>
	 */
	public function get_widget_map(): array {
		return self::WIDGET_MAP;
	}

	/**
	 * Retrieve the disabled widgets list with type-safe fallback.
	 *
	 * Always returns a clean array, even if the option is
	 * missing, corrupted, or contains an unexpected data type.
	 *
	 * @return string[]
	 */
	private function get_disabled_widgets(): array {
		$disabled = get_option( self::OPTION_NAME, [] );

		if ( ! is_array( $disabled ) ) {
			return [];
		}

		return $disabled;
	}
}

