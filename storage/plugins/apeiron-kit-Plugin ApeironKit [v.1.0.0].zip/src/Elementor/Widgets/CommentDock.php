<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Repeater;

class CommentDock extends BaseWidget {

	public function get_name() {
		return 'apeiron-comment-dock';
	}

	public function get_title() {
		return __( 'Comment Panel', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-comment';
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-comment-dock';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-comment-dock-js' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}

		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'Pengaturan', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'comments_limit',
			[
				'label'       => __( 'Jumlah Komentar Ditampilkan', 'apeiron-kit' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 10,
				'min'         => 1,
				'max'         => 200,
				'description' => __( 'Semua komentar akan ditampilkan dalam satu container. Jika jumlah komentar melebihi limit, container akan menjadi scrollable.', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'scrollable_height',
			[
				'label'     => __( 'Tinggi Container Scrollable', 'apeiron-kit' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units'=> [ 'px' ],
				'range'     => [
					'px' => [
						'min' => 200,
						'max' => 800,
					],
				],
				'default'   => [
					'size' => 400,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-list-scrollable' => 'max-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'list_display_mode',
			[
				'label'   => __( 'Tampilan Daftar', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => [
					'auto'   => __( 'Tinggi otomatis', 'apeiron-kit' ),
					'scroll' => __( 'Scroll', 'apeiron-kit' ),
				],
			]
		);

		$this->add_control(
			'list_scroll_height',
			[
				'label'     => __( 'Tinggi Scroll', 'apeiron-kit' ),
				'type'      => Controls_Manager::SLIDER,
				'size_units'=> [ 'px' ],
				'range'     => [
					'px' => [
						'min' => 120,
						'max' => 600,
					],
				],
				'default'   => [
					'size' => 320,
					'unit' => 'px',
				],
				'condition' => [
					'list_display_mode' => 'scroll',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-list.is-scrollable' => 'max-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'use_pagination',
			[
				'label'        => __( 'Gunakan Pagination', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'separator'    => 'before',
				'description' => __( 'Tampilkan tombol next/prev untuk navigasi komentar', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'items_per_page',
			[
				'label'     => __( 'Jumlah per Halaman', 'apeiron-kit' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 5,
				'min'       => 1,
				'max'       => 50,
				'condition' => [
					'use_pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'prev_text',
			[
				'label'     => __( 'Teks Previous', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( '← Previous', 'apeiron-kit' ),
				'condition' => [
					'use_pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'next_text',
			[
				'label'     => __( 'Teks Next', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Next →', 'apeiron-kit' ),
				'condition' => [
					'use_pagination' => 'yes',
				],
			]
		);

		$this->add_control(
			'show_heading',
			[
				'label'        => __( 'Tampilkan Judul', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Judul', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Ucapan & Doa', 'apeiron-kit' ),
				'label_block' => true,
				'condition'   => [
					'show_heading' => 'yes',
				],
			]
		);

		$this->add_control(
			'name_placeholder',
			[
				'label'       => __( 'Placeholder Nama', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Isikan nama lengkap', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'name_label',
			[
				'label'       => __( 'Label Nama', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Nama Lengkap', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'message_placeholder',
			[
				'label'       => __( 'Placeholder Pesan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Tulis ucapan terbaikmu...', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'message_label',
			[
				'label'       => __( 'Label Ucapan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Ucapan', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_stickers',
			[
				'label'        => __( 'Aktifkan Sticker Picker', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'sticker_label',
			[
				'label'       => __( 'Label Sticker', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Sticker', 'apeiron-kit' ),
				'label_block' => true,
				'condition'   => [
					'show_stickers' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticker_allow_image',
			[
				'label'        => __( 'Izinkan Gambar Sticker', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Jika dinonaktifkan, file gambar tidak akan ditampilkan (tidak termasuk .png, .jpg, .jpeg, .gif, .svg, .webp).', 'apeiron-kit' ),
				'condition'    => [
					'show_stickers' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticker_allow_video',
			[
				'label'        => __( 'Izinkan Video Sticker', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Jika dinonaktifkan, file video tidak akan ditampilkan (tidak termasuk .webm, .mp4).', 'apeiron-kit' ),
				'condition'    => [
					'show_stickers' => 'yes',
				],
			]
		);

		$this->add_control(
			'sticker_note',
			[
				'raw'             => __( '<b>Catatan:</b> Sistem stiker bersifat dinamis dan otomatis. Semua file yang ada di folder akan otomatis muncul sebagai pilihan stiker. Untuk mengelola stiker (upload/hapus), silakan kunjungi <a href="' . admin_url( 'admin.php?page=apeiron-kit&tab=stickers' ) . '" target="_blank">Apeiron Kit Settings > Kelola Stiker</a>. Pastikan folder hanya berisi file gambar (.png, .jpg, .webp, .gif) atau video pendek (.webm, .mp4).', 'apeiron-kit' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'condition'       => [
					'show_stickers' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// Attendance Section
		$this->start_controls_section(
			'section_attendance',
			[
				'label' => __( 'Kehadiran', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'attendance_label',
			[
				'label'       => __( 'Label Pilihan Kehadiran', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Konfirmasi Kehadiran', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$attendance = new Repeater();
		$attendance->add_control(
			'option_label',
			[
				'label'       => __( 'Teks Opsi', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Hadir', 'apeiron-kit' ),
				'label_block' => true,
			]
		);
		$attendance->add_control(
			'option_slug',
			[
				'label'       => __( 'Nilai (slug)', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => __( 'Opsional. Jika kosong, slug dibuat otomatis dari teks opsi. Tidak boleh spasi, gunakan huruf kecil.', 'apeiron-kit' ),
			]
		);
		$attendance->add_control(
			'option_icon',
			[
				'label'   => __( 'Ikon', 'apeiron-kit' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-check',
					'library' => 'fa-solid',
				],
			]
		);


		$this->add_control(
			'attendance_options',
			[
				'label'       => __( 'Daftar Opsi', 'apeiron-kit' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $attendance->get_controls(),
				'title_field' => '{{{ option_label }}}',
				'default'     => [
					[
						'option_label' => __( 'Hadir', 'apeiron-kit' ),
						'option_slug'  => 'hadir',
						'option_icon'  => [
							'value'   => 'fas fa-check',
							'library' => 'fa-solid',
						],
					],
					[
						'option_label' => __( 'Tidak Hadir', 'apeiron-kit' ),
						'option_slug'  => 'tidak-hadir',
						'option_icon'  => [
							'value'   => 'fas fa-times',
							'library' => 'fa-solid',
						],
					],
					[
						'option_label' => __( 'Masih Ragu', 'apeiron-kit' ),
						'option_slug'  => 'ragu',
						'option_icon'  => [
							'value'   => 'far fa-meh',
							'library' => 'fa-regular',
						],
					],
				],
			]
		);

		$this->add_control(
			'attendance_display',
			[
				'label'   => __( 'Tampilan Badge', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon'       => __( 'Ikon saja', 'apeiron-kit' ),
					'icon-label' => __( 'Ikon & teks', 'apeiron-kit' ),
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => __( 'Teks Tombol', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Kirim Ucapan', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'success_message',
			[
				'label'       => __( 'Pesan Sukses', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Terima kasih atas ucapannya!', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_avatar',
			[
				'label'        => __( 'Avatar', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'attendence',
			[
				'label'        => __( 'Attendence', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_date',
			[
				'label'        => __( 'Show Date', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'date_format_type',
			[
				'label'     => __( 'Format Waktu', 'apeiron-kit' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'relative',
				'options'   => [
					'relative' => __( 'Relatif (1 menit yang lalu)', 'apeiron-kit' ),
					'custom'   => __( 'Tanggal Lengkap (7 Desember 2025)', 'apeiron-kit' ),
					'default'  => __( 'Default WordPress', 'apeiron-kit' ),
				],
				'condition' => [
					'show_date' => 'yes',
				],
			]
		);

		$this->add_control(
			'default_avatar',
			[
				'label'     => __( 'Avatar Default', 'apeiron-kit' ),
				'type'      => Controls_Manager::MEDIA,
				'condition' => [
					'show_avatar' => 'yes',
				],
			]
		);


		$this->end_controls_section();


		$this->start_controls_section(
			'section_spacing',
			[
				'label' => __( 'Jarak', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'form_gap',
			[
				'label' => __( 'Jarak Form & Komentar', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
				],
				'default' => [
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'comment_gap',
			[
				'label' => __( 'Jarak antar Komentar', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'default' => [
					'size' => 24,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-item' => 'margin-bottom: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-kit-comment-item:last-child' => 'margin-bottom: 0; padding-bottom: 0;',
				],
			]
		);

		$this->add_responsive_control(
			'comment_padding_vertical',
			[
				'label' => __( 'Padding Vertikal Item', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 60,
					],
				],
				'default' => [
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-item' => 'padding-top: {{SIZE}}{{UNIT}}; padding-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_wrapper',
			[
				'label' => __( 'Wrapper', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'wrapper_background',
				'selector' => '{{WRAPPER}} .apeiron-comment-dock',
				'types'    => [ 'classic', 'gradient' ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wrapper_border',
				'selector' => '{{WRAPPER}} .apeiron-comment-dock',
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => __( 'Padding Wrapper', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-comment-dock' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'wrapper_radius',
			[
				'label'      => __( 'Border Radius Wrapper', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-comment-dock' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'wrapper_shadow',
				'selector' => '{{WRAPPER}} .apeiron-comment-dock',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_heading',
			[
				'label' => __( 'Judul', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'heading_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-heading',
			]
		);

		$this->add_control(
			'heading_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-heading' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'heading_alignment',
			[
				'label'     => __( 'Perataan', 'apeiron-kit' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Kiri', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Tengah', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Kanan', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-heading' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'heading_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Avatar Style
		$this->start_controls_section(
			'section_style_avatar',
			[
				'label' => __( 'Avatar', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'avatar_size',
			[
				'label' => __( 'Ukuran', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],
				],
				'default' => [
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-avatar img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'avatar_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-avatar img',
			]
		);

		$this->add_responsive_control(
			'avatar_radius',
			[
				'label'      => __( 'Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Comment Item Style
		$this->start_controls_section(
			'section_style_comment',
			[
				'label' => __( 'Item Komentar', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'comment_background',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-item',
				'exclude'  => [ 'image' ],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'comment_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-item',
			]
		);

		$this->add_responsive_control(
			'comment_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'comment_radius',
			[
				'label'      => __( 'Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Author Name Style
		$this->start_controls_section(
			'section_style_author',
			[
				'label' => __( 'Nama Pengirim', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'author_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-author',
			]
		);

		$this->add_control(
			'author_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-author' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Time Style
		$this->start_controls_section(
			'section_style_time',
			[
				'label' => __( 'Waktu', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'time_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-time',
			]
		);

		$this->add_control(
			'time_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-time' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Message Text Style
		$this->start_controls_section(
			'section_style_message',
			[
				'label' => __( 'Pesan', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'message_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-text',
			]
		);

		$this->add_control(
			'message_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Badge Style
		$this->start_controls_section(
			'section_style_badge',
			[
				'label' => __( 'Badge Kehadiran', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'badge_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-pill',
			]
		);

		$this->add_responsive_control(
			'badge_icon_size',
			[
				'label' => __( 'Ukuran Ikon', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 8,
						'max' => 32,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill-icon' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_gap',
			[
				'label' => __( 'Jarak Ikon & Teks', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 20,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'badge_radius',
			[
				'label'      => __( 'Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'badge_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-pill',
			]
		);

		// --- Warna Status (Index-Based) ---
		$this->add_control(
			'badge_status_colors_heading',
			[
				'label'     => __( 'Warna Status', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'bridge_info_note',
			[
				'raw'             => __( 'Warna berdasarkan <b>urutan item</b> di repeater (index), bukan berdasarkan nama/label. Item pertama = Status 1, item kedua = Status 2, dst. Item ke-4 dan seterusnya menggunakan warna Status 4+.', 'apeiron-kit' ),
				'type'            => Controls_Manager::RAW_HTML,
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			]
		);

		// --- Status 1 (Index 0) ---
		$this->add_control(
			'bridge_status_0_heading',
			[
				'label'     => __( '🟢 Status 1 (Item Pertama)', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'bridge_status_0_bg',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(5,150,105,.15)',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_0_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#047857',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0 .apeiron-kit-comment-pill-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_0_icon_color',
			[
				'label'     => __( 'Warna Icon', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#047857',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0 .apeiron-kit-comment-pill-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_0_border_color',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'bridge_status_0_border_width',
			[
				'label'      => __( 'Lebar Border', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-0' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		// --- Status 2 (Index 1) ---
		$this->add_control(
			'bridge_status_1_heading',
			[
				'label'     => __( '🔴 Status 2 (Item Kedua)', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'bridge_status_1_bg',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(239,68,68,.15)',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_1_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#dc2626',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1 .apeiron-kit-comment-pill-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_1_icon_color',
			[
				'label'     => __( 'Warna Icon', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#dc2626',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1 .apeiron-kit-comment-pill-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_1_border_color',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'bridge_status_1_border_width',
			[
				'label'      => __( 'Lebar Border', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-1' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		// --- Status 3 (Index 2) ---
		$this->add_control(
			'bridge_status_2_heading',
			[
				'label'     => __( '🟡 Status 3 (Item Ketiga)', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'bridge_status_2_bg',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(249,115,22,.15)',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_2_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f97316',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2 .apeiron-kit-comment-pill-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_2_icon_color',
			[
				'label'     => __( 'Warna Icon', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f97316',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2 .apeiron-kit-comment-pill-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_2_border_color',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'bridge_status_2_border_width',
			[
				'label'      => __( 'Lebar Border', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-2' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		// --- Status 4+ (Index >= 3) ---
		$this->add_control(
			'bridge_status_3plus_heading',
			[
				'label'     => __( '🔵 Status 4+ (Item Keempat dst)', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'bridge_status_3plus_bg',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(59,130,246,.15)',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_3plus_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3b82f6',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus .apeiron-kit-comment-pill-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_3plus_icon_color',
			[
				'label'     => __( 'Warna Icon', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3b82f6',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus .apeiron-kit-comment-pill-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bridge_status_3plus_border_color',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'bridge_status_3plus_border_width',
			[
				'label'      => __( 'Lebar Border', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pill.status-index-3-plus' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_form',
			[
				'label' => __( 'Form', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'fields_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form input, {{WRAPPER}} .apeiron-kit-comment-form textarea',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'fields_background',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form input, {{WRAPPER}} .apeiron-kit-comment-form textarea',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'fields_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form input, {{WRAPPER}} .apeiron-kit-comment-form textarea',
			]
		);

		$this->add_responsive_control(
			'fields_radius',
			[
				'label'      => __( 'Radius Kolom', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form input, {{WRAPPER}} .apeiron-kit-comment-form textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'fields_focus_heading',
			[
				'label' => __( 'Focus State', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'fields_focus_border_type',
			[
				'label'     => __( 'Border Type', 'apeiron-kit' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'none'   => __( 'None', 'apeiron-kit' ),
					'solid'  => __( 'Solid', 'apeiron-kit' ),
					'double' => __( 'Double', 'apeiron-kit' ),
					'dotted' => __( 'Dotted', 'apeiron-kit' ),
					'dashed' => __( 'Dashed', 'apeiron-kit' ),
					'groove' => __( 'Groove', 'apeiron-kit' ),
				],
				'default'   => 'solid',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'fields_focus_border_width',
			[
				'label'      => __( 'Border Width', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'default'    => [
					'top'    => '1',
					'right'  => '1',
					'bottom' => '1',
					'left'   => '1',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'fields_focus_border_type!' => 'none',
				],
			]
		);

		$this->add_control(
			'fields_focus_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3b82f6',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'fields_focus_border_type!' => 'none',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'fields_focus_shadow',
				'label'    => __( 'Shadow Focus', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus',
			]
		);

		$this->add_control(
			'fields_focus_background',
			[
				'label'     => __( 'Background Focus', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'fields_focus_color',
			[
				'label'     => __( 'Warna Teks Focus', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form input:focus, {{WRAPPER}} .apeiron-kit-comment-form textarea:focus, {{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'fields_padding',
			[
				'label'      => __( 'Padding Kolom Nama & Pesan', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form input[type="text"], {{WRAPPER}} .apeiron-kit-comment-form input[type="email"], {{WRAPPER}} .apeiron-kit-comment-form textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'select_wrapper_padding',
			[
				'label'      => __( 'Padding Wrapper Konfirmasi Kehadiran', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'select_padding',
			[
				'label'      => __( 'Padding Dropdown', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-select select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'select_radius',
			[
				'label'      => __( 'Border Radius Dropdown', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-select select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => __( 'Padding Tombol', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'button_background',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]',
				'types'    => [ 'classic', 'gradient' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '#083c57',
					],
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'     => __( 'Warna Teks Tombol', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_shadow',
				'label'    => __( 'Shadow Tombol', 'apeiron-kit' ),
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]',
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'button_radius',
			[
				'label'      => __( 'Radius Tombol', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form button[type="submit"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// Label Form — Global Style
		// =============================================
		$this->start_controls_section(
			'section_style_label_form',
			[
				'label' => __( 'Label Form', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'show_form_labels',
			[
				'label'        => __( 'Tampilkan Label', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'selectors'    => [
					'{{WRAPPER}} .apeiron-kit-form-label' => 'display: {{VALUE}};',
				],
				'selectors_dictionary' => [
					'yes' => 'block',
					''    => 'none',
				],
			]
		);

		$this->add_control(
			'label_text_color',
			[
				'label'     => __( 'Warna Teks Label', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-form-label' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_form_labels' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'label_typography',
				'selector'  => '{{WRAPPER}} .apeiron-kit-form-label',
				'condition' => [
					'show_form_labels' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'label_margin_bottom',
			[
				'label'      => __( 'Margin Bottom Label', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-form-label' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'show_form_labels' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// Dropdown Konfirmasi Kehadiran — Full Style
		// =============================================
		$this->start_controls_section(
			'section_style_dropdown',
			[
				'label' => __( 'Dropdown Konfirmasi', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'dropdown_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-form select',
			]
		);

		$this->start_controls_tabs( 'dropdown_style_tabs' );

		// --- Normal Tab ---
		$this->start_controls_tab(
			'dropdown_tab_normal',
			[
				'label' => __( 'Normal', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'dropdown_bg_color',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_text_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_border_color',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'dropdown_border_width',
			[
				'label'      => __( 'Lebar Border', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form select' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; border-style: solid;',
				],
			]
		);

		$this->add_responsive_control(
			'dropdown_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-form select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// --- Hover Tab ---
		$this->start_controls_tab(
			'dropdown_tab_hover',
			[
				'label' => __( 'Hover', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'dropdown_bg_color_hover',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_text_color_hover',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_border_color_hover',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		// --- Focus Tab ---
		$this->start_controls_tab(
			'dropdown_tab_focus',
			[
				'label' => __( 'Focus', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'dropdown_bg_color_focus',
			[
				'label'     => __( 'Background', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_text_color_focus',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'dropdown_border_color_focus',
			[
				'label'     => __( 'Warna Border', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-form select:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_sticker',
			[
				'label'     => __( 'Sticker Picker', 'apeiron-kit' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_stickers' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_option_size',
			[
				'label' => __( 'Ukuran Sticker (Picker)', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 40,
						'max' => 120,
					],
				],
				'default' => [
					'size' => 72,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-comment-dock' => '--apeiron-sticker-size: {{SIZE}}{{UNIT}}; --sticker-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-kit-sticker-option' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_comment_size',
			[
				'label' => __( 'Ukuran Sticker (Komentar)', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 30,
						'max' => 120,
					],
				],
				'default' => [
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-comment-dock' => '--apeiron-sticker-avatar-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_option_gap',
			[
				'label' => __( 'Jarak antar Sticker', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'default' => [
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-sticker-track' => 'gap: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .apeiron-comment-dock' => '--sticker-padding: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'sticker_selection_color',
			[
				'label'     => __( 'Warna Outline Pilihan', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083c57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-sticker-option.is-selected' => 'outline-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_option_padding',
			[
				'label'      => __( 'Padding Stiker', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-sticker-option' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sticker_option_bg',
			[
				'label'     => __( 'Background Stiker', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-sticker-option' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_option_radius',
			[
				'label'      => __( 'Radius Stiker', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-sticker-option' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sticker_field_gap',
			[
				'label' => __( 'Jarak Stiker dari Tombol', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-sticker-field' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_success',
			[
				'label' => __( 'Pesan Sukses', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'notice_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-notice',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'notice_background',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-notice',
			]
		);

		$this->add_control(
			'notice_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-notice' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'notice_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-notice',
			]
		);

		$this->add_responsive_control(
			'notice_radius',
			[
				'label'      => __( 'Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-notice' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'notice_alignment',
			[
				'label'     => __( 'Perataan Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => __( 'Kiri', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Tengah', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => __( 'Kanan', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => 'left',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-notice' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Pagination Style
		$this->start_controls_section(
			'section_style_pagination',
			[
				'label' => __( 'Pagination', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'use_pagination' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pagination_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-pagination button',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'pagination_background',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-pagination button',
				'types'    => [ 'classic', 'gradient' ],
			]
		);

		$this->add_control(
			'pagination_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pagination_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-comment-pagination button',
			]
		);

		$this->add_responsive_control(
			'pagination_radius',
			[
				'label'      => __( 'Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'pagination_info_color',
			[
				'label'     => __( 'Warna Info Halaman', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-page-info' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pagination_hover_color',
			[
				'label'     => __( 'Warna Hover', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button:hover:not(:disabled)' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'pagination_hover_background',
			[
				'label'     => __( 'Background Hover', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button:hover:not(:disabled)' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pagination_disabled_bg',
			[
				'label'     => __( 'Background Disabled', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination button:disabled' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'pagination_alignment',
			[
				'label'     => __( 'Perataan', 'apeiron-kit' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start' => [
						'title' => __( 'Kiri', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Tengah', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Kanan', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-right',
					],
					'space-between' => [
						'title' => __( 'Rata Kiri-Kanan', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-justify',
					],
				],
				'default'   => 'center',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination' => 'justify-content: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'pagination_gap',
			[
				'label' => __( 'Jarak Antar Elemen', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'default' => [
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-comment-pagination' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}
		$settings  = $this->get_settings_for_display();
		$post_id   = get_the_ID() ?: 0;
		$elementId = $this->get_id();
		$all_comments = $this->query_comments( $post_id, $elementId );
		$use_pagination = 'yes' === ( $settings['use_pagination'] ?? 'no' );
		$items_per_page = max( 1, (int) ( $settings['items_per_page'] ?? 5 ) );
		$show_avatar = 'yes' === ( $settings['show_avatar'] ?? 'yes' );
		$show_attendence = 'yes' === ( $settings['attendence'] ?? 'yes' );
		$show_date = 'yes' === ( $settings['show_date'] ?? 'yes' );
		$default_avatar_url = ! empty( $settings['default_avatar']['url'] )
			? $settings['default_avatar']['url']
			: APEIRON_KIT_URL . 'assets/img/man-avatar.webp';
		$show_stickers = 'yes' === ( $settings['show_stickers'] ?? 'no' );
		$sticker_label = $settings['sticker_label'] ?? __( 'Sticker', 'apeiron-kit' );
		$sticker_folder = 'assets/stickers/gift'; // Default folder, tidak perlu diubah oleh user
		$allow_image = 'yes' === ( $settings['sticker_allow_image'] ?? 'yes' );
		$allow_video = 'yes' === ( $settings['sticker_allow_video'] ?? 'yes' );
		$stickers = $show_stickers ? $this->load_stickers( $sticker_folder, $allow_image, $allow_video ) : [];
		$show_stickers = $show_stickers && ! empty( $stickers );

		if ( $use_pagination ) {
			$total = count( $all_comments );
			$comments = $all_comments;
		} else {
			$limit = max( 1, (int) ( $settings['comments_limit'] ?? 10 ) );
			$total = count( $all_comments );
			$comments = $all_comments; // Show all comments in scrollable container
		}

		$display_mode       = $settings['attendance_display'] ?? 'icon';
		$attendance_options = $this->prepare_attendance_options( $settings['attendance_options'] ?? [] );
		$list_classes       = [ 'apeiron-kit-comment-list' ];

		// Add scrollable class if not using pagination and has more comments than limit
		if ( ! $use_pagination && count( $comments ) > max( 1, (int) ( $settings['comments_limit'] ?? 10 ) ) ) {
			$list_classes[] = 'apeiron-kit-comment-list-scrollable';
		} elseif ( 'scroll' === ( $settings['list_display_mode'] ?? 'auto' ) ) {
			$list_classes[] = 'is-scrollable';
		}

		$wrapper_classes = [ 'apeiron-comment-dock' ];
		if ( 'icon' === $display_mode ) {
			$wrapper_classes[] = 'is-icon-only';
		} else {
			$wrapper_classes[] = 'is-icon-text';
		}

		?>
		<section class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>"
			data-attendance-display="<?php echo esc_attr( $display_mode ); ?>"
			data-attendance-map="<?php echo esc_attr( wp_json_encode( $attendance_options ) ); ?>"
			data-comments-limit="<?php echo esc_attr( $use_pagination ? 0 : max( 1, (int) ( $settings['comments_limit'] ?? 10 ) ) ); ?>"
			data-date-format="<?php echo esc_attr( $settings['date_format_type'] ?? 'relative' ); ?>"
			data-default-avatar="<?php echo esc_url( $default_avatar_url ); ?>">
			<?php if ( 'yes' === ( $settings['show_heading'] ?? 'yes' ) && ! empty( $settings['heading'] ) ) : ?>
				<h3 class="apeiron-kit-comment-heading"><?php echo esc_html( $settings['heading'] ); ?></h3>
			<?php endif; ?>

			<form class="apeiron-kit-comment-form"
				data-apeiron-comment-form
				data-success-message="<?php echo esc_attr( $settings['success_message'] ); ?>">
				<input type="hidden" name="post_id" value="<?php echo esc_attr( $post_id ); ?>" />
				<input type="hidden" name="element_id" value="<?php echo esc_attr( $elementId ); ?>" />
				<input type="hidden" name="attendance_label" value="" />
				<div class="apeiron-kit-form-field-wrap">
					<label class="apeiron-kit-form-label" for="apeiron-name-<?php echo esc_attr( $elementId ); ?>"><?php echo esc_html( $settings['name_label'] ?? __( 'Nama Lengkap', 'apeiron-kit' ) ); ?></label>
					<input type="text" id="apeiron-name-<?php echo esc_attr( $elementId ); ?>" name="name" placeholder="<?php echo esc_attr( $settings['name_placeholder'] ); ?>" required />
				</div>
				<div class="apeiron-kit-form-field-wrap">
					<label class="apeiron-kit-form-label" for="apeiron-message-<?php echo esc_attr( $elementId ); ?>"><?php echo esc_html( $settings['message_label'] ?? __( 'Ucapan', 'apeiron-kit' ) ); ?></label>
					<textarea id="apeiron-message-<?php echo esc_attr( $elementId ); ?>" name="message" rows="3" placeholder="<?php echo esc_attr( $settings['message_placeholder'] ); ?>" required></textarea>
				</div>

				<?php if ( ! empty( $attendance_options ) && $show_attendence ) : ?>
					<label class="apeiron-kit-comment-select">
						<span class="apeiron-kit-form-label"><?php echo esc_html( $settings['attendance_label'] ); ?></span>
						<select name="attendance" required>
							<option value=""><?php esc_html_e( 'Pilih salah satu', 'apeiron-kit' ); ?></option>
							<?php foreach ( $attendance_options as $slug => $opt ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>">
									<?php echo esc_html( $opt['label'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</label>
				<?php elseif ( ! empty( $attendance_options ) && ! $show_attendence ) : ?>
					<input type="hidden" name="attendance" value="" />
				<?php endif; ?>

				<?php if ( $show_stickers ) : ?>
					<div class="apeiron-kit-sticker-field">
						<span class="apeiron-kit-sticker-label apeiron-kit-form-label"><?php echo esc_html( $sticker_label ); ?></span>
						<input type="hidden" name="sticker_src" value="">
						<input type="hidden" name="sticker_type" value="">
						<div class="apeiron-kit-sticker-picker" data-sticker-picker="true">
							<div class="apeiron-kit-sticker-track">
								<?php foreach ( $stickers as $sticker ) : ?>
									<button type="button"
										class="apeiron-kit-sticker-option"
										data-src="<?php echo esc_attr( $sticker['relative'] ); ?>"
										data-type="<?php echo esc_attr( $sticker['type'] ); ?>"
										aria-label="<?php echo esc_attr( $sticker['name'] ); ?>">
										<?php if ( 'video' === $sticker['type'] ) : ?>
											<video src="<?php echo esc_url( $sticker['url'] ); ?>" muted loop playsinline></video>
										<?php else : ?>
											<img src="<?php echo esc_url( $sticker['url'] ); ?>" alt="<?php echo esc_attr( $sticker['name'] ); ?>">
										<?php endif; ?>

									</button>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				<?php endif; ?>

				<button type="submit"><?php echo esc_html( $settings['button_text'] ); ?></button>
			</form>

			<div class="<?php echo esc_attr( implode( ' ', $list_classes ) ); ?>">
				<?php foreach ( $comments as $comment ) : ?>
					<?php
					$attendance_value = get_comment_meta( $comment->comment_ID, 'apeiron_attendance_value', true );
					$attendance_label = get_comment_meta( $comment->comment_ID, 'apeiron_attendance_label', true );
					$badge_index      = isset( $attendance_options[ $attendance_value ] ) ? $attendance_options[ $attendance_value ]['index'] : -1;
					$badge_html       = $this->render_attendance_badge(
						$display_mode,
						$attendance_value,
						$attendance_options,
						$attendance_label,
						$badge_index
					);
					?>
					<li class="apeiron-kit-comment-item">
						<div class="apeiron-kit-comment-wrapper">
							<?php if ( $show_avatar ) : ?>
								<?php
								$comment_sticker = $this->get_comment_sticker( (int) $comment->comment_ID );
								$avatar_classes  = [ 'apeiron-kit-comment-avatar' ];
								if ( ! empty( $comment_sticker ) ) {
									$avatar_classes[] = 'has-sticker';
								}
								?>
								<div class="<?php echo esc_attr( implode( ' ', $avatar_classes ) ); ?>">
									<?php echo $this->render_comment_avatar( $comment, $comment_sticker, $default_avatar_url ); ?>
								</div>
							<?php endif; ?>
							<div class="apeiron-kit-comment-content">
								<div class="apeiron-kit-comment-info">
									<span class="apeiron-kit-comment-author"><?php echo esc_html( $comment->comment_author ); ?></span>
									<?php if ( $show_attendence ) : ?>
										<?php echo $badge_html; ?>
									<?php endif; ?>
								</div>
								<div class="apeiron-kit-comment-text">
									<?php echo wp_kses_post( wpautop( $comment->comment_content ) ); ?>
								</div>
								<?php if ( $show_date ) : ?>
									<span class="apeiron-kit-comment-time"><?php echo esc_html( $this->format_comment_date( $comment, $settings['date_format_type'] ?? 'relative' ) ); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			</div>

			<?php if ( $use_pagination && $total > $items_per_page ) : ?>
				<div class="apeiron-kit-comment-pagination" data-total="<?php echo esc_attr( $total ); ?>" data-per-page="<?php echo esc_attr( $items_per_page ); ?>" data-current="1">
					<button type="button" class="apeiron-kit-comment-prev" aria-label="<?php esc_attr_e( 'Previous comments page', 'apeiron-kit' ); ?>" disabled>
						<?php echo esc_html( $settings['prev_text'] ?? __( '← Previous', 'apeiron-kit' ) ); ?>
					</button>
					<span class="apeiron-kit-comment-page-info">
						<span class="apeiron-kit-comment-page-current">1</span> / <span class="apeiron-kit-comment-page-total"><?php echo esc_html( ceil( $total / $items_per_page ) ); ?></span>
					</span>
					<button type="button" class="apeiron-kit-comment-next" aria-label="<?php esc_attr_e( 'Next comments page', 'apeiron-kit' ); ?>" <?php echo $total <= $items_per_page ? 'disabled' : ''; ?>>
						<?php echo esc_html( $settings['next_text'] ?? __( 'Next →', 'apeiron-kit' ) ); ?>
					</button>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	private function query_comments( int $post_id, string $element_id ): array {
		if ( ! $post_id || empty( $element_id ) ) {
			return [];
		}

		return get_comments(
			[
				'post_id'    => $post_id,
				'status'     => 'approve',
				'number'     => 200,
				'meta_query' => [
					[
						'key'   => 'apeiron_element_id',
						'value' => $element_id,
					],
				],
			]
		);
	}

	private function prepare_attendance_options( array $options ): array {
		$prepared   = [];
		$index      = 0;
		$used_slugs = [];

		foreach ( $options as $option ) {
			$slug = ! empty( $option['option_slug'] ) ? sanitize_key( $option['option_slug'] ) : sanitize_title( $option['option_label'] );
			if ( empty( $slug ) ) {
				continue;
			}

			// Dedup: append counter if slug already used
			$original_slug = $slug;
			$counter       = 2;
			while ( isset( $used_slugs[ $slug ] ) ) {
				$slug = $original_slug . '-' . $counter;
				$counter++;
			}
			$used_slugs[ $slug ] = true;

			$icon = '';
			if ( ! empty( $option['option_icon']['value'] ) ) {
				ob_start();
				Icons_Manager::render_icon(
					$option['option_icon'],
					[
						'aria-hidden' => 'true',
					]
				);
				$icon = ob_get_clean();
			}

			$prepared[ $slug ] = [
				'label'           => $option['option_label'],
				'icon'            => $icon,
				'index'           => $index,
			];
			$index++;
		}

		return $prepared;
	}

	private function render_attendance_badge( string $display_mode, string $value, array $options, string $fallback, int $index = -1 ): string {
		if ( empty( $value ) ) {
			return '';
		}

		$option = $options[ $value ] ?? null;
		$label  = $option['label'] ?? $fallback;
		$icon   = $option['icon'] ?? '';
		$has_label = 'icon-label' === $display_mode && ! empty( $label );

		if ( empty( $icon ) && ! $has_label ) {
			return '';
		}

		$wrapper_classes = [ 'apeiron-kit-comment-pill' ];
		$wrapper_classes[] = 'icon' === $display_mode ? 'is-icon-only' : 'is-icon-text';

		// Add index-based class for Bridge Kehadiran color system
		if ( $index >= 0 ) {
			if ( $index <= 2 ) {
				$wrapper_classes[] = 'status-index-' . $index;
			} else {
				$wrapper_classes[] = 'status-index-3-plus';
			}
		}

		$icon_markup = $icon ?: '';
		
		if ( empty( $icon_markup ) && ! empty( $label ) ) {
			$icon_markup = '<span class="apeiron-kit-comment-pill-dot"></span>';
		}

		$icon_html = sprintf(
			'<span class="apeiron-kit-comment-pill-icon">%s</span>',
			$icon_markup
		);

		$text_html = $has_label
			? sprintf(
				'<span class="apeiron-kit-comment-pill-text">%s</span>',
				esc_html( $label )
			)
			: '';

		return sprintf(
			'<span class="%s">%s%s</span>',
			esc_attr( implode( ' ', $wrapper_classes ) ),
			$icon_html,
			$text_html
		);
	}

	/**
	 * Memuat stiker dari folder yang ditentukan.
	 * 
	 * Fungsi ini secara otomatis memindai folder stiker dan memuat semua file gambar/video
	 * yang ada di dalamnya. Sistem ini bersifat dinamis, sehingga:
	 * - Menambah file baru di folder akan otomatis menambahkan stiker baru
	 * - Menghapus file dari folder akan otomatis menghapus stiker tersebut
	 * - Tidak perlu konfigurasi tambahan atau restart plugin
	 * 
	 * Format file yang didukung:
	 * - Gambar: png, jpg, jpeg, gif, svg, webp (jika allow_image = true)
	 * - Video: webm, mp4 (jika allow_video = true)
	 * 
	 * @param string $folder Path relatif folder stiker dari direktori plugin
	 * @param bool   $allow_image Apakah mengizinkan file gambar sebagai stiker
	 * @param bool   $allow_video Apakah mengizinkan file video sebagai stiker
	 * @return array Array berisi informasi stiker (url, relative path, type, name)
	 */
	private function load_stickers( string $folder, bool $allow_image = true, bool $allow_video = true ): array {
		$folder = trim( (string) $folder );
		if ( empty( $folder ) ) {
			return [];
		}

		// Static cache to avoid repeated filesystem scan on same request
		static $cache = [];
		$cache_key = $folder . '|' . ( $allow_image ? '1' : '0' ) . '|' . ( $allow_video ? '1' : '0' );
		if ( isset( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		$relative = ltrim( wp_normalize_path( $folder ), '/\\' );
		if ( empty( $relative ) ) {
			return $cache[ $cache_key ] = [];
		}

		$base_path = trailingslashit( APEIRON_KIT_PATH ) . $relative;
		$base_url  = trailingslashit( APEIRON_KIT_URL ) . $relative;

		if ( ! is_dir( $base_path ) ) {
			return $cache[ $cache_key ] = [];
		}

		// Collect allowed extensions based on settings
		$allowed_extensions = [];
		if ( $allow_image ) {
			$allowed_extensions = array_merge( $allowed_extensions, [ 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp' ] );
		}
		if ( $allow_video ) {
			$allowed_extensions = array_merge( $allowed_extensions, [ 'webm', 'mp4' ] );
		}

		// If neither is allowed, return empty array
		if ( empty( $allowed_extensions ) ) {
			return [];
		}

		// Build glob pattern with GLOB_BRACE
		$pattern_parts = [];
		foreach ( $allowed_extensions as $ext ) {
			$pattern_parts[] = '*.' . $ext;
		}
		$pattern = trailingslashit( $base_path ) . '{' . implode( ',', $pattern_parts ) . '}';
		$files = glob( $pattern, GLOB_BRACE );

		// Fallback: if GLOB_BRACE is not supported or returns false, scan all files and filter
		if ( false === $files || empty( $files ) ) {
			$all_files = glob( trailingslashit( $base_path ) . '*' );
			$files = [];
			if ( is_array( $all_files ) ) {
				foreach ( $all_files as $file ) {
					if ( ! is_file( $file ) ) {
						continue;
					}
					$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
					if ( in_array( $ext, $allowed_extensions, true ) ) {
						$files[] = $file;
					}
				}
			}
		}

		if ( empty( $files ) ) {
			return [];
		}

		$items = [];
		foreach ( $files as $file ) {
			$ext  = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
			$type = in_array( $ext, [ 'webm', 'mp4' ], true ) ? 'video' : 'image';
			
			// Skip files based on type and settings
			if ( 'video' === $type && ! $allow_video ) {
				continue;
			}
			if ( 'image' === $type && ! $allow_image ) {
				continue;
			}
			
			$items[] = [
				'id'       => md5( $file ),
				'url'      => trailingslashit( $base_url ) . basename( $file ),
				'relative' => trailingslashit( $relative ) . basename( $file ),
				'type'     => $type,
				'name'     => ucwords( str_replace( [ '-', '_' ], ' ', pathinfo( $file, PATHINFO_FILENAME ) ) ),
			];
		}

		$cache[ $cache_key ] = $items;
		return $items;
	}

	private function get_comment_sticker( int $comment_id ): array {
		$relative = (string) get_comment_meta( $comment_id, 'apeiron_sticker_src', true );
		if ( empty( $relative ) ) {
			return [];
		}

		$relative = ltrim( wp_normalize_path( $relative ), '/\\' );
		if ( empty( $relative ) ) {
			return [];
		}

		$type = (string) get_comment_meta( $comment_id, 'apeiron_sticker_type', true );
		if ( ! in_array( $type, [ 'image', 'video' ], true ) ) {
			$ext  = strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) );
			$type = in_array( $ext, [ 'webm', 'mp4' ], true ) ? 'video' : 'image';
		}

		return [
			'url'  => trailingslashit( APEIRON_KIT_URL ) . $relative,
			'type' => $type,
		];
	}

	/**
	 * Format tanggal komentar berdasarkan tipe yang dipilih
	 * 
	 * @param object $comment Comment object
	 * @param string $format_type Tipe format: 'relative', 'custom', atau 'default'
	 * @return string Formatted date string
	 */
	private function format_comment_date( $comment, string $format_type = 'relative' ): string {
		$comment_date = get_comment_date( 'U', $comment );
		$current_time = time();
		$diff = $current_time - $comment_date;

		switch ( $format_type ) {
			case 'relative':
				return $this->get_relative_time( $diff );
			
			case 'custom':
				// Format: tanggal dulu, bulan baru tahun (contoh: 7 Desember 2025)
				$day = get_comment_date( 'j', $comment );
				$month = get_comment_date( 'F', $comment );
				$year = get_comment_date( 'Y', $comment );
				
				// Translate month name to Indonesian
				$months = [
					'January'   => 'Januari',
					'February'  => 'Februari',
					'March'     => 'Maret',
					'April'     => 'April',
					'May'       => 'Mei',
					'June'      => 'Juni',
					'July'      => 'Juli',
					'August'    => 'Agustus',
					'September' => 'September',
					'October'   => 'Oktober',
					'November'  => 'November',
					'December'  => 'Desember',
				];
				
				$month_id = isset( $months[ $month ] ) ? $months[ $month ] : $month;
				
				return sprintf( '%d %s %s', $day, $month_id, $year );
			
			case 'default':
			default:
				return get_comment_date( get_option( 'date_format' ), $comment );
		}
	}

	/**
	 * Get relative time string (1 menit yang lalu, 2 jam yang lalu, dll)
	 * 
	 * @param int $diff Time difference in seconds
	 * @return string Relative time string
	 */
	private function get_relative_time( int $diff ): string {
		if ( $diff < 60 ) {
			return __( 'Baru saja', 'apeiron-kit' );
		}

		$minutes = floor( $diff / 60 );
		if ( $minutes < 60 ) {
			return sprintf(
				_n( '%d menit yang lalu', '%d menit yang lalu', $minutes, 'apeiron-kit' ),
				$minutes
			);
		}

		$hours = floor( $diff / 3600 );
		if ( $hours < 24 ) {
			return sprintf(
				_n( '%d jam yang lalu', '%d jam yang lalu', $hours, 'apeiron-kit' ),
				$hours
			);
		}

		$days = floor( $diff / 86400 );
		if ( $days < 7 ) {
			return sprintf(
				_n( '%d hari yang lalu', '%d hari yang lalu', $days, 'apeiron-kit' ),
				$days
			);
		}

		$weeks = floor( $days / 7 );
		if ( $weeks < 4 ) {
			return sprintf(
				_n( '%d minggu yang lalu', '%d minggu yang lalu', $weeks, 'apeiron-kit' ),
				$weeks
			);
		}

		$months = floor( $days / 30 );
		if ( $months < 12 ) {
			return sprintf(
				_n( '%d bulan yang lalu', '%d bulan yang lalu', $months, 'apeiron-kit' ),
				$months
			);
		}

		$years = floor( $days / 365 );
		return sprintf(
			_n( '%d tahun yang lalu', '%d tahun yang lalu', $years, 'apeiron-kit' ),
			$years
		);
	}

	private function render_comment_avatar( $comment, array $sticker, string $default_avatar_url ): string {
		if ( ! empty( $sticker['url'] ) ) {
			$media = '';
			if ( 'video' === ( $sticker['type'] ?? 'image' ) ) {
				$media = sprintf(
					'<video src="%1$s" class="apeiron-kit-sticker-avatar" autoplay muted loop playsinline></video>',
					esc_url( $sticker['url'] )
				);
			} else {
				$media = sprintf(
					'<img src="%1$s" class="apeiron-kit-sticker-avatar" alt="%2$s" />',
					esc_url( $sticker['url'] ),
					esc_attr( $comment->comment_author )
				);
			}

			return sprintf(
				'<span class="apeiron-kit-comment-sticker">%s</span>',
				$media
			);
		}

		$avatar_url = $default_avatar_url;
		if ( empty( $avatar_url ) ) {
			$avatar_url = APEIRON_KIT_URL . 'assets/img/man-avatar.webp';
		}

		return sprintf(
			'<img src="%1$s" alt="%2$s" />',
			esc_url( $avatar_url ),
			esc_attr( $comment->comment_author )
		);
	}
}

