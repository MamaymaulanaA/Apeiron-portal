<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Utils;

class SoundscapePlayer extends BaseWidget {

	public function get_name() {
		return 'apeiron-soundscape';
	}

	public function get_title() {
		return __( 'Audio Player', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-audio';
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-soundscape';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-soundscape-js' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}

		$this->start_controls_section(
			'section_audio',
			[
				'label' => __( 'Audio MP3', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'src_type',
			[
				'label'   => esc_html__( 'Audio Source', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'upload',
				'options' => [
					'upload'  => esc_html__( 'Upload Audio', 'apeiron-kit' ),
					'link'    => esc_html__( 'Audio Link', 'apeiron-kit' ),
					'youtube' => esc_html__( 'Youtube Video', 'apeiron-kit' ),
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'audio_upload',
			[
				'label'      => esc_html__( 'Upload Audio', 'apeiron-kit' ),
				'type'       => Controls_Manager::MEDIA,
				'media_type' => 'audio',
				'condition' => [
					'src_type' => 'upload',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'audio_link',
			[
				'label'       => esc_html__( 'Audio Link', 'apeiron-kit' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://example.com/music-name.mp3', 'apeiron-kit' ),
				'show_external' => false,
				'default'    => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition' => [
					'src_type' => 'link',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'youtube_link',
			[
				'label'       => esc_html__( 'Youtube Video', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'https://youtu.be/Trjrj_fQnIM', 'apeiron-kit' ),
				'default'    => 'https://youtu.be/Trjrj_fQnIM',
				'label_block' => true,
				'condition'  => [
					'src_type' => 'youtube',
				],
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'start',
			[
				'label'       => esc_html__( 'Start Time', 'apeiron-kit' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify a start time (in seconds)', 'apeiron-kit' ),
				'frontend_available' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'end',
			[
				'label'       => esc_html__( 'End Time', 'apeiron-kit' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => esc_html__( 'Specify an end time (in seconds)', 'apeiron-kit' ),
				'frontend_available' => true,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'audio_options',
			[
				'label'     => esc_html__( 'Options', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'        => __( 'Autoplay', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'apeiron-kit' ),
				'label_off'    => __( 'No', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => [
					'src_type' => [ 'link', 'upload' ],
				],
			]
		);

		$this->add_control(
			'loop',
			[
				'label'            => esc_html__( 'Loop', 'apeiron-kit' ),
				'type'             => Controls_Manager::SWITCHER,
				'frontend_available' => true,
				'condition'        => [
					'src_type' => [ 'upload', 'link' ],
				],
			]
		);

		$this->add_control(
			'pause_icon',
			[
				'label'   => __( 'Icon Play', 'apeiron-kit' ),
				'type'    => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value'   => 'fas fa-play',
					'library' => 'fa-solid',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'play_icon',
			[
				'label'   => __( 'Icon Stop', 'apeiron-kit' ),
				'type'    => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value'   => 'fas fa-pause',
					'library' => 'fa-solid',
				],
			]
		);

		$this->add_control(
			'view',
			[
				'label'   => __( 'View', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'default' => __( 'Default', 'apeiron-kit' ),
					'stacked' => __( 'Stacked', 'apeiron-kit' ),
					'framed'  => __( 'Framed', 'apeiron-kit' ),
				],
				'default'      => 'default',
				'prefix_class' => 'elementor-view-',
			]
		);

		$this->add_control(
			'shape',
			[
				'label'   => __( 'Shape', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'circle' => __( 'Circle', 'apeiron-kit' ),
					'square' => __( 'Square', 'apeiron-kit' ),
				],
				'default'      => 'circle',
				'condition'    => [
					'view!' => 'default',
				],
				'prefix_class' => 'elementor-shape-',
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => __( 'Alignment', 'apeiron-kit' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'flex-start' => [
						'title' => __( 'Left', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end' => [
						'title' => __( 'Right', 'apeiron-kit' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => 'justify-content: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'position_type',
			[
				'label'   => __( 'Position', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'fixed',
				'options' => [
					'relative' => __( 'In Flow (Normal)', 'apeiron-kit' ),
					'fixed'    => __( 'Fixed (Floating)', 'apeiron-kit' ),
				],
				'selectors' => [
					'{{WRAPPER}}' => 'position: {{VALUE}}; width: auto;',
				],
			]
		);

		$this->add_control(
			'position_v_anchor',
			[
				'label'   => __( 'Vertical Anchor', 'apeiron-kit' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'top' => [
						'title' => __( 'Top', 'apeiron-kit' ),
						'icon'  => 'eicon-v-align-top',
					],
					'bottom' => [
						'title' => __( 'Bottom', 'apeiron-kit' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'      => 'bottom',
				'condition'    => [
					'position_type' => 'fixed',
				],
				'selectors_dictionary' => [
					'top'    => 'top: var(--apeiron-pos-y, 40px); bottom: auto;',
					'bottom' => 'bottom: var(--apeiron-pos-y, 40px); top: auto;',
				],
				'selectors' => [
					'{{WRAPPER}}' => '{{VALUE}}',
				],
			]
		);

		$this->add_control(
			'position_h_anchor',
			[
				'label'   => __( 'Horizontal Anchor', 'apeiron-kit' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'apeiron-kit' ),
						'icon'  => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'apeiron-kit' ),
						'icon'  => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'apeiron-kit' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default'      => 'center',
				'condition'    => [
					'position_type' => 'fixed',
				],
				'selectors_dictionary' => [
					'left'   => 'left: var(--apeiron-pos-x, 40px); right: auto; transform: none;',
					'center' => 'left: 50%; right: auto; transform: translateX(-50%);',
					'right'  => 'right: var(--apeiron-pos-x, 40px); left: auto; transform: none;',
				],
				'selectors' => [
					'{{WRAPPER}}' => '{{VALUE}}',
				],
			]
		);

		$this->add_responsive_control(
			'position_offset_x',
			[
				'label'      => __( 'Horizontal Offset', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vw' ],
				'range'      => [
					'px' => [ 'min' => 0, 'max' => 200 ],
					'%'  => [ 'min' => 0, 'max' => 100 ],
					'vw' => [ 'min' => 0, 'max' => 50 ],
				],
				'default'    => [ 'size' => 40, 'unit' => 'px' ],
				'condition'  => [
					'position_type'     => 'fixed',
					'position_h_anchor!' => 'center',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--apeiron-pos-x: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'position_offset_y',
			[
				'label'      => __( 'Vertical Offset', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vh' ],
				'range'      => [
					'px' => [ 'min' => 0, 'max' => 200 ],
					'%'  => [ 'min' => 0, 'max' => 100 ],
					'vh' => [ 'min' => 0, 'max' => 50 ],
				],
				'default'    => [ 'size' => 40, 'unit' => 'px' ],
				'condition'  => [
					'position_type' => 'fixed',
				],
				'selectors' => [
					'{{WRAPPER}}' => '--apeiron-pos-y: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'position_zindex',
			[
				'label'   => __( 'Z-Index', 'apeiron-kit' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 9999,
				'selectors' => [
					'{{WRAPPER}}' => 'z-index: {{VALUE}};',
				],
				'condition' => [
					'position_type' => 'fixed',
				],
			]
		);

		$this->add_control(
			'player_skin',
			[
				'label'   => __( 'Player Skin', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'minimal',
				'options' => [
					'minimal' => __( 'Minimal', 'apeiron-kit' ),
					'pill'    => __( 'Soft Pill', 'apeiron-kit' ),
					'dual'    => __( 'Dual Layer', 'apeiron-kit' ),
				],
			]
		);

		$this->add_control(
			'show_label',
			[
				'label'        => __( 'Show Text Label', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'apeiron-kit' ),
				'label_off'    => __( 'Hide', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'play_label_text',
			[
				'label'       => __( 'Play Label', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Putar Musik', 'apeiron-kit' ),
				'label_block' => true,
				'condition'   => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'pause_label_text',
			[
				'label'       => __( 'Pause Label', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Jeda Musik', 'apeiron-kit' ),
				'label_block' => true,
				'condition'   => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'label_position',
			[
				'label'     => __( 'Label Position', 'apeiron-kit' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'after',
				'options'   => [
					'before' => __( 'Before Icon', 'apeiron-kit' ),
					'after'  => __( 'After Icon', 'apeiron-kit' ),
					'stacked'=> __( 'Stacked', 'apeiron-kit' ),
				],
				'condition' => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_control(
			'pulse_style',
			[
				'label'   => __( 'Animated Pulse', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => [
					''          => __( 'None', 'apeiron-kit' ),
					'ripple'    => __( 'Ripple', 'apeiron-kit' ),
					'glow'      => __( 'Soft Glow', 'apeiron-kit' ),
					'heartbeat' => __( 'Heartbeat', 'apeiron-kit' ),
				],
			]
		);

		$this->add_control(
			'pulse_color',
			[
				'label'     => __( 'Pulse Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083c57',
				'condition' => [
					'pulse_style!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => '--apeiron-pulse-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'pulse_speed',
			[
				'label'   => __( 'Pulse Duration', 'apeiron-kit' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 1.8,
				],
				'range'   => [
					'px' => [
						'min'  => 0.5,
						'max'  => 5,
						'step' => 0.1,
					],
				],
				'condition' => [
					'pulse_style!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => '--apeiron-pulse-duration: {{SIZE}}s;',
				],
			]
		);

		$this->add_control(
			'pulse_spread',
			[
				'label'   => __( 'Pulse Spread', 'apeiron-kit' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 2.2,
				],
				'range'   => [
					'px' => [
						'min'  => 1.2,
						'max'  => 4,
						'step' => 0.1,
					],
				],
				'condition' => [
					'pulse_style!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => '--apeiron-pulse-spread: {{SIZE}};',
				],
			]
		);

		$this->add_control(
			'pulse_opacity',
			[
				'label'   => __( 'Pulse Opacity', 'apeiron-kit' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0.6,
				],
				'range'   => [
					'px' => [
						'min'  => 0.1,
						'max'  => 1,
						'step' => 0.05,
					],
				],
				'condition' => [
					'pulse_style!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => '--apeiron-pulse-opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_icon',
			[
				'label' => __( 'Icon', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'icon_colors' );

		$this->start_controls_tab(
			'icon_colors_normal',
			[
				'label' => __( 'Normal', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'primary_color',
			[
				'label'     => __( 'Primary Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-framed .elementor-icon, {{WRAPPER}}.elementor-view-default .elementor-icon' => 'color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-framed .elementor-icon, {{WRAPPER}}.elementor-view-default .elementor-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'secondary_color',
			[
				'label'     => __( 'Secondary Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'view!' => 'default',
				],
				'selectors' => [
					'{{WRAPPER}}.elementor-view-framed .elementor-icon' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'icon_colors_hover',
			[
				'label' => __( 'Hover', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'hover_primary_color',
			[
				'label'     => __( 'Primary Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-framed .elementor-icon:hover, {{WRAPPER}}.elementor-view-default .elementor-icon:hover' => 'color: {{VALUE}}; border-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-framed .elementor-icon:hover, {{WRAPPER}}.elementor-view-default .elementor-icon:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_secondary_color',
			[
				'label'     => __( 'Secondary Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'view!' => 'default',
				],
				'selectors' => [
					'{{WRAPPER}}.elementor-view-framed .elementor-icon:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}}.elementor-view-stacked .elementor-icon:hover svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => __( 'Hover Animation', 'apeiron-kit' ),
				'type'  => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_responsive_control(
			'size',
			[
				'label'   => __( 'Size', 'apeiron-kit' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 22,
					'unit' => 'px',
				],
				'range' => [
					'px' => [
						'min' => 6,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'icon_padding',
			[
				'label' => __( 'Padding', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .elementor-icon' => 'padding: {{SIZE}}{{UNIT}};',
				],
				'range' => [
					'em' => [
						'min' => 0,
						'max' => 5,
					],
				],
				'condition' => [
					'view!' => 'default',
				],
			]
		);

		$this->add_responsive_control(
			'rotate',
			[
				'label' => __( 'Rotate', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0,
					'unit' => 'deg',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-icon i, {{WRAPPER}} .elementor-icon svg' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);

		$this->add_control(
			'border_width',
			[
				'label' => __( 'Border Width', 'apeiron-kit' ),
				'type'  => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .elementor-icon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'view' => 'framed',
				],
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .elementor-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'view!' => 'default',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_wrapper',
			[
				'label' => __( 'Wrapper', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'wrapper_background',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-player',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wrapper_border',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-player',
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-player' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-player' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'wrapper_shadow',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-player',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_shell',
			[
				'label' => __( 'Icon Shell', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'shell_background',
				'selector'  => '{{WRAPPER}} .apeiron-soundscape-icon-shell',
			]
		);

		$this->add_responsive_control(
			'shell_size',
			[
				'label' => __( 'Shell Size', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 24,
						'max' => 120,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-icon-shell' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'shell_border',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-icon-shell',
			]
		);

		$this->add_responsive_control(
			'shell_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-icon-shell' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'shell_primary_color',
			[
				'label'   => __( 'Icon Color', 'apeiron-kit' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#083c57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-player' => '--apeiron-soundscape-color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-soundscape-icon-shell .elementor-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-soundscape-icon-shell .elementor-icon i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .apeiron-soundscape-icon-shell .elementor-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'shell_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-icon-shell' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'shell_shadow',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-icon-shell',
			]
		);

		$this->add_responsive_control(
			'icon_label_gap',
			[
				'label' => __( 'Icon & Label Gap', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
				],
				'condition' => [
					'show_label' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-toggle-inner' => '--apeiron-soundscape-gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style_label',
			[
				'label'     => __( 'Label', 'apeiron-kit' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_label' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'           => 'label_typography',
				'selector'       => '{{WRAPPER}} .apeiron-soundscape-label',
				'fields_options' => [
					'font_size'      => [ 'default' => [ 'size' => 13, 'unit' => 'px' ] ],
					'font_weight'    => [ 'default' => '600' ],
					'letter_spacing' => [ 'default' => [ 'size' => 0.03, 'unit' => 'em' ] ],
					'line_height'    => [ 'default' => [ 'size' => 1.4, 'unit' => 'em' ] ],
				],
			]
		);

		$this->add_control(
			'label_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#1877F2',
				'selectors' => [
					'{{WRAPPER}} .apeiron-soundscape-label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'label_background',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-label',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'label_border',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-label',
			]
		);

		$this->add_responsive_control(
			'label_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'default'    => [
					'top'      => '0.2',
					'right'    => '0.65',
					'bottom'   => '0.2',
					'left'     => '0.65',
					'unit'     => 'em',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'label_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'      => '999',
					'right'    => '999',
					'bottom'   => '999',
					'left'     => '999',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-soundscape-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'label_shadow',
				'selector' => '{{WRAPPER}} .apeiron-soundscape-label',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}
		$settings = $this->get_settings_for_display();
		$wid      = $this->get_id(); // Unique widget ID for scoping

		// --- Separate render attributes for play & pause icon wrappers (BUG H3) ---
		$this->add_render_attribute(
			'toggle_play',
			[
				'class'    => [ 'elementor-icon-wrapper', 'apeiron-soundscape-toggle', 'is-play' ],
				'role'     => 'button',
				'tabindex' => '0',
			]
		);

		$this->add_render_attribute(
			'toggle_pause',
			[
				'class'    => [ 'elementor-icon-wrapper', 'apeiron-soundscape-toggle', 'is-pause' ],
				'role'     => 'button',
				'tabindex' => '0',
			]
		);

		// Separate icon wrapper attributes for play and pause (BUG H3)
		$icon_base_classes = [ 'elementor-icon', 'apeiron-soundscape-icon' ];
		if ( ! empty( $settings['hover_animation'] ) ) {
			$icon_base_classes[] = 'elementor-animation-' . $settings['hover_animation'];
		}
		$this->add_render_attribute( 'icon-wrapper-play', 'class', $icon_base_classes );
		$this->add_render_attribute( 'icon-wrapper-pause', 'class', $icon_base_classes );

		$icon_tag = 'div';

		// Legacy FA4 fallback
		if ( empty( $settings['icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
			$settings['icon'] = 'fa fa-music';
		}
		if ( ! empty( $settings['icon'] ) ) {
			$this->add_render_attribute( 'icon', 'class', $settings['icon'] );
			$this->add_render_attribute( 'icon', 'aria-hidden', 'true' );
		}

		// FA4 migration detection (BUG H4 — use correct key 'pause_icon')
		$migrated = isset( $settings['__fa4_migrated']['pause_icon'] );
		$is_new   = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();

		$player_skin       = $settings['player_skin'] ?? 'minimal';
		$show_label        = 'yes' === ( $settings['show_label'] ?? '' );
		$label_position    = $settings['label_position'] ?? 'after';
		$play_label        = ! empty( $settings['play_label_text'] ) ? $settings['play_label_text'] : __( 'Putar Musik', 'apeiron-kit' );
		$pause_label       = ! empty( $settings['pause_label_text'] ) ? $settings['pause_label_text'] : __( 'Jeda Musik', 'apeiron-kit' );
		$pulse_style       = $settings['pulse_style'] ?? '';
		$has_pulse         = ! empty( $pulse_style );
		$unique_class      = 'apeiron-soundscape-player-' . $wid;
		$player_skin_class = 'apeiron-soundscape-skin-' . \sanitize_html_class( $player_skin );
		$player_classes    = [
			'audio-box',
			'apeiron-soundscape-player',
			$unique_class,
			$player_skin_class,
		];
		// Editor mode detection removed — position is now fully controlled via Elementor selectors
		// No conditional editor-mode class needed

		if ( $show_label ) {
			$player_classes[] = 'has-label';
			$player_classes[] = 'label-' . \sanitize_html_class( $label_position );
		}
		if ( $has_pulse ) {
			$player_classes[] = 'has-pulse';
		}

		$player_classes = array_unique( array_filter( array_map( 'sanitize_html_class', $player_classes ) ) );
		$unique_selector = '.' . \sanitize_html_class( $unique_class );

		// --- Unique IDs per widget instance (BUG H2) ---
		$id_container  = 'audio-container-' . $wid;
		$id_play       = 'unmute-sound-' . $wid;
		$id_pause      = 'mute-sound-' . $wid;
		$id_audio      = 'song-' . $wid;
		$id_yt_audio   = 'youtube-audio-' . $wid;
		$id_yt_player  = 'youtube-player-' . $wid;

		$label_renderer = static function( $text, $modifier = '' ) {
			if ( empty( $text ) ) {
				return '';
			}
			$classes = 'apeiron-soundscape-label';
			if ( ! empty( $modifier ) ) {
				$classes .= ' ' . \sanitize_html_class( $modifier );
			}
			return sprintf( '<span class="%s">%s</span>', esc_attr( $classes ), esc_html( $text ) );
		};

		// --- Determine audio source ---
		$yt = false;
		if ( 'upload' === ( $settings['src_type'] ?? 'upload' ) ) {
			$audio_link = $settings['audio_upload']['url'] ?? '';
		} elseif ( 'link' === $settings['src_type'] ) {
			$audio_link = $settings['audio_link']['url'] ?? '';
		} else {
			$audio_link = $settings['youtube_link'] ?? '';
			$yt         = true;
		}

		// --- Inline styles from build_player_styles() ---
		$inline_styles = $this->build_player_styles( $unique_selector, $has_pulse );
		if ( ! empty( $inline_styles ) ) {
			printf( '<style>%s</style>', $inline_styles ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// --- Autoplay setting (scoped per widget, BUG J1) ---
		$is_autoplay = 'yes' === ( $settings['autoplay'] ?? '' );

		// --- Data attributes for external JS handler ---
		$data_attrs = sprintf(
			'data-src-type="%s" data-autoplay="%s" data-loop="%s" data-start="%s" data-end="%s" data-player-skin="%s"',
			esc_attr( $settings['src_type'] ?? 'upload' ),
			esc_attr( $is_autoplay ? 'yes' : 'no' ),
			esc_attr( ! empty( $settings['loop'] ) ? 'yes' : 'no' ),
			esc_attr( $settings['start'] ?? '' ),
			esc_attr( $settings['end'] ?? '' ),
			esc_attr( $player_skin )
		);

		// --- Player container (ALWAYS renders) ---
		echo '<div id="' . esc_attr( $id_container ) . '" class="' . esc_attr( implode( ' ', $player_classes ) ) . '" ' . $data_attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		// --- Audio element (only when source exists) ---
		if ( $audio_link ) {
			if ( $yt ) {
				echo '<div data-video="' . esc_url( $audio_link ) . '" id="' . esc_attr( $id_yt_audio ) . '"></div>';
			} else {
				$arr       = explode( '.', $audio_link );
				$file_ext  = end( $arr );
				$loop_attr = ! empty( $settings['loop'] ) ? ' loop' : '';
				echo '<audio id="' . esc_attr( $id_audio ) . '"' . $loop_attr . '><source src="' . esc_url( $audio_link ) . '" type="audio/' . esc_attr( $file_ext ) . '"></audio>';
			}
		}

		// --- Play toggle (visible by default) ---
		echo '<div ' . $this->get_render_attribute_string( 'toggle_play' ) . ' id="' . esc_attr( $id_play ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="apeiron-soundscape-toggle-inner">';
		if ( $show_label && 'before' === $label_position ) {
			echo $label_renderer( $play_label, 'is-before' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<span class="apeiron-soundscape-icon-shell">';
		if ( $has_pulse ) {
			echo '<span class="apeiron-soundscape-pulse" aria-hidden="true"></span>';
		}
		echo '<' . $icon_tag . ' ' . $this->get_render_attribute_string( 'icon-wrapper-play' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $is_new || $migrated ) {
			Icons_Manager::render_icon( $settings['pause_icon'], [ 'aria-hidden' => 'true' ] );
		} else {
			echo '<i ' . $this->get_render_attribute_string( 'icon' ) . '></i>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</' . $icon_tag . '>';
		echo '</span>';
		if ( $show_label && 'after' === $label_position ) {
			echo $label_renderer( $play_label, 'is-after' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( $show_label && 'stacked' === $label_position ) {
			echo $label_renderer( $play_label, 'is-stacked' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>'; // toggle-inner
		echo '</div>'; // play toggle

		// --- Pause toggle (hidden by default via CSS .is-pause) ---
		echo '<div ' . $this->get_render_attribute_string( 'toggle_pause' ) . ' id="' . esc_attr( $id_pause ) . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="apeiron-soundscape-toggle-inner">';
		if ( $show_label && 'before' === $label_position ) {
			echo $label_renderer( $pause_label, 'is-before' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<span class="apeiron-soundscape-icon-shell">';
		if ( $has_pulse ) {
			echo '<span class="apeiron-soundscape-pulse" aria-hidden="true"></span>';
		}
		echo '<' . $icon_tag . ' ' . $this->get_render_attribute_string( 'icon-wrapper-pause' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $is_new || $migrated ) {
			Icons_Manager::render_icon( $settings['play_icon'], [ 'aria-hidden' => 'true' ] );
		} else {
			echo '<i ' . $this->get_render_attribute_string( 'icon' ) . '></i>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</' . $icon_tag . '>';
		echo '</span>';
		if ( $show_label && 'after' === $label_position ) {
			echo $label_renderer( $pause_label, 'is-after' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( $show_label && 'stacked' === $label_position ) {
			echo $label_renderer( $pause_label, 'is-stacked' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>'; // toggle-inner
		echo '</div>'; // pause toggle

		echo '</div>'; // player container
	}

	private function build_player_styles( $selector, $has_pulse = false ) {
		if ( empty( $selector ) ) {
			return '';
		}

		// --- Core container: CSS variable defaults (pulse defaults only) ---
		$css  = $selector . '{--apeiron-soundscape-gap:.65rem;--apeiron-soundscape-color:#083c57;--apeiron-pulse-color:#083c57;--apeiron-pulse-duration:1.8s;--apeiron-pulse-spread:2.2;--apeiron-pulse-opacity:0.6;}' . PHP_EOL;

		// --- Pulse animations (all using CSS variables for live control) ---
		if ( $has_pulse ) {
			$settings = $this->get_settings_for_display();
			$pulse_style = $settings['pulse_style'] ?? 'ripple';

			if ( 'ripple' === $pulse_style ) {
				$css .= '@keyframes apeironPulseRipple{0%{transform:scale(0.8);opacity:var(--apeiron-pulse-opacity, 0.6);}100%{transform:scale(var(--apeiron-pulse-spread, 2.2));opacity:0;}}' . PHP_EOL;
				$css .= $selector . '.has-pulse .apeiron-soundscape-pulse{position:absolute;inset:-4px;border-radius:50%;border:2px solid var(--apeiron-pulse-color, #083c57);opacity:0;z-index:0;pointer-events:none;animation:apeironPulseRipple var(--apeiron-pulse-duration, 1.8s) ease-out infinite;}' . PHP_EOL;
				$css .= $selector . '.has-pulse .apeiron-soundscape-pulse::before{content:"";position:absolute;inset:-2px;border-radius:inherit;border:1px solid var(--apeiron-pulse-color, #083c57);animation:apeironPulseRipple var(--apeiron-pulse-duration, 1.8s) ease-out infinite;animation-delay:0.4s;}' . PHP_EOL;
			} elseif ( 'glow' === $pulse_style ) {
				$css .= '@keyframes apeironPulseGlow{0%,100%{box-shadow:0 0 0 0 transparent;}50%{box-shadow:0 0 12px calc(6px * var(--apeiron-pulse-spread, 2.2) / 2.2) var(--apeiron-pulse-color, rgba(8,60,87,0.35));}}' . PHP_EOL;
				$css .= $selector . '.has-pulse .apeiron-soundscape-pulse{position:absolute;inset:-2px;border-radius:50%;z-index:0;pointer-events:none;animation:apeironPulseGlow var(--apeiron-pulse-duration, 1.8s) ease-in-out infinite;}' . PHP_EOL;
			} elseif ( 'heartbeat' === $pulse_style ) {
				$css .= '@keyframes apeironPulseHeartbeat{0%,100%{transform:scale(1);}15%{transform:scale(1.2);}30%{transform:scale(1);}45%{transform:scale(1.15);}60%{transform:scale(1);}}' . PHP_EOL;
				$css .= $selector . '.has-pulse .apeiron-soundscape-icon-shell{animation:apeironPulseHeartbeat var(--apeiron-pulse-duration, 1.8s) ease-in-out infinite;}' . PHP_EOL;
				$css .= $selector . '.has-pulse .apeiron-soundscape-toggle.is-pause .apeiron-soundscape-icon-shell{animation:apeironPulseHeartbeat var(--apeiron-pulse-duration, 1.8s) ease-in-out infinite;}' . PHP_EOL;
			}
		}

		return $css;
	}
}
