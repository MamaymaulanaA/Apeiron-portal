<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class PulseCountdown extends BaseWidget {

	public function get_name() {
		return 'apeiron-pulse-countdown';
	}

	public function get_title() {
		return __( 'Countdown Timer', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-countdown';
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-pulse-countdown';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-countdown-js' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}

		/* ===========================
		 * TAB KONTEN
		 * =========================== */

		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'Pengaturan', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'target_date',
			[
				'label'       => __( 'Tanggal Target Countdown', 'apeiron-kit' ),
				'type'        => Controls_Manager::DATE_TIME,
				'default'     => gmdate( 'Y-m-d H:i', strtotime( '+1 week' ) ),
				'description' => __( 'Atur tanggal dan waktu target countdown.', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'countdown_position',
			[
				'label'   => __( 'Posisi', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'inline',
				'options' => [
					'inline' => __( 'Inline', 'apeiron-kit' ),
					'block'  => __( 'Block', 'apeiron-kit' ),
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown' => 'flex-direction: {{VALUE}};',
				],
				'selectors_dictionary' => [
					'inline' => 'row',
					'block'  => 'column',
				],
			]
		);

		$this->add_control(
			'expired_text',
			[
				'label'       => __( 'Teks Saat Countdown Selesai', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Waktu habis!', 'apeiron-kit' ),
				'description' => __( 'Teks yang ditampilkan saat countdown sudah selesai. Kosongkan untuk tidak menampilkan pesan.', 'apeiron-kit' ),
			]
		);

		$this->end_controls_section();

		/* --- Tampilkan Bagian --- */

		$this->start_controls_section(
			'section_parts',
			[
				'label' => __( 'Tampilkan Bagian', 'apeiron-kit' ),
			]
		);

		// Hari
		$this->add_control(
			'show_days',
			[
				'label'        => __( 'Tampilkan Hari', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'label_days',
			[
				'label'     => __( 'Label Hari', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Hari', 'apeiron-kit' ),
				'condition' => [
					'show_days' => 'yes',
				],
			]
		);

		// Jam
		$this->add_control(
			'show_hours',
			[
				'label'        => __( 'Tampilkan Jam', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'label_hours',
			[
				'label'     => __( 'Label Jam', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Jam', 'apeiron-kit' ),
				'condition' => [
					'show_hours' => 'yes',
				],
			]
		);

		// Menit
		$this->add_control(
			'show_minutes',
			[
				'label'        => __( 'Tampilkan Menit', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'label_minutes',
			[
				'label'     => __( 'Label Menit', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Menit', 'apeiron-kit' ),
				'condition' => [
					'show_minutes' => 'yes',
				],
			]
		);

		// Detik
		$this->add_control(
			'show_seconds',
			[
				'label'        => __( 'Tampilkan Detik', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'label_seconds',
			[
				'label'     => __( 'Label Detik', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => __( 'Detik', 'apeiron-kit' ),
				'condition' => [
					'show_seconds' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		/* --- Pemisah Countdown --- */

		$this->start_controls_section(
			'section_separator',
			[
				'label' => __( 'Pemisah Countdown', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'show_separator',
			[
				'label'        => __( 'Tampilkan Pemisah', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => '',
			]
		);

		$this->add_control(
			'separator_text',
			[
				'label'     => __( 'Teks Pemisah', 'apeiron-kit' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => ':',
				'condition' => [
					'show_separator' => 'yes',
				],
			]
		);

		$this->add_control(
			'separator_color',
			[
				'label'     => __( 'Warna Pemisah', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083c57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__separator' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_separator' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'separator_typography',
				'selector'  => '{{WRAPPER}} .apeiron-kit-countdown__separator',
				'condition' => [
					'show_separator' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		/* ===========================
		 * TAB STYLE
		 * =========================== */

		/* --- Wrapper --- */

		$this->start_controls_section(
			'section_style_wrapper',
			[
				'label' => __( 'Wrapper', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'wrapper_background_color',
			[
				'label'     => __( 'Background Wrapper', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown-wrapper' => 'background-color: {{VALUE}}; background-image: none;',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-countdown-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-countdown-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'wrapper_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown-wrapper',
			]
		);

		$this->add_responsive_control(
			'wrapper_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-countdown-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'wrapper_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown-wrapper',
				'fields_options' => [
					'box_shadow' => [
						'default' => [
							'horizontal' => 0,
							'vertical' => 0,
							'blur' => 0,
							'spread' => 0,
							'color' => 'rgba(0,0,0,0)',
						],
					],
				],
			]
		);

		$this->end_controls_section();

		/* --- Item Countdown --- */

		$this->start_controls_section(
			'section_style_item',
			[
				'label' => __( 'Item Countdown', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'item_background_color',
			[
				'label'     => __( 'Background Item', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083c57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__item' => 'background-color: {{VALUE}}; background-image: none;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'item_border',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown__item',
			]
		);

		$this->add_responsive_control(
			'item_radius',
			[
				'label'      => __( 'Radius Item', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => '6',
					'right'  => '6',
					'bottom' => '6',
					'left'   => '6',
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-countdown__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => __( 'Padding Item', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'      => '5',
					'right'    => '10',
					'bottom'   => '5',
					'left'     => '10',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-kit-countdown__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_gap',
			[
				'label' => __( 'Jarak Antar Item', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
				],
				'default' => [
					'size' => 3,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown' => 'gap: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'item_min_width',
			[
				'label' => __( 'Lebar Minimum Item', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 9,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__item' => 'min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'item_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown__item',
			]
		);

		$this->end_controls_section();

		/* --- Typography & Warna --- */

		$this->start_controls_section(
			'section_style_typography',
			[
				'label' => __( 'Typography & Warna', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'value_heading',
			[
				'label' => __( 'Angka Countdown', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'value_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown__value',
			]
		);

		$this->add_control(
			'value_color',
			[
				'label'     => __( 'Warna Angka', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__value' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'label_heading',
			[
				'label' => __( 'Label Countdown', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .apeiron-kit-countdown__label',
			]
		);

		$this->add_control(
			'label_color',
			[
				'label'     => __( 'Warna Label', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__label' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'label_spacing',
			[
				'label' => __( 'Spacing Angka & Label', 'apeiron-kit' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
					],
				],
				'default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .apeiron-kit-countdown__label' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['target_date'] ) ) {
			echo '<div class="elementor-alert elementor-alert-warning">' . esc_html__( 'Tanggal acara belum ditentukan.', 'apeiron-kit' ) . '</div>';
			return;
		}

		$show_days    = ( $settings['show_days'] ?? 'yes' ) === 'yes';
		$show_hours   = ( $settings['show_hours'] ?? 'yes' ) === 'yes';
		$show_minutes = ( $settings['show_minutes'] ?? 'yes' ) === 'yes';
		$show_seconds = ( $settings['show_seconds'] ?? 'yes' ) === 'yes';
		$show_sep     = ( $settings['show_separator'] ?? '' ) === 'yes';
		$sep_text     = $settings['separator_text'] ?? ':';

		$parts = [];
		if ( $show_days ) {
			$parts[] = [ 'part' => 'days', 'label' => $settings['label_days'] ?? __( 'Hari', 'apeiron-kit' ) ];
		}
		if ( $show_hours ) {
			$parts[] = [ 'part' => 'hours', 'label' => $settings['label_hours'] ?? __( 'Jam', 'apeiron-kit' ) ];
		}
		if ( $show_minutes ) {
			$parts[] = [ 'part' => 'minutes', 'label' => $settings['label_minutes'] ?? __( 'Menit', 'apeiron-kit' ) ];
		}
		if ( $show_seconds ) {
			$parts[] = [ 'part' => 'seconds', 'label' => $settings['label_seconds'] ?? __( 'Detik', 'apeiron-kit' ) ];
		}

		$gmt_offset   = (float) get_option( 'gmt_offset', 0 );
		$expired_text = $settings['expired_text'] ?? '';
		?>
		<div class="apeiron-kit-countdown-wrapper">
			<div class="apeiron-kit-countdown" data-apeiron-countdown="<?php echo esc_attr( $settings['target_date'] ); ?>" data-timezone-offset="<?php echo esc_attr( $gmt_offset ); ?>"<?php echo $expired_text ? ' data-expired-text="' . esc_attr( $expired_text ) . '"' : ''; ?>>
				<?php foreach ( $parts as $i => $p ) : ?>
					<?php if ( $show_sep && $i > 0 ) : ?>
						<span class="apeiron-kit-countdown__separator"><?php echo esc_html( $sep_text ); ?></span>
					<?php endif; ?>
					<?php echo wp_kses_post( $this->render_item( $p['part'], $p['label'] ) ); ?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	private function render_item( string $part, string $label ): string {
		ob_start();
		?>
		<div class="apeiron-kit-countdown__item">
			<span class="apeiron-kit-countdown__value" data-part="<?php echo esc_attr( $part ); ?>">00</span>
			<span class="apeiron-kit-countdown__label"><?php echo esc_html( $label ); ?></span>
		</div>
		<?php
		return ob_get_clean();
	}

	protected function content_template() {
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled — do not render editor JS template
		}
		?>
		<#
		var targetDate = settings.target_date;
		if ( ! targetDate ) {
		#>
			<div class="elementor-alert elementor-alert-warning">
				<?php esc_html_e( 'Tanggal acara belum ditentukan.', 'apeiron-kit' ); ?>
			</div>
		<#
		} else {
			var parts = [];
			if ( settings.show_days === 'yes' ) {
				parts.push({ part: 'days', label: settings.label_days || '<?php esc_attr_e( 'Hari', 'apeiron-kit' ); ?>' });
			}
			if ( settings.show_hours === 'yes' ) {
				parts.push({ part: 'hours', label: settings.label_hours || '<?php esc_attr_e( 'Jam', 'apeiron-kit' ); ?>' });
			}
			if ( settings.show_minutes === 'yes' ) {
				parts.push({ part: 'minutes', label: settings.label_minutes || '<?php esc_attr_e( 'Menit', 'apeiron-kit' ); ?>' });
			}
			if ( settings.show_seconds === 'yes' ) {
				parts.push({ part: 'seconds', label: settings.label_seconds || '<?php esc_attr_e( 'Detik', 'apeiron-kit' ); ?>' });
			}

			var showSep = settings.show_separator === 'yes';
			var sepText = settings.separator_text || ':';
		#>
		<div class="apeiron-kit-countdown-wrapper">
			<div class="apeiron-kit-countdown" data-apeiron-countdown="{{ targetDate }}">
				<# _.each( parts, function( p, i ) { #>
					<# if ( showSep && i > 0 ) { #>
						<span class="apeiron-kit-countdown__separator">{{ sepText }}</span>
					<# } #>
					<div class="apeiron-kit-countdown__item">
						<span class="apeiron-kit-countdown__value" data-part="{{ p.part }}">00</span>
						<span class="apeiron-kit-countdown__label">{{ p.label }}</span>
					</div>
				<# }); #>
			</div>
		</div>
		<# } #>
		<?php
	}
}
