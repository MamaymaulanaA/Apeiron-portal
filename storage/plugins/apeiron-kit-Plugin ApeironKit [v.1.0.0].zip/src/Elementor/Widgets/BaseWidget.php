<?php
/**
 * Base Widget Class
 *
 * Abstract base class for all Apeiron Kit Elementor widgets.
 * Provides license validation, widget disabled gate, shared dependencies,
 * and common functionality.
 *
 * @package ApeironKit
 * @since 1.0.0
 */

namespace ApeironKit\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use ApeironKit\Core\LicenseManager;

/**
 * Class BaseWidget
 *
 * All Apeiron Kit widgets extend this class to inherit:
 * - Widget disabled gate (Layer 2 render protection)
 * - License validation and lock state rendering
 * - Common asset dependencies
 * - Widget category registration
 *
 * @abstract
 * @since 1.0.0
 */
abstract class BaseWidget extends Widget_Base {

	/**
	 * Map of Elementor widget type => dashboard toggle slug.
	 *
	 * Reverse of WidgetToggleHandler::WIDGET_SLUG_TO_TYPE.
	 * Used by the render gate to check if a widget is disabled.
	 *
	 * @var array<string, string>
	 */
	private const WIDGET_TYPE_TO_SLUG = [
		'apeiron-comment-dock'             => 'comment_dock',
		'apeiron-pulse-countdown'          => 'pulse_countdown',
		'apeiron-guest-invitation-manager' => 'guest_manager',
		'apeiron-clipboard-tap'            => 'clipboard_tap',
		'apeiron-soundscape'               => 'soundscape',
		'apeiron-signal-form'              => 'signal_form',
		'apeiron-social-proof'             => 'social_proof',
		'apeiron-autoscroll'               => 'autoscroll',
	];

	/**
	 * Static cache of disabled widget slugs.
	 *
	 * Populated once per request via get_option() to avoid
	 * repeated database queries when multiple widgets render.
	 *
	 * @var string[]|null
	 */
	private static ?array $disabled_cache = null;

	/**
	 * License manager instance (lazy loaded).
	 *
	 * @var LicenseManager|null
	 */
	private ?LicenseManager $license_manager = null;

	/**
	 * Get widget categories.
	 *
	 * Register this widget under the 'apeiron-kit' category.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'apeiron-kit' ];
	}

	/**
	 * Get script dependencies.
	 *
	 * @return array Scripts this widget depends on.
	 */
	public function get_script_depends() {
		return [];
	}

	/**
	 * Get style dependencies.
	 *
	 * @return array Stylesheets this widget depends on.
	 */
	public function get_style_depends() {
		return [ 'apeiron-kit-frontend' ];
	}

	/**
	 * Get license manager instance
	 */
	protected function get_license_manager(): LicenseManager {
		if ( null === $this->license_manager ) {
			$this->license_manager = LicenseManager::instance();
		}
		return $this->license_manager;
	}

	/**
	 * Check if license is valid
	 */
	protected function is_license_valid(): bool {
		return $this->get_license_manager()->is_valid();
	}

	/**
	 * Check if this widget is disabled via the dashboard toggle.
	 *
	 * Layer 2 (Render Gate): Even if Elementor attempts to render
	 * a widget from cached _elementor_data, this method allows the
	 * render() function to bail out and produce no HTML output.
	 *
	 * Uses a static cache so get_option() is called only once per
	 * PHP request, regardless of how many widgets are on the page.
	 *
	 * @return bool True if widget is disabled and should not render.
	 */
	protected function is_widget_disabled(): bool {
		// Populate cache on first call
		if ( null === self::$disabled_cache ) {
			$disabled = get_option( 'apeiron_kit_disabled_widgets', [] );
			self::$disabled_cache = is_array( $disabled ) ? $disabled : [];
		}

		$slug = self::WIDGET_TYPE_TO_SLUG[ $this->get_name() ] ?? '';

		return $slug && in_array( $slug, self::$disabled_cache, true );
	}

	/**
	 * Check if widget should render.
	 *
	 * Convenience helper — returns true when the widget is NOT disabled.
	 * Child classes may call this after parent::render() as an extra guard.
	 *
	 * @since 1.0.0
	 * @return bool True if widget should render, false if disabled.
	 */
	protected function should_render_widget(): bool {
		return ! $this->is_widget_disabled();
	}

	/**
	 * Register controls with license check
	 * Child classes should call parent::register_controls() at the start of their register_controls() method
	 */
	protected function register_controls() {
		// License validation is handled in render() — no visual notice needed here
	}


	/**
	 * Render widget with disabled gate and license check.
	 *
	 * Child classes should call parent::render() at the start of
	 * their render() method. The execution order is:
	 *
	 * 1. Layer 2 — Disabled gate: if widget is toggled off, output nothing.
	 * 2. License gate: if license is invalid, show locked message.
	 * 3. Child class continues rendering if both checks pass.
	 */
	protected function render() {
		// Layer 2: Render Gate — block output for disabled widgets.
		// This catches widgets that Elementor tries to render from
		// cached _elementor_data even after they have been toggled off.
		if ( $this->is_widget_disabled() ) {
			return; // Output nothing — widget is disabled via dashboard toggle
		}

		if ( ! $this->is_license_valid() ) {
			$this->render_locked_widget();
			return;
		}
		// If both checks pass, child class will continue rendering
	}

	/**
	 * Render locked widget message (frontend)
	 */
	protected function render_locked_widget(): void {
		// Enqueue Google Fonts: Poppins
		wp_enqueue_style(
			'apeiron-kit-google-fonts-poppins',
			'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap',
			[],
			null
		);

		// Enqueue the widget lock CSS
		wp_enqueue_style(
			'apeiron-kit-widget-lock',
			APEIRON_KIT_URL . 'assets/css/apeiron-widget-lock.css',
			[ 'apeiron-kit-google-fonts-poppins' ],
			APEIRON_KIT_VERSION
		);

		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			$settings_url = admin_url( 'admin.php?page=apeiron-kit-license' );
			?>
			<style>
				.apeiron-widget-locked-frontend{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;max-width:380px;margin:0 auto;padding:36px 28px 32px;background:#fff;border:none;border-radius:12px;box-sizing:border-box;font-family:'Poppins',sans-serif!important}
				.apeiron-locked-frontend-icon{width:58px;height:58px;margin:0 auto 12px;background:transparent;border:2px solid #374151;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:none;animation:apeironLockFloat 2.5s ease-in-out infinite}
				.apeiron-locked-frontend-icon svg{color:#374151;width:26px;height:26px;display:block}
				@keyframes apeironLockFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
				.apeiron-widget-locked-frontend h3{margin:0 0 2px;padding:0;color:#1f2937;font-size:20px;font-weight:500;line-height:1.3;font-family:'Poppins',sans-serif!important;text-shadow:none}
				.apeiron-widget-locked-frontend p{margin:0;padding:0;color:#6b7280;font-size:12px;font-weight:400;line-height:1.5;font-family:'Poppins',sans-serif!important;text-shadow:none}
				.apeiron-locked-activate-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;margin-top:6px;padding:12px 17px;background:#083c57;background-image:none;color:#fff!important;font-size:12px;font-weight:400;text-decoration:none!important;border-radius:3px;border:none;cursor:pointer;transition:opacity .2s ease;box-shadow:none!important;line-height:1.4;font-family:'Poppins',sans-serif!important;outline:none}
				.apeiron-locked-activate-btn:hover{opacity:.85;box-shadow:none!important;transform:none;color:#fff!important;text-decoration:none!important;background:#083c57}
				.apeiron-locked-activate-btn svg{flex-shrink:0;width:14px;height:14px;display:block}
			</style>
			<div class="apeiron-widget-locked-frontend">
				<div class="apeiron-locked-frontend-icon">
					<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<circle cx="15.5" cy="8.5" r="1.5"></circle>
						<path d="M12 2a6.5 6.5 0 0 1 6.5 6.5c0 1.63-.6 3.12-1.59 4.26l-.41.44-5.5 5.5a2.5 2.5 0 0 1-2.7.54l-.3-.14a2.5 2.5 0 0 1-.54-.39l-.7-.7a2.5 2.5 0 0 1 0-3.54l.7-.7-.7-.7a2.5 2.5 0 0 1 0-3.54l.35-.35L9 8.5A6.5 6.5 0 0 1 12 2z"></path>
					</svg>
				</div>
				<h3><?php esc_html_e( 'Widget Terkunci', 'apeiron-kit' ); ?></h3>
				<p><?php esc_html_e( 'Aktifkan Lisensi Untuk Menggunakan Widget Ini', 'apeiron-kit' ); ?></p>
				<a href="<?php echo esc_url( $settings_url ); ?>" class="apeiron-locked-activate-btn" target="_blank">
					<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
						<path d="M7 11V7a5 5 0 0 1 9.9-1"></path>
					</svg>
					<?php esc_html_e( 'Aktifkan Lisensi', 'apeiron-kit' ); ?>
				</a>
			</div>
			<?php
		} else {
			// On frontend, show nothing or minimal message
			?>
			<div class="apeiron-widget-locked-frontend apeiron-widget-locked-frontend--hidden">
				<!-- Widget locked - hidden on frontend -->
			</div>
			<?php
		}
	}

	/**
	 * Block JS-rendered editor preview for disabled widgets.
	 *
	 * Defense-in-depth: since disabled widgets are not registered
	 * (Layer 1), Elementor should never call this method for them.
	 * But if editor cache somehow loads a disabled widget, this
	 * ensures no JavaScript template is provided.
	 */
	protected function content_template() {
		// Intentionally empty — all Apeiron Kit widgets use PHP render().
		// This override prevents Elementor from rendering any JS template
		// for a widget that should not be visible.
	}

}

