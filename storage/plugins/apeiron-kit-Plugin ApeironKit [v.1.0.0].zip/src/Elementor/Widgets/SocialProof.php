<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

class SocialProof extends BaseWidget {

	public function get_name() {
		return 'apeiron-social-proof';
	}

	public function get_title() {
		return __( 'Social Proof', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-notification';
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-social-proof';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-social-proof-js' ];
	}

	public function get_keywords() {
		return [ 'social', 'proof', 'notification', 'popup', 'alert' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}

		// =============================================
		// TAB CONTENT — Pengaturan
		// =============================================
		$this->start_controls_section(
			'section_settings',
			[
				'label' => __( 'Pengaturan', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'info_notice',
			[
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => __( '<div style="padding:10px 12px;background:#fff;border-radius:6px;border:1px solid #e2e8f0"><strong style="color:#0f172a;font-size:12px">Kelola Data Client</strong><br><span style="color:#64748b;font-size:11px">Tambahkan data client di <a href="' . admin_url( 'admin.php?page=apeiron-kit-social-proof' ) . '" target="_blank" style="color:#083C57;font-weight:600;text-decoration:none">Dashboard → ApeironKit → Social Proof</a></span></div>', 'apeiron-kit' ),
				'content_classes' => 'apeiron-info-notice',
			]
		);

		$this->add_control(
			'enable_popup',
			[
				'label'        => __( 'Aktifkan Popup', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'text_template',
			[
				'label'       => __( 'Template Teks', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'default'     => '{name} telah membeli {product} pada:',
				'placeholder' => '{name} telah membeli {product} pada:',
				'description' => __( 'Gunakan {name} untuk nama client dan {product} untuk nama tema/produk', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'override_position',
			[
				'label'        => __( 'Override Posisi', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __( 'Aktifkan untuk mengubah posisi dari pengaturan dashboard', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'popup_position',
			[
				'label'     => __( 'Posisi Popup', 'apeiron-kit' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'top-right'    => __( 'Atas Kanan', 'apeiron-kit' ),
					'top-left'     => __( 'Atas Kiri', 'apeiron-kit' ),
					'bottom-right' => __( 'Bawah Kanan', 'apeiron-kit' ),
					'bottom-left'  => __( 'Bawah Kiri', 'apeiron-kit' ),
				],
				'default'   => 'bottom-right',
				'condition' => [
					'override_position' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// =============================================
		// TAB STYLE — Popup Container
		// =============================================
		$this->start_controls_section(
			'section_style_popup',
			[
				'label' => __( 'Popup', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'popup_width',
			[
				'label'      => __( 'Lebar', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 250,
						'max'  => 500,
						'step' => 10,
					],
				],
				'default'    => [
					'size' => 340,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-social-proof-popup' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'popup_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'default'    => [
					'top'      => 14,
					'right'    => 16,
					'bottom'   => 14,
					'left'     => 16,
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-social-proof-popup' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'popup_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-social-proof-popup' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'popup_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-social-proof-popup' => 'background-color: {{VALUE}}; background-image: none;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'           => 'popup_border',
				'selector'       => '{{WRAPPER}} .apeiron-social-proof-popup',
				'fields_options' => [
					'border' => [
						'default' => 'solid',
					],
					'width'  => [
						'default' => [
							'top'      => 1,
							'right'    => 1,
							'bottom'   => 1,
							'left'     => 1,
							'unit'     => 'px',
							'isLinked' => true,
						],
					],
					'color'  => [
						'default' => '#e5e7eb',
					],
				],
			]
		);

		$this->add_responsive_control(
			'popup_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'      => 8,
					'right'    => 8,
					'bottom'   => 8,
					'left'     => 8,
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-social-proof-popup' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'           => 'popup_box_shadow',
				'selector'       => '{{WRAPPER}} .apeiron-social-proof-popup',
				'fields_options' => [
					'box_shadow_type' => [
						'default' => 'no',
					],
					'box_shadow'      => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 0,
							'spread'     => 0,
							'color'      => 'rgba(0,0,0,0)',
						],
					],
				],
			]
		);

		$this->add_responsive_control(
			'content_gap',
			[
				'label'      => __( 'Jarak Gambar & Teks', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 40,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 12,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-popup-content' => 'gap: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->end_controls_section();

		// =============================================
		// TAB STYLE — Foto Client
		// =============================================
		$this->start_controls_section(
			'section_style_image',
			[
				'label' => __( 'Foto Client', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_size',
			[
				'label'      => __( 'Ukuran', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 32,
						'max'  => 120,
						'step' => 2,
					],
				],
				'default'    => [
					'size' => 48,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-popup-image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'      => 6,
					'right'    => 6,
					'bottom'   => 6,
					'left'     => 6,
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-popup-image, {{WRAPPER}} .apeiron-popup-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_background_color',
			[
				'label'     => __( 'Background (Placeholder)', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f1f5f9',
				'selectors' => [
					'{{WRAPPER}} .apeiron-popup-image' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'image_border',
				'selector' => '{{WRAPPER}} .apeiron-popup-image',
			]
		);

		$this->end_controls_section();

		// =============================================
		// TAB STYLE — Teks
		// =============================================
		$this->start_controls_section(
			'section_style_text',
			[
				'label' => __( 'Teks', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		// --- Nama Client ---
		$this->add_control(
			'name_heading',
			[
				'label' => __( 'Nama Client', 'apeiron-kit' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typography',
				'selector' => '{{WRAPPER}} .apeiron-popup-name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083C57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-popup-name' => 'color: {{VALUE}};',
				],
			]
		);

		// --- Deskripsi ---
		$this->add_control(
			'desc_heading',
			[
				'label'     => __( 'Deskripsi', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'desc_typography',
				'selector' => '{{WRAPPER}} .apeiron-popup-desc',
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#475569',
				'selectors' => [
					'{{WRAPPER}} .apeiron-popup-desc' => 'color: {{VALUE}};',
				],
			]
		);

		// --- Nama Produk/Tema ---
		$this->add_control(
			'product_heading',
			[
				'label'     => __( 'Nama Produk/Tema', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'product_typography',
				'selector' => '{{WRAPPER}} .apeiron-popup-product',
			]
		);

		$this->add_control(
			'product_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083C57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-popup-product' => 'color: {{VALUE}};',
				],
			]
		);

		// --- Tanggal ---
		$this->add_control(
			'date_heading',
			[
				'label'     => __( 'Tanggal', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'date_typography',
				'selector' => '{{WRAPPER}} .apeiron-popup-date',
			]
		);

		$this->add_control(
			'date_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#94a3b8',
				'selectors' => [
					'{{WRAPPER}} .apeiron-popup-date' => 'color: {{VALUE}};',
				],
			]
		);

		// --- Spacing Teks ---
		$this->add_control(
			'spacing_heading',
			[
				'label'     => __( 'Jarak Antar Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'spacing_name_desc',
			[
				'label'      => __( 'Nama → Deskripsi', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 2,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-popup-name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'spacing_desc_date',
			[
				'label'      => __( 'Deskripsi → Tanggal', 'apeiron-kit' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
				],
				'default'    => [
					'size' => 3,
					'unit' => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-popup-desc' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}

		$settings = $this->get_settings_for_display();

		if ( $settings['enable_popup'] !== 'yes' ) {
			return;
		}

		$option_name = 'apeiron_social_proof_settings';
		$defaults    = [
			'display_duration'  => 3,
			'interval_duration' => 2,
			'animation_type'    => 'slide-top',
			'popup_position'    => 'bottom-right',
			'text_template'     => '{name} telah membeli {product} pada:',
			'image_border_radius' => 10,
			'entries'           => [],
		];
		$social_proof_settings = wp_parse_args( get_option( $option_name, [] ), $defaults );

		$entries = $social_proof_settings['entries'] ?? [];
		if ( empty( $entries ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div style="padding:20px;background:#f8fafc;border-radius:8px;border:1px solid #e5e7eb;text-align:center;color:#64748b;font-size:13px">
					<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 10px;display:block;opacity:.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
					<strong>Belum ada data client</strong><br>
					<span style="font-size:12px">Tambahkan di Dashboard → ApeironKit → Social Proof</span>
				</div>';
			}
			return;
		}

		$text_template    = $settings['text_template'] ?? $social_proof_settings['text_template'];
		$display_duration = ( $social_proof_settings['display_duration'] ?? 3 ) * 1000;
		$interval_duration = ( $social_proof_settings['interval_duration'] ?? 2 ) * 1000;
		$animation_type   = $social_proof_settings['animation_type'] ?? 'slide-top';

		// Determine popup position from Content tab or dashboard setting
		$popup_position = ( ( $settings['override_position'] ?? '' ) === 'yes' )
			? ( $settings['popup_position'] ?? 'bottom-right' )
			: ( $social_proof_settings['popup_position'] ?? 'bottom-right' );

		// Map popup_position to h/v classes
		$pos_map = [
			'top-right'    => [ 'right', 'top' ],
			'top-left'     => [ 'left', 'top' ],
			'bottom-right' => [ 'right', 'bottom' ],
			'bottom-left'  => [ 'left', 'bottom' ],
		];
		$pos_h = isset( $pos_map[ $popup_position ] ) ? $pos_map[ $popup_position ][0] : 'right';
		$pos_v = isset( $pos_map[ $popup_position ] ) ? $pos_map[ $popup_position ][1] : 'bottom';

		// Build position CSS classes
		$pos_classes = 'apeiron-sp-h-' . esc_attr( $pos_h ) . ' apeiron-sp-v-' . esc_attr( $pos_v );

		// Convert entries to JSON format
		$entries_json = [];
		foreach ( $entries as $entry ) {
			$entries_json[] = [
				'name'     => $entry['name'] ?? 'Apeiron',
				'product'  => $entry['product'] ?? 'Apeiron',
				'image'    => $entry['image'] ?? '',
				'datetime' => $entry['datetime'] ?? '',
			];
		}

		?>
		<div class="apeiron-social-proof-popup apeiron-sp-animation-<?php echo esc_attr( $animation_type ); ?> <?php echo esc_attr( $pos_classes ); ?>"
		     data-entries="<?php echo esc_attr( wp_json_encode( $entries_json ) ); ?>"
		     data-text-template="<?php echo esc_attr( $text_template ); ?>"
		     data-display-duration="<?php echo absint( $display_duration ); ?>"
		     data-interval-duration="<?php echo absint( $interval_duration ); ?>">
			<div class="apeiron-popup-content">
				<div class="apeiron-popup-image">
					<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="color:#94a3b8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
				</div>
				<div class="apeiron-popup-text">
					<div class="apeiron-popup-name">Apeiron</div>
					<div class="apeiron-popup-desc"></div>
					<div class="apeiron-popup-date"></div>
				</div>
			</div>
		</div>
		<?php
	}
}
