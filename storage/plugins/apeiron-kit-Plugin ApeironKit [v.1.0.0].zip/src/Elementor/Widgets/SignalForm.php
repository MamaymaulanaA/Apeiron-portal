<?php

namespace ApeironKit\Elementor\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

class SignalForm extends BaseWidget {

	public function get_name() {
		return 'apeiron-signal-form';
	}

	public function get_title() {
		return __( 'Smart Form', 'apeiron-kit' );
	}

	public function get_icon() {
		return 'apeiron-icon-form';
	}

	public function get_style_depends() {
		$styles = parent::get_style_depends();
		$styles[] = 'apeiron-kit-signal-form';
		return $styles;
	}

	public function get_script_depends() {
		return [ 'apeiron-kit-signal-form-js' ];
	}

	protected function register_controls() {
		parent::register_controls(); // Add license notice section

		if ( ! $this->is_license_valid() ) {
			return; // Don't register other controls if license is invalid
		}

		$this->start_controls_section(
			'section_general',
			[
				'label' => __( 'Form', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'phone_number',
			[
				'label'       => __( 'Nomor WhatsApp', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '628123456789',
				'label_block' => true,
			]
		);

		$this->add_control(
			'form_title',
			[
				'label'       => __( 'Judul Form', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Konfirmasi Kehadiran', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'label',
			[
				'label'   => __( 'Label', 'apeiron-kit' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Nama Tamu', 'apeiron-kit' ),
			]
		);
		$repeater->add_control(
			'name',
			[
				'label'   => __( 'Field ID', 'apeiron-kit' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'nama',
			]
		);
		$repeater->add_control(
			'placeholder',
			[
				'label'   => __( 'Placeholder', 'apeiron-kit' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Tulis nama lengkap', 'apeiron-kit' ),
			]
		);
		$repeater->add_control(
			'type',
			[
				'label'   => __( 'Tipe Input', 'apeiron-kit' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'text'     => __( 'Teks', 'apeiron-kit' ),
					'number'   => __( 'Angka', 'apeiron-kit' ),
					'textarea' => __( 'Paragraf', 'apeiron-kit' ),
				],
				'default' => 'text',
			]
		);

		$this->add_control(
			'fields',
			[
				'label'       => __( 'Kolom', 'apeiron-kit' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'label'       => __( 'Nama Tamu', 'apeiron-kit' ),
						'name'        => 'nama',
						'placeholder' => __( 'Tulis nama lengkap', 'apeiron-kit' ),
						'type'        => 'text',
					],
					[
						'label'       => __( 'Jumlah Tamu', 'apeiron-kit' ),
						'name'        => 'jumlah',
						'placeholder' => __( 'Contoh: 2 orang', 'apeiron-kit' ),
						'type'        => 'number',
					],
					[
						'label'       => __( 'Ucapan', 'apeiron-kit' ),
						'name'        => 'ucapan',
						'placeholder' => __( 'Tulis doa atau pesan', 'apeiron-kit' ),
						'type'        => 'textarea',
					],
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => __( 'Teks Tombol', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Kirim via WhatsApp', 'apeiron-kit' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'message_template',
			[
				'label'       => __( 'Template Pesan', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => "Halo, saya [nama] akan hadir bersama [jumlah] orang. [konfirmasi]. Pesan: [ucapan]",
				'description' => __( 'Gunakan [nama_field] sesuai ID field di atas. Untuk opsi konfirmasi gunakan [konfirmasi].', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'show_confirmation',
			[
				'label'        => __( 'Tampilkan Konfirmasi Kehadiran', 'apeiron-kit' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Ya', 'apeiron-kit' ),
				'label_off'    => __( 'Tidak', 'apeiron-kit' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'separator'    => 'before',
			]
		);

		$this->add_control(
			'confirmation_label',
			[
				'label'       => __( 'Label Konfirmasi', 'apeiron-kit' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Konfirmasi Kehadiran', 'apeiron-kit' ),
				'condition'   => [
					'show_confirmation' => 'yes',
				],
			]
		);

		$option_repeater = new Repeater();
		$option_repeater->add_control(
			'option_text',
			[
				'label'   => __( 'Opsi', 'apeiron-kit' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			]
		);

		$this->add_control(
			'confirmation_options',
			[
				'label'       => __( 'Opsi Konfirmasi', 'apeiron-kit' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $option_repeater->get_controls(),
				'default'     => [
					[
						'option_text' => __( 'Ya saya akan datang', 'apeiron-kit' ),
					],
					[
						'option_text' => __( 'Saya masih ragu', 'apeiron-kit' ),
					],
					[
						'option_text' => __( 'Maaf saya tidak bisa datang', 'apeiron-kit' ),
					],
				],
				'title_field' => '{{{ option_text }}}',
				'condition'   => [
					'show_confirmation' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		// Style Section: Wrapper
		$this->start_controls_section(
			'section_style_container',
			[
				'label' => __( 'Wrapper', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'container_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form' => 'background-color: {{VALUE}}; background-image: none;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'container_border',
				'selector' => '{{WRAPPER}} .apeiron-signal-form',
			]
		);

		$this->add_responsive_control(
			'container_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'    => [
					'top'    => 6,
					'right'  => 6,
					'bottom' => 6,
					'left'   => 6,
					'unit'   => 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'container_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'container_shadow',
				'selector' => '{{WRAPPER}} .apeiron-signal-form',
			]
		);

		$this->end_controls_section();

		// Style Section: Label
		$this->start_controls_section(
			'section_style_labels',
			[
				'label' => __( 'Label', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typography',
				'selector' => '{{WRAPPER}} .apeiron-signal-form label span',
			]
		);

		$this->add_control(
			'label_color',
			[
				'label'     => __( 'Warna', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form label span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// Style Section: Input Fields
		$this->start_controls_section(
			'section_style_fields',
			[
				'label' => __( 'Kolom Input', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'tabs_fields_style' );

		$this->start_controls_tab(
			'tab_fields_normal',
			[
				'label' => __( 'Normal', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'input_text_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form textarea, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'fields_typography',
				'selector' => '{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form textarea, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)',
			]
		);

		$this->add_control(
			'input_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form textarea, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'fields_border',
				'selector' => '{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form textarea, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)',
			]
		);

		$this->add_responsive_control(
			'fields_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form textarea, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'input_text_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form input, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select)' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_fields_focus',
			[
				'label' => __( 'Focus', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'input_focus_text_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form input:focus, {{WRAPPER}} .apeiron-signal-form textarea:focus, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select):focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'input_focus_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form input:focus, {{WRAPPER}} .apeiron-signal-form textarea:focus, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select):focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'input_focus_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form input:focus, {{WRAPPER}} .apeiron-signal-form textarea:focus, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select):focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'input_focus_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-signal-form input:focus, {{WRAPPER}} .apeiron-signal-form textarea:focus, {{WRAPPER}} .apeiron-signal-form select:not(.apeiron-signal-form__select):focus',
				'fields_options' => [
					'box_shadow_type' => [
						'default' => 'no',
					],
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		// Spacing between fields
		$this->add_control(
			'fields_spacing_heading',
			[
				'label'     => __( 'Jarak Antar Field', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'fields_margin',
			[
				'label'      => __( 'Margin', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form__field' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		// Style Section: Textarea (Ucapan)
		$this->start_controls_section(
			'section_style_textarea',
			[
				'label' => __( 'Ucapan (Textarea)', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'textarea_typography',
				'selector' => '{{WRAPPER}} .apeiron-signal-form textarea',
			]
		);

		$this->add_control(
			'textarea_text_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form textarea' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'textarea_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'textarea_border',
				'selector' => '{{WRAPPER}} .apeiron-signal-form textarea',
			]
		);

		$this->add_responsive_control(
			'textarea_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'textarea_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'textarea_focus_heading',
			[
				'label'     => __( 'Focus State', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'textarea_focus_text_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form textarea:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'textarea_focus_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form textarea:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'textarea_focus_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'textarea_focus_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-signal-form textarea:focus',
				'fields_options' => [
					'box_shadow_type' => [
						'default' => 'no',
					],
				],
			]
		);

		$this->end_controls_section();

		// Style Section: Button
		$this->start_controls_section(
			'section_style_button',
			[
				'label' => __( 'Tombol', 'apeiron-kit' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_normal',
			[
				'label' => __( 'Normal', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'button_text_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__button',
			]
		);

		$this->add_control(
			'button_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#083c57',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__button' => 'background-color: {{VALUE}}; background-image: none;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__button',
			]
		);

		$this->add_responsive_control(
			'button_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form__button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form__button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_shadow',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__button',
				'fields_options' => [
					'box_shadow_type' => [
						'default' => 'no',
					],
					'box_shadow' => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 0,
							'spread'     => 0,
							'color'      => 'rgba(0,0,0,0)',
						],
					],
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[
				'label' => __( 'Hover', 'apeiron-kit' ),
			]
		);

		$this->add_control(
			'button_hover_color',
			[
				'label'     => __( 'Text Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__button:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_background_hover_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__button:hover' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		// Style Section: Confirmation Select
		$this->start_controls_section(
			'section_style_confirmation',
			[
				'label'     => __( 'Konfirmasi Kehadiran', 'apeiron-kit' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_confirmation' => 'yes',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'confirmation_typography',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__select',
			]
		);

		$this->add_control(
			'confirmation_color',
			[
				'label'     => __( 'Warna Teks', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__select' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'confirmation_background_color',
			[
				'label'     => __( 'Background Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__select' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'confirmation_border',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__select',
			]
		);

		$this->add_responsive_control(
			'confirmation_radius',
			[
				'label'      => __( 'Border Radius', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form__select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'confirmation_padding',
			[
				'label'      => __( 'Padding', 'apeiron-kit' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .apeiron-signal-form__select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'confirmation_focus_heading',
			[
				'label'     => __( 'Focus State', 'apeiron-kit' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'confirmation_focus_border_color',
			[
				'label'     => __( 'Border Color', 'apeiron-kit' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => [
					'{{WRAPPER}} .apeiron-signal-form__select:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'confirmation_focus_box_shadow',
				'selector' => '{{WRAPPER}} .apeiron-signal-form__select:focus',
				'fields_options' => [
					'box_shadow_type' => [
						'default' => 'no',
					],
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		parent::render(); // Layer 2: disabled gate + license gate
		if ( $this->is_widget_disabled() ) {
			return; // Widget disabled via dashboard toggle — output nothing
		}
		if ( ! $this->is_license_valid() ) {
			return; // License check failed, locked message already rendered
		}
		$settings = $this->get_settings_for_display();
		$fields   = $settings['fields'] ?? [];

		if ( empty( $fields ) ) {
			return;
		}

		$data = [
			'phone'    => preg_replace( '/\D/', '', $settings['phone_number'] ),
			'template' => $settings['message_template'],
		];


		?>
		<div class="apeiron-signal-form" data-apeiron-wa-form="<?php echo esc_attr( wp_json_encode( $data ) ); ?>">
			<?php if ( ! empty( $settings['form_title'] ) ) : ?>
				<h3 class="apeiron-signal-form__title"><?php echo esc_html( $settings['form_title'] ); ?></h3>
			<?php endif; ?>
			<form>
				<?php foreach ( $fields as $field ) : ?>
					<label class="apeiron-signal-form__field">
						<span><?php echo esc_html( $field['label'] ); ?></span>
						<?php echo $this->render_input( $field ); ?>
					</label>
				<?php endforeach; ?>
				
				<?php if ( ! empty( $settings['show_confirmation'] ) && $settings['show_confirmation'] === 'yes' ) : ?>
					<?php $this->render_confirmation_radio( $settings ); ?>
				<?php endif; ?>
				
				<button type="submit" class="apeiron-signal-form__button"><?php echo esc_html( $settings['button_text'] ); ?></button>
			</form>
		</div>
		<?php
	}

	private function render_input( array $field ): string {
		$name        = sanitize_key( $field['name'] );
		$placeholder = esc_attr( $field['placeholder'] );

		if ( $field['type'] === 'textarea' ) {
			return sprintf(
				'<textarea name="%1$s" placeholder="%2$s" required></textarea>',
				esc_attr( $name ),
				$placeholder
			);
		}

		$type = $field['type'] === 'number' ? 'number' : 'text';

		return sprintf(
			'<input type="%1$s" name="%2$s" placeholder="%3$s" required />',
			esc_attr( $type ),
			esc_attr( $name ),
			$placeholder
		);
	}

	private function render_confirmation_radio( array $settings ): void {
		$options      = $settings['confirmation_options'] ?? [];
		$label        = $settings['confirmation_label'] ?? __( 'Konfirmasi Kehadiran', 'apeiron-kit' );
		$field_name   = 'konfirmasi';
		$field_id     = 'apeiron-confirmation-' . $this->get_id();

		if ( empty( $options ) ) {
			return;
		}

		?>
		<label class="apeiron-signal-form__field apeiron-signal-form__confirmation">
			<span><?php echo esc_html( $label ); ?></span>
			<select name="<?php echo esc_attr( $field_name ); ?>" id="<?php echo esc_attr( $field_id ); ?>" class="apeiron-signal-form__select" required>
				<?php foreach ( $options as $index => $option ) : ?>
					<?php
					$option_text = $option['option_text'] ?? '';
					$is_selected = $index === 0; // First option selected by default
					?>
					<option value="<?php echo esc_attr( $option_text ); ?>" <?php echo $is_selected ? 'selected' : ''; ?>>
						<?php echo esc_html( $option_text ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>
		<?php
	}
}

