<?php

namespace ApeironKit\Core;

/**
 * API Key Manager
 * 
 * Handles encrypted API key storage and retrieval
 * API key is encrypted using WordPress options API with additional obfuscation
 */
class ApiKeyManager {

	private string $option_name = 'apeiron_kit_api_key_encrypted';
	private string $salt_option = 'apeiron_kit_api_salt';
	private string $cipher      = 'AES-256-CBC';

	/**
	 * Get encrypted API key
	 *
	 * @return string|null Decrypted API key or null
	 */
	public function get_api_key(): ?string {
		$encrypted = get_option( $this->option_name );

		if ( empty( $encrypted ) ) {
			return null;
		}

		$salt = $this->get_salt();
		$key = $this->derive_key( $salt );

		// Try AES (primary)
		$decrypted = $this->decrypt_aes( $encrypted, $key );
		if ( ! empty( $decrypted ) ) {
			return $decrypted;
		}

		// Fallback to legacy XOR storage
		$legacy = $this->xor_decrypt( $encrypted, $key );
		if ( strlen( $legacy ) < 8 ) {
			return null;
		}

		// Upgrade storage to AES transparently
		$this->set_api_key( $legacy );

		return $legacy;
	}

	/**
	 * Set and encrypt API key
	 *
	 * @param string $api_key API key to encrypt and store
	 * @return bool Success
	 */
	public function set_api_key( string $api_key ): bool {
		// Trim whitespace first, then sanitize
		$api_key = trim( $api_key );
		$api_key = sanitize_text_field( $api_key );

		// Trim again after sanitize to be safe
		$api_key = trim( $api_key );

		if ( empty( $api_key ) ) {
			return false;
		}

		// Generate salt if not exists
		$salt = $this->get_salt();
		if ( empty( $salt ) ) {
			$salt = $this->generate_salt();
			update_option( $this->salt_option, $salt, false );
		}

		$key = $this->derive_key( $salt );

		$encrypted = $this->encrypt_aes( $api_key, $key );

		if ( empty( $encrypted ) ) {
			return false;
		}

		// Store encrypted key
		return update_option( $this->option_name, $encrypted, false );
	}

	/**
	 * Delete API key
	 * 
	 * @return bool Success
	 */
	public function delete_api_key(): bool {
		delete_option( $this->salt_option );
		return delete_option( $this->option_name );
	}

	/**
	 * Check if API key is set
	 * 
	 * @return bool True if API key exists
	 */
	public function has_api_key(): bool {
		return ! empty( $this->get_api_key() );
	}

	/**
	 * Get or generate salt
	 * 
	 * @return string Salt
	 */
	private function get_salt(): string {
		$salt = get_option( $this->salt_option );
		
		if ( empty( $salt ) ) {
			$salt = $this->generate_salt();
			update_option( $this->salt_option, $salt, false );
		}
		
		return $salt;
	}

	/**
	 * Generate random salt
	 * 
	 * @return string Salt
	 */
	private function generate_salt(): string {
		// Use WordPress salt + additional randomness
		$wp_salt = defined( 'AUTH_SALT' ) ? AUTH_SALT : wp_generate_password( 32, true, true );
		$random = wp_generate_password( 16, true, true );
		
		return hash( 'sha256', $wp_salt . $random . get_option( 'siteurl' ) );
	}

	/**
	 * Derive encryption key from salt
	 * 
	 * @param string $salt Salt
	 * @return string Derived key
	 */
	private function derive_key( string $salt ): string {
		// Use multiple sources for key derivation
		$sources = [
			$salt,
			defined( 'AUTH_KEY' ) ? AUTH_KEY : '',
			get_option( 'siteurl' ),
			get_option( 'admin_email' ),
		];
		
		$combined = implode( '|', $sources );
		return hash( 'sha256', $combined, true ); // Binary output
	}

	private function encrypt_aes( string $data, string $key ): string {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}

		try {
			$iv = random_bytes( 16 );
		} catch ( \Exception $e ) {
			return '';
		}
		$encrypted = openssl_encrypt( $data, $this->cipher, $key, OPENSSL_RAW_DATA, $iv );

		if ( false === $encrypted ) {
			return '';
		}

		return base64_encode( $iv . $encrypted );
	}

	private function decrypt_aes( string $encrypted, string $key ): string {
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}

		$decoded = base64_decode( $encrypted, true );
		if ( false === $decoded || strlen( $decoded ) <= 16 ) {
			return '';
		}

		$iv        = substr( $decoded, 0, 16 );
		$payload   = substr( $decoded, 16 );
		$decrypted = openssl_decrypt( $payload, $this->cipher, $key, OPENSSL_RAW_DATA, $iv );

		return false === $decrypted ? '' : $decrypted;
	}

	/**
	 * Legacy XOR decrypt (kept for backward compatibility during migration)
	 */

	/**
	 * XOR decrypt
	 * 
	 * @param string $encrypted Encrypted data (base64 encoded)
	 * @param string $key Decryption key
	 * @return string Decrypted data
	 */
	private function xor_decrypt( string $encrypted, string $key ): string {
		$data = base64_decode( $encrypted, true );
		
		if ( $data === false ) {
			return '';
		}
		
		$key_length = strlen( $key );
		$decrypted = '';
		
		for ( $i = 0; $i < strlen( $data ); $i++ ) {
			$decrypted .= $data[ $i ] ^ $key[ $i % $key_length ];
		}
		
		return $decrypted;
	}
}

