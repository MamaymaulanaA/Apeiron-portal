<?php

namespace ApeironKit\Core;

/**
 * License Manager untuk handle remote license validation
 */
class LicenseManager {

	private static ?LicenseManager $instance = null;

	private string $option_name = 'apeiron_kit_license';
	private string $cache_option = 'apeiron_kit_license_cache';
	private string $api_url = ''; // Akan di-set via filter atau constant
	private string $product_id = 'apeiron-kit';
	private ApiKeyManager $api_key_manager;

	/**
	 * Default license server URL (hardcoded for security)
	 */
	private const DEFAULT_API_URL = 'https://server-apeiron.web.id/api';

	/**
	 * Get singleton instance.
	 *
	 * @return self
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Use hardcoded URL as default, allow override via constant for development
		$default_url = defined( 'APEIRON_KIT_LICENSE_API_URL' ) && ! empty( APEIRON_KIT_LICENSE_API_URL )
			? APEIRON_KIT_LICENSE_API_URL
			: self::DEFAULT_API_URL;
		$default_url = $this->sanitize_api_url( $default_url );

		$this->api_url = $this->sanitize_api_url( apply_filters( 'apeiron_kit_license_api_url', $default_url ) );
		
		$this->api_key_manager = new ApiKeyManager();
		
		// Auto-set API Key dari constant jika ada dan belum ada saved key
		if ( defined( 'APEIRON_KIT_LICENSE_API_KEY' ) && ! empty( APEIRON_KIT_LICENSE_API_KEY ) ) {
			if ( ! $this->api_key_manager->has_api_key() ) {
				// Auto-set API key dari constant
				$this->api_key_manager->set_api_key( APEIRON_KIT_LICENSE_API_KEY );
			}
		}
	}

	/**
	 * Register license management hooks
	 */
	public function register(): void {
		// Register filter to allow saved API URL to override default/constant
		add_filter( 'apeiron_kit_license_api_url', [ $this, 'filter_api_url_from_option' ], 10 );

		// Schedule periodic license check
		if ( ! wp_next_scheduled( 'apeiron_kit_check_license' ) ) {
			wp_schedule_event( time(), 'daily', 'apeiron_kit_check_license' );
		}
		add_action( 'apeiron_kit_check_license', [ $this, 'check_license_status' ] );

		// Register AJAX handlers
		add_action( 'wp_ajax_apeiron_activate_license', [ $this, 'handle_activate' ] );
		add_action( 'wp_ajax_apeiron_deactivate_license', [ $this, 'handle_deactivate' ] );
		add_action( 'wp_ajax_apeiron_check_license', [ $this, 'handle_check' ] );
		add_action( 'wp_ajax_apeiron_save_server_config', [ $this, 'handle_save_server_config' ] );
		add_action( 'wp_ajax_apeiron_test_server_connection', [ $this, 'handle_test_connection' ] );

		// Surface configuration/licensing issues in dashboard
		add_action( 'admin_notices', [ $this, 'render_admin_notices' ] );
	}

	/**
	 * Filter to get API URL from saved option if available
	 * This allows the saved URL to override the default/constant
	 *
	 * @param string $default_url Default URL from constant or hardcoded default
	 * @return string API URL to use
	 */
	public function filter_api_url_from_option( string $default_url ): string {
		// If constant is defined and not empty, use it (highest priority)
		if ( defined( 'APEIRON_KIT_LICENSE_API_URL' ) && ! empty( APEIRON_KIT_LICENSE_API_URL ) ) {
			return $default_url;
		}

		// Otherwise, try to get from saved option
		$saved_url = get_option( 'apeiron_kit_license_api_url', '' );
		if ( ! empty( $saved_url ) ) {
			return $this->sanitize_api_url( $saved_url );
		}

		return $default_url;
	}

	/**
	 * Helper: sanitized License Server URL (HTTPS only)
	 */
	private function sanitize_api_url( string $url ): string {
		$url = esc_url_raw( untrailingslashit( trim( $url ) ) );

		if ( empty( $url ) || ! wp_http_validate_url( $url ) ) {
			return '';
		}

		$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
		if ( 'https' !== $scheme ) {
			return '';
		}

		return $url;
	}

	public function get_api_url(): string {
		return $this->api_url;
	}

	public function has_api_key(): bool {
		return $this->api_key_manager->has_api_key();
	}

	public function has_server_config(): bool {
		return ! empty( $this->api_url ) && $this->api_key_manager->has_api_key();
	}

	/**
	 * Get license data
	 */
	public function get_license(): array {
		$default = [
			'key'           => '',
			'status'        => 'inactive',
			'expires'       => '',
			'activations'   => 0,
			'activation_limit' => 0,
			'site_url'      => '',
			'last_check'    => 0,
		];

		$license = get_option( $this->option_name, [] );
		$license = wp_parse_args( $license, $default );
		
		// Decrypt license key if encrypted
		if ( ! empty( $license['key'] ) && ! empty( $license['key_encrypted'] ) ) {
			$decrypted_key = $this->decrypt_license_key( $license['key'] );
			
			// If decryption failed (empty result), log error but keep original
			if ( empty( $decrypted_key ) && ! empty( $license['key'] ) ) {
				if ( class_exists( '\ApeironKit\Support\ErrorLogger' ) ) {
					\ApeironKit\Support\ErrorLogger::error( 'Failed to decrypt license key. Salt, AUTH_KEY, or siteurl may have changed.' );
				}
				// Keep encrypted key - user will need to re-activate
				// Don't set to empty to avoid losing the key completely
			} else {
				$license['key'] = $decrypted_key;
			}
		}
		
		return $license;
	}

	/**
	 * Save license data
	 */
	private function save_license( array $license ): void {
		// Encrypt license key before saving
		if ( ! empty( $license['key'] ) ) {
			$license['key'] = $this->encrypt_license_key( $license['key'] );
			$license['key_encrypted'] = true; // Flag to indicate encryption
		}
		
		update_option( $this->option_name, $license );
	}

	/**
	 * Check if license is active
	 */
	public function is_active(): bool {
		$license = $this->get_license();
		return 'active' === $license['status'];
	}

	/**
	 * Check if license is valid (active and not expired)
	 * Uses cache to improve performance
	 */
	public function is_valid(): bool {
		// Check cache first (1 hour cache)
		$cached = get_transient( 'apeiron_kit_license_valid' );
		if ( $cached !== false ) {
			return (bool) $cached;
		}

		// Perform actual validation
		if ( ! $this->is_active() ) {
			set_transient( 'apeiron_kit_license_valid', 0, HOUR_IN_SECONDS );
			return false;
		}

		$license = $this->get_license();
		
		// If no expiration date, consider it valid if active
		if ( empty( $license['expires'] ) ) {
			set_transient( 'apeiron_kit_license_valid', 1, HOUR_IN_SECONDS );
			return true;
		}

		// Check if expired
		$expires = strtotime( $license['expires'] );
		$is_valid = $expires > time() || $expires === false;
		
		// Cache result
		set_transient( 'apeiron_kit_license_valid', $is_valid ? 1 : 0, HOUR_IN_SECONDS );
		
		return $is_valid;
	}

	/**
	 * Activate license via remote API
	 */
	public function activate( string $license_key ): array {
		$license_key = sanitize_text_field( trim( $license_key ) );

		if ( empty( $license_key ) ) {
			return [
				'success' => false,
				'message' => __( 'License key tidak boleh kosong.', 'apeiron-kit' ),
			];
		}

		$response = $this->api_request( 'activate', [
			'license_key' => $license_key,
			'site_url'    => home_url(),
			'product_id'  => $this->product_id,
		] );

		if ( $response['success'] ) {
			$data = $response['data'];
			$this->save_license( [
				'key'             => $license_key,
				'status'          => $data['status'] ?? 'active',
				'expires'         => $data['expires'] ?? '',
				'activations'     => $data['activations'] ?? 0,
				'activation_limit' => $data['activation_limit'] ?? 0,
				'site_url'        => home_url(),
				'last_check'      => time(),
			] );
			
			// Clear cache when license is activated
			delete_transient( 'apeiron_kit_license_valid' );
		}

		return $response;
	}

	/**
	 * Deactivate license via remote API
	 */
	public function deactivate(): array {
		$license = $this->get_license();

		if ( empty( $license['key'] ) ) {
			return [
				'success' => false,
				'message' => __( 'Tidak ada license key yang terdaftar.', 'apeiron-kit' ),
			];
		}

		$response = $this->api_request( 'deactivate', [
			'license_key' => $license['key'],
			'site_url'    => home_url(),
			'product_id'  => $this->product_id,
		] );

		if ( $response['success'] ) {
			// Clear license data
			delete_option( $this->option_name );
			// Clear cache
			delete_transient( 'apeiron_kit_license_valid' );
		}

		return $response;
	}

	/**
	 * Check license status via remote API
	 */
	public function check_license_status(): array {
		$license = $this->get_license();

		if ( empty( $license['key'] ) ) {
			return [
				'success' => false,
				'message' => __( 'Tidak ada license key yang terdaftar.', 'apeiron-kit' ),
			];
		}

		$response = $this->api_request( 'check', [
			'license_key' => $license['key'],
			'site_url'    => home_url(),
			'product_id'  => $this->product_id,
		] );

		if ( $response['success'] ) {
			$data = $response['data'];
			$this->save_license( [
				'key'             => $license['key'],
				'status'          => $data['status'] ?? $license['status'],
				'expires'         => $data['expires'] ?? $license['expires'],
				'activations'     => $data['activations'] ?? $license['activations'],
				'activation_limit' => $data['activation_limit'] ?? $license['activation_limit'],
				'site_url'        => home_url(),
				'last_check'      => time(),
			] );
			
			// Clear cache when license status changes
			delete_transient( 'apeiron_kit_license_valid' );
		} else {
			// If check fails and license was active, mark as inactive
			if ( $this->is_active() ) {
				$license['status'] = 'inactive';
				$license['last_check'] = time();
				$this->save_license( $license );
				// Clear cache
				delete_transient( 'apeiron_kit_license_valid' );
			}
		}

		return $response;
	}

	/**
	 * Make API request to license server
	 */
	private function api_request( string $action, array $data ): array {
		// Ensure API URL valid & secure
		$this->api_url = $this->sanitize_api_url( $this->api_url );

		if ( empty( $this->api_url ) ) {
			return $this->get_cached_response( $action, [
				'success' => false,
				'message' => __( 'License server URL tidak dikonfigurasi.', 'apeiron-kit' ),
			] );
		}

		if ( 'https' !== wp_parse_url( $this->api_url, PHP_URL_SCHEME ) ) {
			return [
				'success' => false,
				'message' => __( 'License server harus menggunakan HTTPS untuk alasan keamanan.', 'apeiron-kit' ),
			];
		}

		// Get API key
		$api_key = $this->api_key_manager->get_api_key();
		if ( empty( $api_key ) ) {
			return $this->get_cached_response( $action, [
				'success' => false,
				'message' => __( 'API Key tidak dikonfigurasi. Silakan set API Key di settings.', 'apeiron-kit' ),
			] );
		}

		$url = trailingslashit( $this->api_url ) . $action . '.php';

		// Validate URL before making request
		if ( ! wp_http_validate_url( $url ) ) {
			return [
				'success' => false,
				'message' => __( 'License server URL tidak valid.', 'apeiron-kit' ),
			];
		}

		$args = [
			'timeout' => 15,
			'body'    => json_encode( $data ),
			'headers' => [
				'Content-Type'  => 'application/json',
				'X-API-Key'    => $api_key,
				'User-Agent'   => 'ApeironKit/' . APEIRON_KIT_VERSION . '; ' . home_url(),
			],
			'sslverify' => true, // Verify SSL certificate
		];

		// Debug logging (guarded — strips sensitive data)
		if ( class_exists( '\ApeironKit\Support\ErrorLogger' ) ) {
			\ApeironKit\Support\ErrorLogger::info( 'License API request', [
				'url'       => $url,
				'action'    => $action,
			] );
		}

		$response = wp_remote_post( $url, $args );

		// Handle connection errors - use cache if available
		if ( is_wp_error( $response ) ) {
			$error_message = $response->get_error_message();
			$error_code = $response->get_error_code();
			
			// Log connection error
			if ( class_exists( '\ApeironKit\Support\ErrorLogger' ) ) {
				\ApeironKit\Support\ErrorLogger::error( 
					'License server connection error',
					[
						'url' => $url,
						'action' => $action,
						'error_code' => $error_code,
						'error_message' => $error_message,
					]
				);
			}
			
			// Try cache on connection error (only for check action)
			if ( $action === 'check' ) {
				$cached = $this->get_cached_response( $action );
				if ( $cached !== null ) {
					return [
						'success' => true,
						'data'    => $cached,
						'message' => __( 'License status dari cache (server tidak dapat dihubungi).', 'apeiron-kit' ),
						'cached'  => true,
					];
				}
			}
			
			// Build detailed error message
			$user_message = sprintf( __( 'Error koneksi ke license server: %s', 'apeiron-kit' ), $error_message );
			
			// Add troubleshooting tips based on error code
			if ( strpos( $error_code, 'ssl' ) !== false || strpos( $error_message, 'SSL' ) !== false ) {
				$user_message .= ' ' . __( 'Kemungkinan masalah SSL certificate. Pastikan server menggunakan HTTPS yang valid.', 'apeiron-kit' );
			} elseif ( strpos( $error_code, 'timeout' ) !== false || strpos( $error_message, 'timeout' ) !== false ) {
				$user_message .= ' ' . __( 'Server tidak merespons. Cek koneksi internet atau status server license.', 'apeiron-kit' );
			} elseif ( strpos( $error_code, 'resolve' ) !== false || strpos( $error_message, 'resolve' ) !== false ) {
				$user_message .= ' ' . __( 'Tidak dapat menemukan server. Pastikan License Server URL benar.', 'apeiron-kit' );
			}
			
			return [
				'success' => false,
				'message' => $user_message,
				'error_code' => $error_code,
			];
		}

		$body = wp_remote_retrieve_body( $response );
		$code = wp_remote_retrieve_response_code( $response );

		if ( $code !== 200 ) {
			// Log error for debugging
			$error_details = [
				'code' => $code,
				'body' => $body,
				'url' => $url,
				'action' => $action,
			];
			
			// Try to parse error message from response body
			$error_message = '';
			$error_code = '';
			if ( ! empty( $body ) ) {
				$error_data = json_decode( $body, true );
				if ( is_array( $error_data ) && isset( $error_data['message'] ) ) {
					$error_message = $error_data['message'];
				}
				if ( is_array( $error_data ) && isset( $error_data['error_code'] ) ) {
					$error_code = $error_data['error_code'];
				}
			}
			
			// Log error with context
			if ( class_exists( '\ApeironKit\Support\ErrorLogger' ) ) {
				\ApeironKit\Support\ErrorLogger::error( 
					'License server returned error',
					$error_details
				);
			}
			
			// Try cache on server error (only for check action, not activate/deactivate)
			if ( $action === 'check' ) {
				$cached = $this->get_cached_response( $action );
				if ( $cached !== null ) {
					return [
						'success' => true,
						'data'    => $cached,
						'message' => __( 'License status dari cache (server error).', 'apeiron-kit' ),
						'cached'  => true,
					];
				}
			}
			
			// Build user-friendly error message
			$user_message = sprintf( __( 'License server mengembalikan error: %d', 'apeiron-kit' ), $code );
			
			// Add error message from server if available
			if ( ! empty( $error_message ) ) {
				$user_message .= '. ' . esc_html( $error_message );
			}
			
			// Add helpful troubleshooting tips for 500 error
			if ( $code === 500 ) {
				$user_message .= ' ' . __( 'Kemungkinan masalah: (1) Server license sedang maintenance, (2) Database error, (3) Konfigurasi server tidak benar. Silakan cek log server atau hubungi administrator.', 'apeiron-kit' );
			}
			
			return [
				'success' => false,
				'message' => $user_message,
				'error_code' => $error_code ?: 'HTTP_' . $code,
				'debug' => defined( 'WP_DEBUG' ) && WP_DEBUG ? $error_details : null,
			];
		}

		$response_data = json_decode( $body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return [
				'success' => false,
				'message' => __( 'Invalid response dari license server.', 'apeiron-kit' ),
			];
		}

		// Expected response format:
		// { "success": true, "data": { "status": "active", "expires": "2024-12-31", ... } }
		// or
		// { "success": false, "message": "Error message" }

		if ( isset( $response_data['success'] ) && $response_data['success'] ) {
			// Cache successful response
			$this->cache_response( $action, $response_data['data'] ?? [] );
			
			return [
				'success' => true,
				'data'    => $response_data['data'] ?? [],
				'message' => $response_data['message'] ?? __( 'License berhasil divalidasi.', 'apeiron-kit' ),
			];
		}

		// Handle specific error codes
		$error_code = $response_data['error_code'] ?? '';
		$error_message = $response_data['message'] ?? __( 'License validation gagal.', 'apeiron-kit' );

		// Customize error message for specific error codes
		if ( $error_code === 'INVALID_API_KEY' || strpos( $error_message, 'API key' ) !== false ) {
			$error_message = __( 'API Key tidak valid. Silakan cek kembali API Key yang Anda masukkan atau hubungi administrator.', 'apeiron-kit' );
		} elseif ( $error_code === 'SINGLE_DOMAIN_VIOLATION' ) {
			$existing_domain = $response_data['existing_domain'] ?? '';
			$error_message = sprintf(
				__( 'License ini hanya dapat diaktifkan di satu domain. Domain yang sudah terdaftar: %s', 'apeiron-kit' ),
				$existing_domain
			);
		} elseif ( $error_code === 'MAX_DOMAINS_REACHED' ) {
			$error_message = __( 'Batas maksimal domain telah tercapai untuk license ini.', 'apeiron-kit' );
		} elseif ( $error_code === 'DOMAIN_NOT_ALLOWED' ) {
			$error_message = __( 'Domain tidak diizinkan untuk license ini. Silakan hubungi administrator.', 'apeiron-kit' );
		} elseif ( $error_code === 'ORIGIN_MISMATCH' ) {
			$error_message = __( 'Request origin tidak sesuai dengan site URL. Pastikan request dikirim dari domain yang benar.', 'apeiron-kit' );
		} elseif ( $error_code === 'ACTIVATION_LIMIT_REACHED' ) {
			$error_message = __( 'Batas aktivasi untuk license ini telah tercapai. Silakan hubungi administrator untuk reset.', 'apeiron-kit' );
		} elseif ( $error_code === 'LICENSE_INACTIVE' ) {
			$error_message = __( 'License telah dinonaktifkan. Silakan hubungi administrator untuk mengaktifkan kembali.', 'apeiron-kit' );
		} elseif ( $error_code === 'LICENSE_SUSPENDED' ) {
			$error_message = __( 'License telah di-suspend. Silakan hubungi administrator.', 'apeiron-kit' );
		} elseif ( $error_code === 'LICENSE_EXPIRED' ) {
			$error_message = __( 'License telah kedaluwarsa. Silakan hubungi administrator untuk memperpanjang.', 'apeiron-kit' );
		}

		return [
			'success' => false,
			'message' => $error_message,
			'error_code' => $error_code,
		];
	}

	/**
	 * Cache API response for offline use
	 * 
	 * @param string $action Action name
	 * @param array $data Response data
	 * @return void
	 */
	private function cache_response( string $action, array $data ): void {
		$cache = get_option( $this->cache_option, [] );
		$cache[ $action ] = [
			'data'      => $data,
			'timestamp' => time(),
		];
		update_option( $this->cache_option, $cache, false );
	}

	/**
	 * Get cached API response
	 * 
	 * @param string $action Action name
	 * @param array|null $fallback Fallback response if cache expired
	 * @return array|null Cached data or null
	 */
	private function get_cached_response( string $action, ?array $fallback = null ): ?array {
		$cache = get_option( $this->cache_option, [] );
		
		if ( ! isset( $cache[ $action ] ) ) {
			return $fallback;
		}
		
		$cached = $cache[ $action ];
		$age = time() - ( $cached['timestamp'] ?? 0 );
		
		// Cache valid for 24 hours
		if ( $age > 86400 ) {
			return $fallback;
		}
		
		return $cached['data'] ?? $fallback;
	}

	/**
	 * Encrypt license key before storage using AES-256-CBC
	 * 
	 * SECURITY: Upgraded from XOR to AES-256-CBC for better security
	 * 
	 * @param string $key License key to encrypt
	 * @return string Encrypted license key (base64 encoded with IV)
	 */
	private function encrypt_license_key( string $key ): string {
		$salt = get_option( 'apeiron_kit_license_salt' );
		if ( empty( $salt ) ) {
			$salt = wp_generate_password( 32, true, true );
			update_option( 'apeiron_kit_license_salt', $salt, false );
		}
		
		$wp_key = defined( 'AUTH_KEY' ) ? AUTH_KEY : wp_generate_password( 32, true, true );
		$site_url = get_option( 'siteurl' );
		
		// Derive encryption key using PBKDF2 (more secure than simple hash)
		$encryption_key = hash_pbkdf2( 'sha256', $salt . $wp_key . $site_url, 'apeiron_kit_salt', 10000, 32, true );
		
		// Generate random IV for each encryption
		$iv = openssl_random_pseudo_bytes( 16 );
		if ( $iv === false ) {
			// Fallback if openssl not available (shouldn't happen in modern PHP)
			$iv = random_bytes( 16 );
		}
		
		// Encrypt using AES-256-CBC
		$encrypted = openssl_encrypt( $key, 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, $iv );
		if ( $encrypted === false ) {
			if ( class_exists( '\ApeironKit\Support\ErrorLogger' ) ) {
				\ApeironKit\Support\ErrorLogger::error( 'License key encryption failed. Check OpenSSL extension.' );
			}
			return ''; // Return empty on failure
		}
		
		// Combine IV + encrypted data and encode
		$combined = $iv . $encrypted;
		return base64_encode( $combined );
	}

	/**
	 * Decrypt license key from storage using AES-256-CBC
	 * 
	 * SECURITY: Upgraded from XOR to AES-256-CBC decryption
	 * 
	 * @param string $encrypted Encrypted license key (base64 encoded with IV)
	 * @return string Decrypted license key
	 */
	private function decrypt_license_key( string $encrypted ): string {
		$salt = get_option( 'apeiron_kit_license_salt' );
		$wp_key = defined( 'AUTH_KEY' ) ? AUTH_KEY : wp_generate_password( 32, true, true );
		$site_url = get_option( 'siteurl' );
		
		// Derive encryption key using PBKDF2 (must match encryption method)
		$encryption_key = hash_pbkdf2( 'sha256', $salt . $wp_key . $site_url, 'apeiron_kit_salt', 10000, 32, true );
		
		// Decode base64
		$combined = base64_decode( $encrypted, true );
		if ( $combined === false || strlen( $combined ) < 16 ) {
			// Try old XOR format for backward compatibility
			return $this->decrypt_license_key_xor( $encrypted );
		}
		
		// Extract IV (first 16 bytes) and encrypted data
		$iv = substr( $combined, 0, 16 );
		$encrypted_data = substr( $combined, 16 );
		
		// Decrypt using AES-256-CBC
		$decrypted = openssl_decrypt( $encrypted_data, 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, $iv );
		if ( $decrypted === false ) {
			// Try old XOR format for backward compatibility
			return $this->decrypt_license_key_xor( $encrypted );
		}
		
		return $decrypted;
	}
	
	/**
	 * Legacy XOR decryption for backward compatibility
	 * 
	 * @param string $encrypted Encrypted license key
	 * @return string Decrypted license key
	 */
	private function decrypt_license_key_xor( string $encrypted ): string {
		$salt = get_option( 'apeiron_kit_license_salt' );
		$wp_key = defined( 'AUTH_KEY' ) ? AUTH_KEY : wp_generate_password( 32, true, true );
		$site_url = get_option( 'siteurl' );
		
		$encryption_key = hash( 'sha256', $salt . $wp_key . $site_url, true );
		
		$data = base64_decode( $encrypted, true );
		if ( $data === false ) {
			return '';
		}
		
		$decrypted = '';
		$key_length = strlen( $encryption_key );
		for ( $i = 0; $i < strlen( $data ); $i++ ) {
			$decrypted .= $data[ $i ] ^ $encryption_key[ $i % $key_length ];
		}
		
		return $decrypted;
	}

	/**
	 * Handle AJAX activate license
	 */
	public function handle_activate(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'apeiron_license_management' ) ) {
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'apeiron-kit' ) ] );
			return;
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Anda tidak memiliki izin untuk melakukan aksi ini.', 'apeiron-kit' ) ] );
			return;
		}

		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( $_POST['license_key'] ) : '';

		$result = $this->activate( $license_key );

		if ( $result['success'] ) {
			wp_send_json_success( [
				'message' => $result['message'],
				'license' => $this->get_license(),
			] );
		} else {
			wp_send_json_error( [ 'message' => $result['message'] ] );
		}
	}

	/**
	 * Handle AJAX deactivate license
	 */
	public function handle_deactivate(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'apeiron_license_management' ) ) {
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'apeiron-kit' ) ] );
			return;
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Anda tidak memiliki izin untuk melakukan aksi ini.', 'apeiron-kit' ) ] );
			return;
		}

		$result = $this->deactivate();

		if ( $result['success'] ) {
			wp_send_json_success( [ 'message' => $result['message'] ] );
		} else {
			wp_send_json_error( [ 'message' => $result['message'] ] );
		}
	}

	/**
	 * Handle AJAX check license
	 */
	public function handle_check(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'apeiron_license_management' ) ) {
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'apeiron-kit' ) ] );
			return;
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Anda tidak memiliki izin untuk melakukan aksi ini.', 'apeiron-kit' ) ] );
			return;
		}

		$result = $this->check_license_status();

		if ( $result['success'] ) {
			wp_send_json_success( [
				'message' => $result['message'],
				'license' => $this->get_license(),
			] );
		} else {
			wp_send_json_error( [ 'message' => $result['message'] ] );
		}
	}

	/**
	 * Handle AJAX save server configuration
	 */
	public function handle_save_server_config(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'apeiron_license_management' ) ) {
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'apeiron-kit' ) ] );
			return;
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Anda tidak memiliki izin untuk melakukan aksi ini.', 'apeiron-kit' ) ] );
			return;
		}

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( trim( wp_unslash( $_POST['api_key'] ) ) ) : '';

		// Determine API URL: constant > POST > saved option > default
		if ( defined( 'APEIRON_KIT_LICENSE_API_URL' ) && ! empty( APEIRON_KIT_LICENSE_API_URL ) ) {
			$api_url = APEIRON_KIT_LICENSE_API_URL;
		} else {
			$api_url = isset( $_POST['api_url'] ) ? (string) wp_unslash( $_POST['api_url'] ) : '';
			if ( empty( $api_url ) ) {
				$api_url = get_option( 'apeiron_kit_license_api_url', self::DEFAULT_API_URL );
			}
		}

		$api_url = $this->sanitize_api_url( $api_url );

		if ( empty( $api_url ) ) {
			wp_send_json_error( [ 'message' => __( 'License Server URL tidak valid atau tidak menggunakan HTTPS.', 'apeiron-kit' ) ] );
			return;
		}

		// Save API URL to option (can be filtered later)
		update_option( 'apeiron_kit_license_api_url', $api_url, false );

		// Update API URL in instance
		$this->api_url = $api_url;

		// Save API Key if provided
		if ( ! empty( $api_key ) ) {
			if ( ! $this->api_key_manager->set_api_key( $api_key ) ) {
				wp_send_json_error( [ 'message' => __( 'Gagal menyimpan API Key.', 'apeiron-kit' ) ] );
				return;
			}
		}

		wp_send_json_success( [
			'message' => __( 'Konfigurasi server berhasil disimpan!', 'apeiron-kit' ),
		] );
	}

	/**
	 * Handle AJAX test server connection
	 */
	public function handle_test_connection(): void {
		// Verify nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'apeiron_license_management' ) ) {
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'apeiron-kit' ) ] );
			return;
		}

		// Check user capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Anda tidak memiliki izin untuk melakukan aksi ini.', 'apeiron-kit' ) ] );
			return;
		}

		// Get current API URL (refresh from source)
		$api_url = $this->get_api_url();

		// Get API key
		$api_key = $this->api_key_manager->get_api_key();

		// Check server configuration
		if ( empty( $api_url ) ) {
			wp_send_json_error( [
				'message' => __( 'License Server URL belum dikonfigurasi.', 'apeiron-kit' ),
				'error_code' => 'NO_API_URL'
			] );
			return;
		}

		if ( empty( $api_key ) ) {
			wp_send_json_error( [
				'message' => __( 'API Key belum dikonfigurasi.', 'apeiron-kit' ),
				'error_code' => 'NO_API_KEY'
			] );
			return;
		}

		// Test connection using health.php endpoint (no auth required for basic check)
		$url = trailingslashit( $api_url ) . 'health.php';

		$args = [
			'timeout' => 15,
			'headers' => [
				'Content-Type' => 'application/json',
				'User-Agent'   => 'ApeironKit/' . APEIRON_KIT_VERSION . '; ' . home_url(),
			],
			'sslverify' => true,
		];

		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			$error_message = $response->get_error_message();
			$error_code = $response->get_error_code();
			
			wp_send_json_error( [
				'message'    => sprintf( __( 'Koneksi gagal: %s', 'apeiron-kit' ), $error_message ),
				'error_code' => $error_code,
			] );
			return;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( $code >= 200 && $code < 300 ) {
			wp_send_json_success( [
				'message' => __( 'Koneksi ke license server berhasil!', 'apeiron-kit' ),
			] );
		} else {
			$error_message = __( 'Koneksi gagal.', 'apeiron-kit' );
			$error_code = 'HTTP_' . $code;
			
			// Try to get error message from response body
			$response_data = json_decode( $body, true );
			if ( is_array( $response_data ) && isset( $response_data['message'] ) ) {
				$error_message = $response_data['message'];
			}
			if ( is_array( $response_data ) && isset( $response_data['error_code'] ) ) {
				$error_code = $response_data['error_code'];
			}
			
			wp_send_json_error( [
				'message'    => $error_message,
				'error_code' => $error_code,
			] );
		}
	}

	/**
	 * Get license status for display
	 */
	public function get_status_display(): array {
		$license = $this->get_license();
		$status = $license['status'];
		$is_valid = $this->is_valid();

		$status_info = [
			'active'   => [
				'label' => __( 'Aktif', 'apeiron-kit' ),
				'color' => '#46b450',
				'icon'  => 'yes-alt',
			],
			'inactive' => [
				'label' => __( 'Tidak Aktif', 'apeiron-kit' ),
				'color' => '#dc3232',
				'icon'  => 'dismiss',
			],
			'expired'  => [
				'label' => __( 'Kedaluwarsa', 'apeiron-kit' ),
				'color' => '#f0b849',
				'icon'  => 'warning',
			],
		];

		if ( ! $is_valid && ! empty( $license['expires'] ) ) {
			$expires = strtotime( $license['expires'] );
			if ( $expires && $expires < time() ) {
				$status = 'expired';
			}
		}

		return [
			'status'      => $status,
			'is_valid'    => $is_valid,
			'info'        => $status_info[ $status ] ?? $status_info['inactive'],
			'expires'     => $license['expires'],
			'activations' => $license['activations'],
			'limit'       => $license['activation_limit'],
			'last_check'  => $license['last_check'],
		];
	}

	/**
	 * Show admin notices for missing configuration or invalid license
	 */
	public function render_admin_notices(): void {
		if ( ! is_admin() || wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$is_license_screen = $screen && 'toplevel_page_apeiron-kit' === $screen->id;

		if ( ! $this->has_server_config() ) {
			$link = sprintf(
				'<a href="%s">%s</a>',
				esc_url( admin_url( 'admin.php?page=apeiron-kit&tab=license' ) ),
				esc_html__( 'Konfigurasi sekarang', 'apeiron-kit' )
			);

			printf(
				'<div class="notice notice-warning"><p><strong>%s</strong> %s %s</p></div>',
				esc_html__( 'Apeiron Kit:', 'apeiron-kit' ),
				esc_html__( 'License Server URL atau API Key belum dikonfigurasi.', 'apeiron-kit' ),
				$is_license_screen ? '' : $link
			);

			return;
		}

		$status = $this->get_status_display();
		if ( $status['is_valid'] ) {
			return;
		}

		$last_check = '';
		if ( ! empty( $status['last_check'] ) ) {
			$last_check = sprintf(
				/* translators: %s: datetime */
				__( 'Terakhir diperiksa: %s', 'apeiron-kit' ),
				esc_html(
					date_i18n(
						get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
						$status['last_check']
					)
				)
			);
		}

		printf(
			'<div class="notice notice-error"><p><strong>%s</strong> %s. %s</p></div>',
			esc_html__( 'Apeiron Kit:', 'apeiron-kit' ),
			esc_html__( 'Lisensi tidak aktif atau kedaluwarsa', 'apeiron-kit' ),
			$last_check
		);
	}
}

