<?php

namespace ApeironKit\Core;

class Requirements {

	private string $min_php        = '7.4';
	private string $min_wp         = '6.0';
	private string $min_elementor  = '3.7.0';

	private array $requirements = [];

	public function __construct() {
		$this->requirements = [
			[
				'check'  => 'elementor_loaded',
				'passed' => $this->check_elementor(),
				'message' => __( 'Apeiron Kit membutuhkan Elementor aktif.', 'apeiron-kit' ),
			],
			[
				'check'   => 'elementor_version',
				'passed'  => $this->check_elementor_version(),
				'message' => sprintf(
					/* translators: %s: required Elementor version */
					__( 'Apeiron Kit membutuhkan Elementor versi %s atau lebih baru.', 'apeiron-kit' ),
					$this->min_elementor
				),
			],
			[
				'check'  => 'php_version',
				'passed' => version_compare( PHP_VERSION, $this->min_php, '>=' ),
				'message' => sprintf(
					/* translators: %s: required PHP version */
					__( 'Apeiron Kit membutuhkan PHP %s atau lebih baru.', 'apeiron-kit' ),
					$this->min_php
				),
			],
			[
				'check'  => 'wp_version',
				'passed' => $this->check_wp_version(),
				'message' => sprintf(
					/* translators: %s: required WordPress version */
					__( 'Apeiron Kit membutuhkan WordPress %s atau lebih baru.', 'apeiron-kit' ),
					$this->min_wp
				),
			],
		];
	}

	/**
	 * Check if Elementor is loaded and available
	 * More robust check that handles different loading scenarios
	 */
	private function check_elementor(): bool {
		// Check if Elementor class exists (most reliable)
		if ( class_exists( '\Elementor\Plugin' ) ) {
			return true;
		}

		// Fallback: check if action was fired
		if ( did_action( 'elementor/loaded' ) ) {
			return true;
		}

		// Additional check: see if Elementor plugin is active
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( 'elementor/elementor.php' );
	}

	private function check_elementor_version(): bool {
		if ( ! $this->check_elementor() ) {
			return false;
		}

		if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
			return false;
		}

		return version_compare( ELEMENTOR_VERSION, $this->min_elementor, '>=' );
	}

	private function check_wp_version(): bool {
		global $wp_version;

		if ( empty( $wp_version ) ) {
			return false;
		}

		return version_compare( $wp_version, $this->min_wp, '>=' );
	}

	public function passes(): bool {
		foreach ( $this->requirements as $requirement ) {
			if ( ! $requirement['passed'] ) {
				return false;
			}
		}

		return true;
	}

	public function register_notice(): void {
		add_action(
			'admin_notices',
			function () {
				$messages = array_filter(
					$this->requirements,
					static function ( $requirement ) {
						return ! $requirement['passed'];
					}
				);

				if ( empty( $messages ) ) {
					return;
				}

				echo '<div class="notice notice-error"><p>';
				foreach ( $messages as $message ) {
					echo esc_html( $message['message'] ) . '<br>';
				}
				echo '</p></div>';
			}
		);
	}
}

