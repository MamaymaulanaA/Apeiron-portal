<?php

namespace ApeironKit\Core;

class Activator {

	public static function activate(): void {
		self::seed_options();
	}

	private static function seed_options(): void {
		if ( ! get_option( 'apeiron_kit_settings' ) ) {
			add_option(
				'apeiron_kit_settings',
				[
					'comment_moderation' => 'auto',
				]
			);
		}

		if ( false === get_option( 'apeiron_kit_license_api_url', false ) ) {
			add_option( 'apeiron_kit_license_api_url', '', false );
		}
	}
}

