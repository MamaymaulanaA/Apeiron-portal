<?php

namespace ApeironKit\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ApeironKit\Admin\SettingsPage;
use ApeironKit\Elementor\WidgetManager;
use ApeironKit\Rest\CommentsController;
use ApeironKit\Support\AssetManager;
use ApeironKit\Support\StickerManager;

class Plugin {

	private Requirements $requirements;
	private AssetManager $assets;
	private SettingsPage $settings;
	private WidgetManager $widgets;
	private CommentsController $comments;
	private StickerManager $sticker_manager;
	private LicenseManager $license_manager;

	public function __construct() {
		$this->requirements   = new Requirements();
		$this->assets         = new AssetManager();
		$this->settings       = new SettingsPage();
		$this->widgets        = new WidgetManager();
		$this->comments       = new CommentsController();
		$this->sticker_manager = new StickerManager();
		$this->license_manager = LicenseManager::instance();
	}

	public function boot(): void {
		if ( ! $this->requirements->passes() ) {
			$this->requirements->register_notice();
			return;
		}

		add_action( 'init', [ $this, 'init' ] );
		add_action( 'rest_api_init', [ $this->comments, 'register_routes' ] );
	}

	public function init(): void {
		$this->assets->register();
		$this->settings->register();
		$this->license_manager->register();
		$this->widgets->register();
		$this->sticker_manager->register();
	}
}

