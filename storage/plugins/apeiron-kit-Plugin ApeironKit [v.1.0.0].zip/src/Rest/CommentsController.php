<?php

namespace ApeironKit\Rest;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;
use ApeironKit\Support\ErrorLogger;

class CommentsController {

	/**
	 * REST API namespace.
	 */
	private string $namespace = 'apeiron-kit/v1';

	/**
	 * Rate limiting constants.
	 */
	private const RATE_LIMIT_POST_MAX = 5;
	private const RATE_LIMIT_GET_MAX = 30;
	private const RATE_LIMIT_WINDOW = MINUTE_IN_SECONDS;

	/**
	 * Pagination constants.
	 */
	private const DEFAULT_PER_PAGE = 50;
	private const MAX_PER_PAGE = 200;

	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/comments',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'fetch_comments' ],
					'permission_callback' => '__return_true',
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'store_comment' ],
					'permission_callback' => [ $this, 'verify_nonce' ],
				],
			]
		);
	}

	public function fetch_comments( WP_REST_Request $request ): WP_REST_Response {
		// Block requests when Comment Dock widget is disabled
		if ( $this->is_comment_dock_disabled() ) {
			return new WP_REST_Response(
				[ 'code' => 'widget_disabled', 'message' => __( 'Widget tidak aktif.', 'apeiron-kit' ) ],
				403
			);
		}

		// Rate limiting for GET requests to prevent scraping
		$rate_error = $this->check_rate_limit( 'get' );
		if ( is_wp_error( $rate_error ) ) {
			return new WP_REST_Response(
				[ 'code' => 'rate_limit', 'message' => $rate_error->get_error_message() ],
				429
			);
		}

		$post_id    = (int) $request->get_param( 'post_id' );
		$element_id = sanitize_text_field( (string) $request->get_param( 'element_id' ) );
		$per_page   = min( absint( $request->get_param( 'per_page' ) ) ?: self::DEFAULT_PER_PAGE, self::MAX_PER_PAGE );
		$page       = max( 1, absint( $request->get_param( 'page' ) ) );
		$offset     = ( $page - 1 ) * $per_page;

		if ( ! $post_id || empty( $element_id ) ) {
			return new WP_REST_Response( [ 'items' => [], 'total' => 0, 'page' => 1, 'per_page' => $per_page ] );
		}

		// Get total count first for pagination headers
		$count_args = [
			'post_id'    => $post_id,
			'status'     => 'approve',
			'count'      => true,
			'meta_query' => [
				[
					'key'   => 'apeiron_element_id',
					'value' => $element_id,
				],
			],
		];
		$total = (int) get_comments( $count_args );

		// Fetch paginated comments
		$comments = get_comments(
			[
				'post_id'    => $post_id,
				'status'     => 'approve',
				'number'     => $per_page,
				'offset'     => $offset,
				'meta_query' => [
					[
						'key'   => 'apeiron_element_id',
						'value' => $element_id,
					],
				],
			]
		);

		$controller = $this;
		$items      = array_map(
			static function ( $comment ) use ( $controller ) {
				return [
					'id'               => (int) $comment->comment_ID,
					'name'             => esc_html( $comment->comment_author ),
					'message'          => wp_kses_post( wpautop( $comment->comment_content ) ),
					'createdAt'        => (int) get_comment_date( 'U', $comment ), // Send timestamp instead of formatted date
					'attendanceLabel'  => esc_html( (string) get_comment_meta( $comment->comment_ID, 'apeiron_attendance_label', true ) ),
					'attendanceValue'  => esc_html( (string) get_comment_meta( $comment->comment_ID, 'apeiron_attendance_value', true ) ),
					'avatar'           => esc_url( get_avatar_url( $comment->comment_author_email, [ 'size' => 40 ] ) ),
					'sticker'          => $controller->prepare_sticker_payload( (int) $comment->comment_ID ),
				];
			},
			$comments
		);

		return new WP_REST_Response( [
			'items'    => $items,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
			'pages'    => (int) ceil( $total / $per_page ),
		] );
	}

	public function store_comment( WP_REST_Request $request ) {
		// Block submissions when Comment Dock widget is disabled
		if ( $this->is_comment_dock_disabled() ) {
			return new WP_Error(
				'widget_disabled',
				__( 'Widget tidak aktif.', 'apeiron-kit' ),
				[ 'status' => 403 ]
			);
		}

		// Rate limiting check for POST requests
		$rate_limit_error = $this->check_rate_limit( 'post' );
		if ( is_wp_error( $rate_limit_error ) ) {
			return $rate_limit_error;
		}

		$post_id    = (int) $request->get_param( 'post_id' );
		$element_id = sanitize_text_field( (string) $request->get_param( 'element_id' ) );
		$name       = sanitize_text_field( (string) $request->get_param( 'name' ) );
		$email      = sanitize_email( (string) $request->get_param( 'email' ) );
		$message    = trim( wp_kses_post( (string) $request->get_param( 'message' ) ) );
		$attendance_value = sanitize_key( (string) $request->get_param( 'attendance' ) );
		$attendance_label = sanitize_text_field( (string) $request->get_param( 'attendance_label' ) );
		$sticker_src      = $this->sanitize_sticker_src( (string) $request->get_param( 'sticker_src' ) );
		$sticker_type     = sanitize_key( (string) $request->get_param( 'sticker_type' ) );
		if ( ! in_array( $sticker_type, [ 'image', 'video' ], true ) ) {
			$sticker_type = '';
		}

		if ( ! $post_id || empty( $element_id ) ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Permintaan tidak valid.', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		// Input length validation
		if ( strlen( $name ) > 100 ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Nama terlalu panjang (maksimal 100 karakter).', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		if ( strlen( $email ) > 254 ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Email terlalu panjang.', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		if ( strlen( $message ) > 5000 ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Pesan terlalu panjang (maksimal 5000 karakter).', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		if ( empty( $name ) || empty( $message ) ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Nama dan pesan wajib diisi.', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		// Enhanced email validation
		if ( ! empty( $email ) && ( ! is_email( $email ) || strlen( $email ) > 254 ) ) {
			return new WP_Error( 'apeiron_kit_invalid', __( 'Email tidak valid.', 'apeiron-kit' ), [ 'status' => 422 ] );
		}

		$settings        = get_option( 'apeiron_kit_settings', [] );
		$requires_review = ( $settings['comment_moderation'] ?? 'auto' ) === 'manual';
		$status          = $requires_review ? 0 : 1;

		$comment_id = wp_insert_comment(
			wp_slash(
				[
					'comment_post_ID'      => $post_id,
					'comment_author'       => $name,
					'comment_author_email' => $email,
					'comment_content'      => $message,
					'comment_type'         => 'comment',
					'comment_approved'     => $status,
				]
			)
		);

		if ( is_wp_error( $comment_id ) ) {
			ErrorLogger::error( 'Failed to insert comment', [
				'post_id' => $post_id,
				'element_id' => $element_id,
				'error' => $comment_id->get_error_message(),
			] );
			return $comment_id;
		}

		if ( $element_id ) {
			add_comment_meta( $comment_id, 'apeiron_element_id', $element_id, true );
		}

		if ( $attendance_value ) {
			add_comment_meta( $comment_id, 'apeiron_attendance_value', $attendance_value, true );
		}

		if ( $attendance_label ) {
			add_comment_meta( $comment_id, 'apeiron_attendance_label', $attendance_label, true );
		}

		if ( $sticker_src ) {
			add_comment_meta( $comment_id, 'apeiron_sticker_src', $sticker_src, true );
			$stored_type = $sticker_type ?: $this->guess_sticker_type( $sticker_src );
			add_comment_meta( $comment_id, 'apeiron_sticker_type', $stored_type, true );
		}

		$comment = get_comment( $comment_id );

		return new WP_REST_Response(
			[
				'ok'      => true,
				'message' => $requires_review ? __( 'Komentar dikirim dan menunggu moderasi.', 'apeiron-kit' ) : __( 'Komentar dipublikasikan.', 'apeiron-kit' ),
				'comment' => $requires_review || ! $comment
					? null
					: [
						'id'               => (int) $comment->comment_ID,
						'name'             => esc_html( $comment->comment_author ),
						'message'          => wp_kses_post( wpautop( $comment->comment_content ) ),
						'createdAt'        => (int) get_comment_date( 'U', $comment ), // Send timestamp instead of formatted date
						'attendanceLabel'  => esc_html( $attendance_label ?: $attendance_value ),
						'attendanceValue'  => esc_html( $attendance_value ),
						'avatar'           => esc_url( get_avatar_url( $comment->comment_author_email, [ 'size' => 40 ] ) ),
						'sticker'          => $this->prepare_sticker_payload( (int) $comment->comment_ID ),
					],
			],
			201
		);
	}

	public function verify_nonce( WP_REST_Request $request ): bool {
		$nonce = $request->get_header( 'X-WP-Nonce' );
		if ( ! $nonce ) {
			return false;
		}
		return (bool) wp_verify_nonce( $nonce, 'wp_rest' );
	}

	private function sanitize_sticker_src( string $value ): string {
		$value = trim( $value );
		if ( empty( $value ) ) {
			return '';
		}

		$normalized = ltrim( wp_normalize_path( $value ), '/\\' );
		if ( empty( $normalized ) || 0 !== strpos( $normalized, 'assets/stickers/' ) ) {
			return '';
		}

		if ( preg_match( '#(^|/)\.\.($|/)#', $normalized ) ) {
			return '';
		}

		if ( ! preg_match( '#^assets/stickers/[a-zA-Z0-9/_\.\-]+$#', $normalized ) ) {
			return '';
		}

		$ext = strtolower( pathinfo( $normalized, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, [ 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'webm', 'mp4' ], true ) ) {
			return '';
		}

		return $normalized;
	}

	private function guess_sticker_type( string $relative ): string {
		$ext = strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) );
		return in_array( $ext, [ 'webm', 'mp4' ], true ) ? 'video' : 'image';
	}

	private function prepare_sticker_payload( int $comment_id ): array {
		$relative = (string) get_comment_meta( $comment_id, 'apeiron_sticker_src', true );
		if ( empty( $relative ) ) {
			return [];
		}

		$relative = ltrim( wp_normalize_path( $relative ), '/\\' );
		if ( empty( $relative ) || 0 !== strpos( $relative, 'assets/stickers/' ) ) {
			return [];
		}

		if ( preg_match( '#(^|/)\.\.($|/)#', $relative ) ) {
			return [];
		}

		if ( ! preg_match( '#^assets/stickers/[a-zA-Z0-9/_\.\-]+$#', $relative ) ) {
			return [];
		}

		$ext = strtolower( pathinfo( $relative, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, [ 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'webm', 'mp4' ], true ) ) {
			return [];
		}

		$type = (string) get_comment_meta( $comment_id, 'apeiron_sticker_type', true );
		if ( ! in_array( $type, [ 'image', 'video' ], true ) ) {
			$type = $this->guess_sticker_type( $relative );
		}

		return [
			'src'  => trailingslashit( APEIRON_KIT_URL ) . $relative,
			'type' => $type,
		];
	}

	/**
	 * Check rate limit for API requests
	 *
	 * @param string $type Request type: 'post' or 'get'
	 * @return bool|WP_Error True if allowed, WP_Error if rate limited
	 */
	private function check_rate_limit( string $type = 'post' ) {
		$identifier = $this->get_rate_limit_identifier();
		$transient_key = 'apeiron_comment_rate_' . $type . '_' . md5( $identifier );
		$count = (int) get_transient( $transient_key );
		$max_requests = 'post' === $type ? self::RATE_LIMIT_POST_MAX : self::RATE_LIMIT_GET_MAX;

		if ( $count >= $max_requests ) {
			return new WP_Error(
				'rate_limit',
				__( 'Terlalu banyak request. Silakan tunggu sebentar sebelum mencoba lagi.', 'apeiron-kit' ),
				[ 'status' => 429 ]
			);
		}

		set_transient( $transient_key, $count + 1, self::RATE_LIMIT_WINDOW );
		return true;
	}

	/**
	 * Build a stable identifier for rate limiting.
	 *
	 * @return string
	 */
	private function get_rate_limit_identifier(): string {
		$ip = $this->get_client_ip();
		if ( ! empty( $ip ) ) {
			return 'ip:' . $ip;
		}

		$user_agent      = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$accept_language = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) : '';

		if ( '' === $user_agent && '' === $accept_language ) {
			return 'anonymous';
		}

		return 'fallback:' . hash( 'sha256', strtolower( $user_agent ) . '|' . strtolower( $accept_language ) );
	}

	/**
	 * Get client IP address
	 * 
	 * @return string Client IP address
	 */
	private function get_client_ip(): string {
		$ip_keys = [
			'HTTP_CF_CONNECTING_IP', // Cloudflare
			'HTTP_X_REAL_IP',        // Nginx proxy
			'HTTP_X_FORWARDED_FOR',  // Proxy
			'REMOTE_ADDR',           // Standard (fallback)
		];

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				// Handle comma-separated IPs (X-Forwarded-For)
				if ( strpos( $ip, ',' ) !== false ) {
					$ip = trim( explode( ',', $ip )[0] );
				}
				// Validate IP
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}

		return '';
	}

	/**
	 * Check if the Comment Dock widget is disabled.
	 *
	 * @return bool True if comment_dock is in the disabled widgets list.
	 */
	private function is_comment_dock_disabled(): bool {
		$disabled = get_option( 'apeiron_kit_disabled_widgets', [] );

		if ( ! is_array( $disabled ) ) {
			return false;
		}

		return in_array( 'comment_dock', $disabled, true );
	}
}
