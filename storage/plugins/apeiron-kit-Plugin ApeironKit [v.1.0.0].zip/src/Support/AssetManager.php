<?php

namespace ApeironKit\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AssetManager {

	/**
	 * Option name for disabled widgets.
	 */
	private const OPTION_NAME = 'apeiron_kit_disabled_widgets';

	/**
	 * Map of toggle slug => Elementor widget type.
	 *
	 * Used to bridge between the dashboard toggle slugs
	 * and Elementor's widget type identifiers.
	 *
	 * @var array<string, string>
	 */
	private const WIDGET_SLUG_TO_TYPE = [
		'comment_dock'     => 'apeiron-comment-dock',
		'pulse_countdown'  => 'apeiron-pulse-countdown',
		'guest_manager'    => 'apeiron-guest-invitation-manager',
		'clipboard_tap'    => 'apeiron-clipboard-tap',
		'soundscape'       => 'apeiron-soundscape',
		'signal_form'      => 'apeiron-signal-form',
		'social_proof'     => 'apeiron-social-proof',
		'autoscroll'       => 'apeiron-autoscroll',
	];

	/**
	 * Map of Elementor widget type => CSS handle.
	 *
	 * @var array<string, string>
	 */
	private const WIDGET_CSS_MAP = [
		'apeiron-autoscroll'               => 'apeiron-kit-autoscroll',
		'apeiron-guest-invitation-manager' => 'apeiron-kit-guest-invitation',
		'apeiron-pulse-countdown'          => 'apeiron-kit-pulse-countdown',
		'apeiron-soundscape'               => 'apeiron-kit-soundscape',
		'apeiron-signal-form'              => 'apeiron-kit-signal-form',
		'apeiron-clipboard-tap'            => 'apeiron-kit-clipboard-tap',
		'apeiron-comment-dock'             => 'apeiron-kit-comment-dock',
		'apeiron-social-proof'             => 'apeiron-kit-social-proof',
	];

	/**
	 * Map of Elementor widget type => JS handle.
	 *
	 * Only widgets that require frontend JavaScript are listed.
	 * Maps Elementor widget type to registered JS handle.
	 *
	 * @var array<string, string>
	 */
	private const WIDGET_JS_MAP = [
		'apeiron-autoscroll'               => 'apeiron-kit-autoscroll-js',
		'apeiron-pulse-countdown'          => 'apeiron-kit-countdown-js',
		'apeiron-soundscape'               => 'apeiron-kit-soundscape-js',
		'apeiron-signal-form'              => 'apeiron-kit-signal-form-js',
		'apeiron-clipboard-tap'            => 'apeiron-kit-clipboard-js',
		'apeiron-comment-dock'             => 'apeiron-kit-comment-dock-js',
		'apeiron-guest-invitation-manager' => 'apeiron-kit-guest-invitation-js',
		'apeiron-social-proof'             => 'apeiron-kit-social-proof-js',
	];

	/**
	 * Prevent duplicate registration during same request.
	 *
	 * @var bool
	 */
	private bool $assets_registered = false;

	/**
	 * Cached parsed Elementor data for the current page.
	 * Avoids redundant json_decode() calls in has_specific_widget().
	 *
	 * @var array|null|false  null = not yet loaded, false = not available, array = parsed data.
	 */
	private $parsed_elementor_data = null;

	public function register(): void {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend' ] );
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_editor' ] );

		// Heartbeat: send disabled widgets state to Elementor editor
		add_filter( 'heartbeat_received', [ $this, 'heartbeat_received' ], 10, 2 );
	}

	/**
	 * Safely detect Elementor editor mode.
	 *
	 * @return bool
	 */
	private function is_elementor_edit_mode(): bool {
		return class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->editor )
			&& \Elementor\Plugin::$instance->editor->is_edit_mode();
	}

	/**
	 * Register all plugin frontend assets once per request.
	 */
	private function register_assets(): void {
		if ( $this->assets_registered ) {
			return;
		}

		// Use minified assets in production, unminified when debugging.
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_register_style(
			'apeiron-kit-frontend',
			APEIRON_KIT_URL . 'assets/css/frontend' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-autoscroll',
			APEIRON_KIT_URL . 'assets/css/apeiron-autoscroll' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-guest-invitation',
			APEIRON_KIT_URL . 'assets/css/apeiron-guest-invitation' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-pulse-countdown',
			APEIRON_KIT_URL . 'assets/css/apeiron-pulse-countdown' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-soundscape',
			APEIRON_KIT_URL . 'assets/css/apeiron-soundscape' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-signal-form',
			APEIRON_KIT_URL . 'assets/css/apeiron-signal-form' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-clipboard-tap',
			APEIRON_KIT_URL . 'assets/css/apeiron-clipboard-tap' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-comment-dock',
			APEIRON_KIT_URL . 'assets/css/apeiron-comment-dock' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		wp_register_style(
			'apeiron-kit-social-proof',
			APEIRON_KIT_URL . 'assets/css/apeiron-social-proof' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		// Core script: anchor for wp_localize_script data
		wp_register_script(
			'apeiron-core',
			APEIRON_KIT_URL . 'assets/js/apeiron-core' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_localize_script(
			'apeiron-core',
			'ApeironKit',
			[
				'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
				'restUrl'          => get_rest_url( null, 'apeiron-kit/v1' ),
				'nonce'            => wp_create_nonce( 'wp_rest' ),
				'defaultAvatarUrl' => APEIRON_KIT_URL . 'assets/img/man-avatar.webp',
			]
		);

		// Per-widget JavaScript files
		wp_register_script(
			'apeiron-kit-countdown-js',
			APEIRON_KIT_URL . 'assets/js/widgets/countdown' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-comment-dock-js',
			APEIRON_KIT_URL . 'assets/js/widgets/comment-dock' . $suffix . '.js',
			[ 'jquery', 'apeiron-core' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-clipboard-js',
			APEIRON_KIT_URL . 'assets/js/widgets/clipboard' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-signal-form-js',
			APEIRON_KIT_URL . 'assets/js/widgets/signal-form' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-soundscape-js',
			APEIRON_KIT_URL . 'assets/js/widgets/soundscape' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-autoscroll-js',
			APEIRON_KIT_URL . 'assets/js/widgets/autoscroll' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		wp_register_script(
			'apeiron-kit-social-proof-js',
			APEIRON_KIT_URL . 'assets/js/widgets/social-proof' . $suffix . '.js',
			[ 'jquery' ],
			APEIRON_KIT_VERSION,
			true
		);

		// SheetJS library for Excel import (Guest Invitation Manager)
		wp_register_script(
			'apeiron-sheetjs',
			'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
			[],
			'0.18.5',
			true
		);

		wp_register_script(
			'apeiron-kit-guest-invitation-js',
			APEIRON_KIT_URL . 'assets/js/widgets/guest-invitation' . $suffix . '.js',
			[ 'apeiron-sheetjs' ],
			APEIRON_KIT_VERSION,
			true
		);

		$this->assets_registered = true;
	}

	/**
	 * Check if assets should be loaded on current page
	 * Optimize by only loading when needed
	 */
	private function should_load_assets(): bool {
		// Always load in Elementor editor
		if ( $this->is_elementor_edit_mode() ) {
			return true;
		}

		// Check if any active (non-disabled) Apeiron Kit widget is used on current page
		if ( is_singular() ) {
			$post_id = get_the_ID();
			$elementor_data = get_post_meta( $post_id, '_elementor_data', true );
			if ( $elementor_data && is_string( $elementor_data ) ) {
				$data = json_decode( $elementor_data, true );
				$disabled_types = $this->get_disabled_widget_types();
				if ( $this->has_apeiron_widget( $data, null, $disabled_types ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Recursively check if page contains Apeiron Kit widgets.
	 *
	 * @param array       $data        Elementor page data.
	 * @param string|null $widget_type Optional specific widget type to check for (e.g., 'apeiron-autoscroll').
	 * @param string[]    $exclude     Widget types to skip (disabled widgets).
	 * @return bool True if widget is found.
	 */
	private function has_apeiron_widget( $data, ?string $widget_type = null, array $exclude = [] ): bool {
		if ( ! is_array( $data ) ) {
			return false;
		}

		foreach ( $data as $element ) {
			if ( isset( $element['widgetType'] ) ) {
				// Skip disabled widget types
				if ( $exclude && in_array( $element['widgetType'], $exclude, true ) ) {
					// Continue to check child elements
				} elseif ( $widget_type !== null ) {
					// If specific widget type requested, check for exact match
					if ( $element['widgetType'] === $widget_type ) {
						return true;
					}
				} else {
					// Check for any Apeiron widget
					if ( strpos( $element['widgetType'], 'apeiron-' ) === 0 ) {
						return true;
					}
				}
			}
			if ( isset( $element['elements'] ) && $this->has_apeiron_widget( $element['elements'], $widget_type, $exclude ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if a specific Apeiron widget is used on current page.
	 *
	 * @param string $widget_type Widget type slug (e.g., 'apeiron-autoscroll').
	 * @return bool True if specific widget is found.
	 */
	private function has_specific_widget( string $widget_type ): bool {
		if ( ! is_singular() ) {
			return false;
		}

		$data = $this->get_parsed_elementor_data();

		if ( is_array( $data ) ) {
			return $this->has_apeiron_widget( $data, $widget_type );
		}

		return false;
	}

	/**
	 * Get parsed Elementor data for current page (cached).
	 *
	 * Caches the result of json_decode() so that multiple
	 * has_specific_widget() calls don't re-parse the same JSON.
	 *
	 * @return array|false Parsed data or false if unavailable.
	 */
	private function get_parsed_elementor_data() {
		if ( $this->parsed_elementor_data !== null ) {
			return $this->parsed_elementor_data;
		}

		$post_id        = get_the_ID();
		$elementor_data = get_post_meta( $post_id, '_elementor_data', true );

		if ( $elementor_data && is_string( $elementor_data ) ) {
			$this->parsed_elementor_data = json_decode( $elementor_data, true );
		} else {
			$this->parsed_elementor_data = false;
		}

		return $this->parsed_elementor_data;
	}

	public function enqueue_frontend(): void {
		$this->register_assets();

		// Only enqueue if needed (optimization)
		if ( $this->should_load_assets() ) {
			wp_enqueue_style( 'apeiron-kit-frontend' );

			// Get active widget maps (disabled widgets filtered out)
			$widget_css_map = $this->get_active_widget_css_map();
			$widget_js_map  = $this->get_active_widget_js_map();

			// In Elementor editor, load all active CSS + JS for preview
			if ( $this->is_elementor_edit_mode() ) {
				foreach ( $widget_css_map as $css_handle ) {
					wp_enqueue_style( $css_handle );
				}
				foreach ( $widget_js_map as $js_handle ) {
					wp_enqueue_script( $js_handle );
				}
			} else {
				// On frontend, only load CSS + JS for active widgets actually present on this page
				foreach ( $widget_css_map as $widget_type => $css_handle ) {
					if ( $this->has_specific_widget( $widget_type ) ) {
						wp_enqueue_style( $css_handle );
					}
				}
				foreach ( $widget_js_map as $widget_type => $js_handle ) {
					if ( $this->has_specific_widget( $widget_type ) ) {
						wp_enqueue_script( $js_handle );
					}
				}
			}
		}
	}

	public function enqueue_editor(): void {
		$this->register_assets();

		// Use minified assets in production, unminified when debugging
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		// Load active widget CSS in editor for correct preview
		$active_css_handles = array_values( $this->get_active_widget_css_map() );
		// Always include frontend base CSS
		array_unshift( $active_css_handles, 'apeiron-kit-frontend' );

		foreach ( $active_css_handles as $style_handle ) {
			wp_enqueue_style( $style_handle );
		}

		// Load all active per-widget JS in editor for widget preview
		$active_js_handles = array_values( $this->get_active_widget_js_map() );
		foreach ( $active_js_handles as $js_handle ) {
			wp_enqueue_script( $js_handle );
		}

		// Inject Heartbeat-based widget toggle notification for editor
		$this->enqueue_editor_heartbeat_script();

		// Load external CSS for license lock notice in editor (moved from inline for cacheability)
		wp_enqueue_style(
			'apeiron-kit-editor-license',
			APEIRON_KIT_URL . 'assets/css/editor-license' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);

		// Load custom SVG widget icons for Elementor panel
		wp_enqueue_style(
			'apeiron-kit-widget-icons',
			APEIRON_KIT_URL . 'assets/css/widget-icons' . $suffix . '.css',
			[],
			APEIRON_KIT_VERSION
		);
	}

	/**
	 * Get the CSS map filtered to only include active (non-disabled) widgets.
	 *
	 * @return array<string, string> Widget type => CSS handle for active widgets only.
	 */
	private function get_active_widget_css_map(): array {
		$disabled       = $this->get_disabled_widgets();
		$disabled_types = [];

		foreach ( $disabled as $slug ) {
			if ( isset( self::WIDGET_SLUG_TO_TYPE[ $slug ] ) ) {
				$disabled_types[] = self::WIDGET_SLUG_TO_TYPE[ $slug ];
			}
		}

		return array_diff_key(
			self::WIDGET_CSS_MAP,
			array_flip( $disabled_types )
		);
	}

	/**
	 * Get the JS map filtered to only include active (non-disabled) widgets.
	 *
	 * @return array<string, string> Widget type => JS handle for active widgets only.
	 */
	private function get_active_widget_js_map(): array {
		$disabled       = $this->get_disabled_widgets();
		$disabled_types = [];

		foreach ( $disabled as $slug ) {
			if ( isset( self::WIDGET_SLUG_TO_TYPE[ $slug ] ) ) {
				$disabled_types[] = self::WIDGET_SLUG_TO_TYPE[ $slug ];
			}
		}

		return array_diff_key(
			self::WIDGET_JS_MAP,
			array_flip( $disabled_types )
		);
	}

	/**
	 * Retrieve the disabled widgets list with type-safe fallback.
	 *
	 * Always returns a clean array, even if the option is
	 * missing, corrupted, or contains an unexpected data type.
	 *
	 * @return string[]
	 */
	private function get_disabled_widgets(): array {
		$disabled = get_option( self::OPTION_NAME, [] );

		if ( ! is_array( $disabled ) ) {
			return [];
		}

		return $disabled;
	}

	/**
	 * Get Elementor widget types for disabled widgets.
	 *
	 * Maps disabled toggle slugs to their Elementor widget type
	 * identifiers using the existing WIDGET_SLUG_TO_TYPE constant.
	 *
	 * @return string[] e.g. ['apeiron-comment-dock', 'apeiron-autoscroll']
	 */
	private function get_disabled_widget_types(): array {
		$disabled = $this->get_disabled_widgets();
		$types    = [];

		foreach ( $disabled as $slug ) {
			if ( isset( self::WIDGET_SLUG_TO_TYPE[ $slug ] ) ) {
				$types[] = self::WIDGET_SLUG_TO_TYPE[ $slug ];
			}
		}

		return $types;
	}

	/**
	 * Heartbeat API: send current disabled widgets to editor.
	 *
	 * @param array $response Heartbeat response data.
	 * @param array $data     Heartbeat request data.
	 * @return array Modified response.
	 */
	public function heartbeat_received( array $response, array $data ): array {
		if ( ! empty( $data['apeiron_editor_active'] ) ) {
			$response['apeiron_disabled_widgets'] = $this->get_disabled_widgets();
		}

		return $response;
	}

	/**
	 * Inject inline JS for Heartbeat-based toggle notification in editor.
	 */
	private function enqueue_editor_heartbeat_script(): void {
		$disabled = $this->get_disabled_widgets();
		$initial  = wp_json_encode( $disabled );
		?>
		<script type="text/javascript">
		(function() {
			if (typeof wp === 'undefined' || !wp.heartbeat) return;
			var initial = <?php echo $initial; ?>;

			// Tell heartbeat we are in editor
			wp.heartbeat.enqueue('apeiron_editor_active', true);

			jQuery(document).on('heartbeat-tick', function(e, data) {
				if (!data.apeiron_disabled_widgets) return;
				var current = JSON.stringify(data.apeiron_disabled_widgets.sort());
				var prev    = JSON.stringify(initial.slice().sort());
				if (current !== prev) {
					initial = data.apeiron_disabled_widgets; // update so we only warn once
					if (!document.getElementById('apeiron-editor-toggle-notice')) {
						var bar = document.createElement('div');
						bar.id = 'apeiron-editor-toggle-notice';
						bar.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:200000;background:#fcf0f1;color:#86181d;padding:10px 16px;font-size:13px;text-align:center;border-bottom:1px solid #d63638;display:flex;align-items:center;justify-content:center;gap:8px;';
						bar.innerHTML = '<span class="dashicons dashicons-warning" style="font-size:16px;width:16px;height:16px;color:#d63638"></span>'
							+ '<?php echo esc_js( __( 'Pengaturan widget Apeiron telah berubah. Segarkan editor untuk menerapkan perubahan.', 'apeiron-kit' ) ); ?>'
							+ ' <button onclick="location.reload()" style="background:#d63638;color:#fff;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;font-size:12px;margin-left:8px"><?php echo esc_js( __( 'Segarkan', 'apeiron-kit' ) ); ?></button>'
							+ ' <button onclick="this.parentNode.remove()" style="background:none;border:none;color:#86181d;cursor:pointer;font-size:16px;line-height:1;padding:0 4px;margin-left:4px">&times;</button>';
						document.body.appendChild(bar);
					}
				}
			});
		})();
		</script>
		<?php
	}
}

